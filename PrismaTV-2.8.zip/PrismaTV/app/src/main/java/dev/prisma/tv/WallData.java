package dev.prisma.tv;

/**
 * Listas de partida para buscar fotos reales: artículos de Wikipedia (su foto principal casi siempre es una foto
 * de calidad en Wikimedia Commons) y búsquedas en Commons. Índice 1 = animales, 2 = paisajes,
 * 3 = lugares del mundo, 4 = ciudades.
 */
final class WallData {
    private WallData() {
    }

    static final String[][] TITLES = {
            {},
            // animales
            {"Lion", "Tiger", "Leopard", "Cheetah", "Jaguar", "Snow leopard", "Cougar", "Eurasian lynx", "Serval",
                    "African elephant", "Asian elephant", "Giraffe", "Plains zebra", "Hippopotamus",
                    "White rhinoceros", "Gorilla", "Chimpanzee", "Orangutan", "Red panda", "Giant panda", "Koala",
                    "Red kangaroo", "Gray wolf", "Red fox", "Arctic fox", "Fennec fox", "Brown bear", "Polar bear",
                    "American black bear", "Bald eagle", "Golden eagle", "Peregrine falcon", "Snowy owl",
                    "Great horned owl", "Barn owl", "Atlantic puffin", "Emperor penguin", "King penguin",
                    "Greater flamingo", "Scarlet macaw", "Indian peafowl", "Toco toucan", "Common kingfisher",
                    "Ruby-throated hummingbird", "Humpback whale", "Orca", "Bottlenose dolphin", "Sea otter",
                    "Walrus", "Moose", "Red deer", "Reindeer", "American bison", "Arabian horse", "Monarch butterfly",
                    "Green sea turtle", "Veiled chameleon", "Red-eyed tree frog", "Meerkat", "Ring-tailed lemur",
                    "Capybara", "Dromedary", "Llama", "Ostrich", "Grey crowned crane", "Mute swan", "Secretarybird",
                    "European bee-eater", "Okapi", "Mandrill", "Quokka", "Wombat", "Raccoon", "Beaver"},
            // paisajes
            {"Matterhorn", "Mount Fuji", "Denali", "Mount Kilimanjaro", "Torres del Paine National Park",
                    "Moraine Lake", "Lake Louise (Alberta)", "Lake Bled", "Lake Como",
                    "Plitvice Lakes National Park", "Banff National Park", "Yosemite National Park",
                    "Zion National Park", "Bryce Canyon National Park", "Antelope Canyon", "Horseshoe Bend",
                    "Monument Valley", "Arches National Park", "Glacier National Park (U.S.)",
                    "Grand Prismatic Spring", "Niagara Falls", "Angel Falls", "Geirangerfjord", "Lofoten",
                    "Preikestolen", "Trolltunga", "Skógafoss", "Gullfoss", "Jökulsárlón", "Dolomites", "Lake Tahoe",
                    "Crater Lake", "Death Valley", "Sossusvlei", "Salar de Uyuni", "Atacama Desert",
                    "Zhangjiajie National Forest Park", "Li River", "Bora Bora", "Table Mountain", "Mount Rainier",
                    "Mount Hood", "Aoraki / Mount Cook", "Milford Sound", "Tongariro National Park", "Cappadocia",
                    "Pamukkale", "Giant's Causeway", "Cliffs of Moher", "Isle of Skye", "Mount Etna", "Aurora",
                    "Lake Baikal", "Lake Titicaca", "Ha Long Bay", "Great Barrier Reef", "Serengeti",
                    "Okavango Delta", "Mount Everest", "Amazon rainforest"},
            // lugares y maravillas del mundo
            {"Taj Mahal", "Machu Picchu", "Great Wall of China", "Petra", "Colosseum", "Chichen Itza",
                    "Christ the Redeemer (statue)", "Great Pyramid of Giza", "Angkor Wat", "Alhambra",
                    "Sagrada Família", "Eiffel Tower", "Santorini", "Iguazu Falls", "Grand Canyon", "Stonehenge",
                    "Moai", "Mont-Saint-Michel", "Neuschwanstein Castle", "Burj Khalifa", "Uluru", "Hagia Sophia",
                    "Forbidden City", "Acropolis of Athens", "Victoria Falls", "Sydney Opera House",
                    "Golden Gate Bridge", "Statue of Liberty", "Elizabeth Tower", "Tower Bridge", "Louvre",
                    "Palace of Versailles", "Notre-Dame de Paris", "Pantheon, Rome", "Trevi Fountain",
                    "Leaning Tower of Pisa", "St. Peter's Basilica", "Milan Cathedral", "Brandenburg Gate",
                    "Cologne Cathedral", "Prague Castle", "Charles Bridge", "Hallstatt", "Bran Castle",
                    "Saint Basil's Cathedral", "Sultan Ahmed Mosque", "Burj Al Arab", "Sheikh Zayed Grand Mosque",
                    "Petronas Towers", "Marina Bay Sands", "Borobudur", "Bagan", "Shwedagon Pagoda", "Wat Arun",
                    "Potala Palace", "Himeji Castle", "Fushimi Inari-taisha", "Kinkaku-ji", "Itsukushima Shrine",
                    "Gyeongbokgung", "Terracotta Army", "Temple of Heaven", "Golden Temple", "Hawa Mahal",
                    "Red Fort", "Gateway of India", "Lotus Temple", "Sigiriya", "Karnak", "Abu Simbel temples",
                    "Great Sphinx of Giza", "Teotihuacan", "Tikal", "Sugarloaf Mountain", "Perito Moreno Glacier",
                    "Mount Rushmore", "Hoover Dam", "Brooklyn Bridge", "Empire State Building", "Space Needle",
                    "CN Tower", "Edinburgh Castle", "Windsor Castle", "Buckingham Palace", "St Paul's Cathedral",
                    "Westminster Abbey", "Schönbrunn Palace", "Meteora", "Pompeii", "Ephesus"},
            // ciudades
            {"Paris", "London", "New York City", "Tokyo", "Madrid", "Barcelona", "Rome", "Venice", "Florence",
                    "Prague", "Vienna", "Budapest", "Amsterdam", "Berlin", "Lisbon", "Porto", "Istanbul", "Dubai",
                    "Hong Kong", "Singapore", "Shanghai", "Sydney", "San Francisco", "Chicago", "Seattle",
                    "Vancouver", "Toronto", "Rio de Janeiro", "Cape Town", "Seville", "Valencia", "Edinburgh",
                    "Copenhagen", "Stockholm", "Oslo", "Dubrovnik", "Kyoto", "Osaka", "Seoul", "Bangkok",
                    "Kuala Lumpur", "Doha", "Abu Dhabi", "Cairo", "Marrakesh", "Buenos Aires", "Mexico City",
                    "Havana", "Miami", "Las Vegas", "Los Angeles", "Boston", "Washington, D.C.", "Moscow",
                    "Saint Petersburg", "Tallinn", "Salzburg", "Zurich", "Geneva", "Bruges", "Brussels", "Munich",
                    "Hamburg", "Frankfurt", "Milan", "Naples", "Athens", "Warsaw", "Kraków"}};

    /** Búsquedas en Commons (con filtro de fotos destacadas / de calidad). */
    static final String[][] KW = {
            {},
            {"lion", "tiger", "eagle", "wolf", "elephant", "fox", "owl", "bear", "whale", "parrot", "horse",
                    "butterfly", "penguin", "giraffe", "dolphin", "flamingo", "leopard", "panda", "koala",
                    "hummingbird", "deer", "zebra", "cheetah", "puffin", "toucan", "kingfisher", "otter", "gorilla"},
            {"mountain", "lake", "waterfall", "forest", "sunset", "desert", "glacier", "valley", "aurora",
                    "canyon", "beach", "volcano", "fjord", "autumn forest", "coast cliffs", "snow peaks",
                    "mountain lake", "alpine meadow", "sand dunes", "foggy forest"},
            {"Taj Mahal", "Machu Picchu", "Great Wall of China", "Petra Jordan", "Colosseum Rome",
                    "Chichen Itza", "Christ the Redeemer", "Pyramids of Giza", "Angkor Wat", "Alhambra",
                    "Sagrada Familia", "Eiffel Tower", "Santorini", "Iguazu Falls", "Grand Canyon", "Stonehenge",
                    "Easter Island moai", "Mont Saint-Michel", "Neuschwanstein", "Burj Khalifa", "Uluru",
                    "Hagia Sophia", "Forbidden City", "Acropolis Athens", "Victoria Falls", "Sydney Opera House",
                    "Golden Gate Bridge", "Statue of Liberty"},
            {"Paris skyline", "London skyline", "New York skyline", "Tokyo skyline", "Madrid skyline",
                    "Barcelona skyline", "Venice skyline", "Dubai skyline", "Hong Kong skyline", "Sydney skyline",
                    "Rome skyline", "Istanbul skyline", "Prague skyline", "San Francisco skyline",
                    "Singapore skyline", "Shanghai skyline", "Lisbon skyline", "Chicago skyline", "Toronto skyline",
                    "Rio de Janeiro skyline", "Vienna skyline", "Budapest skyline", "Seoul skyline",
                    "Bangkok skyline", "Cape Town skyline", "Amsterdam skyline", "Berlin skyline",
                    "Kuala Lumpur skyline"}};

    /** Búsquedas de respaldo, solo si un tema tiene pocas fotos. */
    static final String[][] EXTRA = {
            {},
            {"wildlife", "bird", "monkey", "seal", "frog", "tiger cub", "rhinoceros", "crocodile", "cat portrait"},
            {"landscape", "sunrise", "river", "lake mountains", "tropical beach", "rainforest", "snowy mountain"},
            {"ancient temple", "world heritage site", "famous monument", "castle", "pyramid", "great bridge", "old town"},
            {"city skyline", "city at night", "city skyline sunset", "aerial view city", "downtown skyline",
                    "bridge and city", "metropolis", "city panorama", "harbor skyline", "skyscrapers", "cityscape",
                    "blue hour city"}};
}
