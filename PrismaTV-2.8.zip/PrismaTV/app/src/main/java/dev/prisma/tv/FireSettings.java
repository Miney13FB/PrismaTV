package dev.prisma.tv;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Ajustes del Fire TV original. En Fire OS las intenciones estándar de Android (android.settings.*) suelen
 * acabar en una pantalla vacía de cumplimiento (CTSDummySettingsHandler) que no abre nada; por eso aquí se
 * prepara una lista de rutas (de la mejor a la peor) y {@link MainActivity#openRoutes} prueba cada una y
 * comprueba que de verdad se abrió algo antes de dar la ruta por buena.
 */
final class FireSettings {
    private FireSettings() {
    }

    static final String LAUNCHER = "com.amazon.tv.launcher";
    static final String[] SETTINGS_PKGS = {"com.amazon.tv.settings.v2", "com.amazon.tv.settings"};

    // ------------------------------------------------------------------ escribir ajustes

    static boolean putSecure(Context c, String key, int v) {
        try {
            return Settings.Secure.putInt(c.getContentResolver(), key, v);
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean putSystem(Context c, String key, int v) {
        try {
            return Settings.System.putInt(c.getContentResolver(), key, v);
        } catch (Throwable t) {
            return false;
        }
    }

    // ------------------------------------------------------------------ rutas para abrir pantallas de ajustes

    private static Intent explicit(String pkg, String cls, String action) {
        Intent i = new Intent(action == null ? Intent.ACTION_MAIN : action);
        i.setComponent(new ComponentName(pkg, cls));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return i;
    }

    private static boolean has(PackageManager pm, String pkg, String cls) {
        try {
            pm.getActivityInfo(new ComponentName(pkg, cls), 0);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Una intención estándar solo vale si no acaba en la pantalla vacía de Fire OS ni en un selector. */
    private static Intent standard(PackageManager pm, Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ResolveInfo ri = pm.resolveActivity(i, 0);
            if (ri == null || ri.activityInfo == null) return null;
            String n = ri.activityInfo.name == null ? "" : ri.activityInfo.name;
            if (n.contains("CTSDummy") || n.contains("ResolverActivity") || n.contains("Dummy")) return null;
            return i;
        } catch (Throwable t) {
            return null;
        }
    }

    private static Intent standard(PackageManager pm, String action) {
        return standard(pm, new Intent(action));
    }

    /** Pantalla principal de Ajustes del launcher de Amazon (Fire OS 7 y 8), de la más a la menos fiable. */
    static List<Intent> mainRoutes(Context c) {
        PackageManager pm = c.getPackageManager();
        ArrayList<Intent> out = new ArrayList<>();
        if (has(pm, LAUNCHER, "com.amazon.tv.launcher.ui.MainSettingsActivity")) {
            out.add(explicit(LAUNCHER, "com.amazon.tv.launcher.ui.MainSettingsActivity",
                    "amazon.intent.action.MAINSETTINGS"));
        }
        try {
            Intent cat = new Intent(Intent.ACTION_MAIN);
            cat.addCategory("android.intent.category.LEANBACK_SETTINGS");
            cat.setPackage(LAUNCHER);
            cat.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (pm.resolveActivity(cat, 0) != null) out.add(cat);
        } catch (Throwable ignored) {
        }
        if (has(pm, LAUNCHER, "com.amazon.tv.launcher.ui.SettingsActivity")) {
            out.add(explicit(LAUNCHER, "com.amazon.tv.launcher.ui.SettingsActivity", null));
        }
        Intent std = standard(pm, Settings.ACTION_SETTINGS);
        if (std != null) out.add(std);
        return out;
    }

    /** Pantallas sueltas de la app de ajustes de Amazon cuyo nombre contiene alguna de las palabras (en orden). */
    private static List<Intent> pages(Context c, String... words) {
        ArrayList<Intent> out = new ArrayList<>();
        PackageManager pm = c.getPackageManager();
        for (String p : SETTINGS_PKGS) {
            try {
                PackageInfo pi = pm.getPackageInfo(p, PackageManager.GET_ACTIVITIES);
                if (pi.activities == null) continue;
                for (String w : words) {
                    for (ActivityInfo ai : pi.activities) {
                        if (!ai.exported || !ai.enabled || ai.name == null) continue;
                        String n = ai.name.toLowerCase(Locale.ROOT);
                        if (n.contains("cts") || n.contains("dummy") || n.contains("fallback")
                                || n.contains("wallpaper") || n.contains("mirror") || n.contains("daydream")) continue;
                        if (!n.contains(w)) continue;
                        boolean dup = false;
                        for (Intent o : out) {
                            if (o.getComponent() != null && o.getComponent().getClassName().equals(ai.name)) dup = true;
                        }
                        if (!dup) out.add(explicit(p, ai.name, null));
                    }
                }
            } catch (Throwable ignored) {
            }
        }
        return out;
    }

    /** Una intención estándar de Android (si funciona de verdad) y, si no, los ajustes principales de Fire TV. */
    static List<Intent> routes(Context c, Intent first) {
        ArrayList<Intent> out = new ArrayList<>();
        Intent std = standard(c.getPackageManager(), first);
        if (std != null) out.add(std);
        out.addAll(mainRoutes(c));
        return out;
    }

    static List<Intent> routes(Context c, String action) {
        return routes(c, new Intent(action));
    }

    /** Pantalla y sonidos: su pantalla si se deja abrir y, si no, los ajustes principales de Fire TV. */
    static List<Intent> displayRoutes(Context c) {
        ArrayList<Intent> out = new ArrayList<>();
        Intent std = standard(c.getPackageManager(), Settings.ACTION_DISPLAY_SETTINGS);
        if (std != null) out.add(std);
        out.addAll(pages(c, "displaysound", "display_sound", "displayandsound", "display"));
        out.addAll(mainRoutes(c));
        return out;
    }

    static List<Intent> soundRoutes(Context c) {
        ArrayList<Intent> out = new ArrayList<>();
        Intent std = standard(c.getPackageManager(), Settings.ACTION_SOUND_SETTINGS);
        if (std != null) out.add(std);
        out.addAll(pages(c, "displaysound", "display_sound", "displayandsound", "sound", "audio"));
        out.addAll(mainRoutes(c));
        return out;
    }

    /** Texto corto para saber qué se probó (se enseña solo si ninguna ruta funcionó). */
    static String describe(List<Intent> routes) {
        StringBuilder sb = new StringBuilder();
        for (Intent i : routes) {
            if (sb.length() > 0) sb.append('\n');
            if (i.getComponent() != null) {
                String cls = i.getComponent().getClassName();
                sb.append(i.getComponent().getPackageName()).append('/').append(cls.substring(cls.lastIndexOf('.') + 1));
            } else if (i.getAction() != null) {
                sb.append(i.getAction());
            } else {
                sb.append(String.valueOf(i.getCategories()));
            }
        }
        return sb.length() == 0 ? "-" : sb.toString();
    }
}
