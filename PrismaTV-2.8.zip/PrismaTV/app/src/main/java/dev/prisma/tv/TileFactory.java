package dev.prisma.tv;

import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;

/**
 * Crea la tarjeta de cada app: 1) su banner de Android TV a pantalla completa;
 * 2) si no tiene (o el banner es casi todo transparente), su icono sobre un degradado con el color
 * dominante y el nombre. La tarjeta nunca queda transparente.
 */
final class TileFactory {
    private TileFactory() {
    }

    static Bitmap make(PackageManager pm, AppItem a, int w, int h) {
        Drawable banner = null;
        try {
            banner = a.ri.activityInfo.loadBanner(pm);
            if (banner == null) banner = a.ri.activityInfo.applicationInfo.loadBanner(pm);
        } catch (Throwable ignored) {
        }
        if (banner != null) {
            try {
                Bitmap b = fromBanner(banner, w, h);
                if (b != null) return b;
            } catch (Throwable ignored) {
            }
        }

        Drawable icon = null;
        try {
            icon = a.ri.loadIcon(pm);
        } catch (Throwable ignored) {
        }
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        gradient(c, icon != null ? dominant(icon) : 0xFF3A4A66, w, h);

        if (icon != null) {
            int s = (int) (h * 0.50f);
            int l = (w - s) / 2;
            int t = (int) (h * 0.12f);
            icon.setBounds(l, t, l + s, t + s);
            icon.draw(c);
        }

        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setColor(0xFFFFFFFF);
        tp.setTextSize(h * 0.135f);
        tp.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tp.setTextAlign(Paint.Align.CENTER);
        tp.setShadowLayer(h * 0.03f, 0, h * 0.01f, 0x99000000);
        CharSequence lab = TextUtils.ellipsize(a.label, new android.text.TextPaint(tp), w * 0.86f,
                TextUtils.TruncateAt.END);
        c.drawText(lab, 0, lab.length(), w / 2f, h * 0.90f, tp);
        return out;
    }

    /** Degradado con el color de la app (de más claro arriba a más oscuro abajo). */
    private static void gradient(Canvas c, int base, int w, int h) {
        float[] hsv = new float[3];
        Color.colorToHSV(base, hsv);
        hsv[1] = Math.max(hsv[1], 0.45f);
        hsv[2] = Math.min(Math.max(hsv[2], 0.55f), 0.90f);
        int top = Color.HSVToColor(hsv);
        hsv[2] *= 0.50f;
        int bot = Color.HSVToColor(hsv);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, w * 0.4f, h, top, bot, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
    }

    /**
     * Banner a pantalla completa. Devuelve null si casi todo es transparente (no se vería nada) y, si solo
     * tiene partes transparentes (un logo suelto), lo pone sobre un degradado para que la tarjeta se vea entera.
     */
    private static Bitmap fromBanner(Drawable banner, int w, int h) {
        Bitmap raw = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        drawCover(new Canvas(raw), banner, w, h);
        int solid = 0, total = 0;
        for (int y = 1; y < h; y += 6) {
            for (int x = 1; x < w; x += 6) {
                total++;
                if (Color.alpha(raw.getPixel(x, y)) >= 200) solid++;
            }
        }
        float frac = total == 0 ? 0f : solid / (float) total;
        if (frac < 0.12f) {
            raw.recycle();
            return null;
        }
        if (frac >= 0.95f) return raw;
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        gradient(c, dominant(banner), w, h);
        c.drawBitmap(raw, 0, 0, null);
        raw.recycle();
        return out;
    }

    private static void drawCover(Canvas c, Drawable d, int w, int h) {
        int iw = d.getIntrinsicWidth();
        int ih = d.getIntrinsicHeight();
        if (iw <= 0 || ih <= 0) {
            d.setBounds(0, 0, w, h);
            d.draw(c);
            return;
        }
        float s = Math.max(w / (float) iw, h / (float) ih);
        c.save();
        c.translate((w - iw * s) / 2f, (h - ih * s) / 2f);
        c.scale(s, s);
        d.setBounds(0, 0, iw, ih);
        d.draw(c);
        c.restore();
    }

    private static int dominant(Drawable icon) {
        try {
            Bitmap s = Bitmap.createBitmap(24, 24, Bitmap.Config.ARGB_8888);
            Canvas sc = new Canvas(s);
            icon.setBounds(0, 0, 24, 24);
            icon.draw(sc);
            double r = 0, g = 0, b = 0, wt = 0;
            float[] hsv = new float[3];
            for (int y = 0; y < 24; y++) {
                for (int x = 0; x < 24; x++) {
                    int px = s.getPixel(x, y);
                    if (Color.alpha(px) < 128) continue;
                    Color.colorToHSV(px, hsv);
                    double wgt = hsv[1] * hsv[2];
                    if (wgt < 0.05) continue;
                    r += Color.red(px) * wgt;
                    g += Color.green(px) * wgt;
                    b += Color.blue(px) * wgt;
                    wt += wgt;
                }
            }
            s.recycle();
            if (wt < 1) return 0xFF3A4A66;
            return Color.rgb((int) (r / wt), (int) (g / wt), (int) (b / wt));
        } catch (Throwable t) {
            return 0xFF3A4A66;
        }
    }
}
