package dev.prisma.tv;

import android.content.Context;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

/** Botón de cristal pequeño (Wi-Fi, ajustes) de la barra superior. */
final class Chip extends GlassView implements FocusFx {
    Chip(Context c, float radiusPx) {
        super(c, radiusPx, 0x55101828);
        setFocusable(true);
        setClickable(true);
    }

    @Override
    protected void onFocusChanged(boolean gainFocus, int direction, android.graphics.Rect previouslyFocusedRect) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect);
        // si pierde el foco porque se oculta o se quita (el escuchador global no avisa), vuelve a su aspecto normal
        if (!gainFocus && !isShown()) fx(false, 0, false);
    }

    @Override
    public void fx(boolean focused, int dir, boolean animate) {
        setFocusRim(focused);
        float s = focused ? 1.10f : 1f;
        if (!animate) {
            setScaleX(s);
            setScaleY(s);
            return;
        }
        animate().cancel();
        animate().scaleX(s).scaleY(s)
                .setDuration(focused ? 240 : 160)
                .setInterpolator(focused ? new OvershootInterpolator(1.6f) : new DecelerateInterpolator())
                .start();
    }
}
