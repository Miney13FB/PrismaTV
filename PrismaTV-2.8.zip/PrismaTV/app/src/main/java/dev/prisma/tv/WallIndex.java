package dev.prisma.tv;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Parte "pura" del buscador de fotos (sin Android): lee las respuestas de Wikipedia y de Wikimedia Commons,
 * se queda solo con fotos de verdad (JPEG, horizontales, con licencia libre, sin mapas, logos, dibujos ni
 * collages) y guarda/lee el índice de fotos en texto.
 */
final class WallIndex {
    private WallIndex() {
    }

    static final int ANIMALS = 1, LAND = 2, WORLD = 3, CITIES = 4;

    /** Una foto del índice: tema, dirección de la imagen (1920 px de ancho), título y crédito. */
    static final class Item {
        final int topic;
        final String url;
        final String title;
        final String credit;

        Item(int topic, String url, String title, String credit) {
            this.topic = topic;
            this.url = url;
            this.title = title;
            this.credit = credit;
        }
    }

    private static final Pattern BAD_ALL = Pattern.compile("\\b(montage|collage|composite|mosaic|map|maps|locator|"
            + "logo|flag|flags|diagram|chart|graph|coat of arms|emblem|icon|illustration|drawing|sketch|painting|"
            + "engraving|lithograph|poster|stamp|plan|schematic|infographic|skeleton|skull|fossil|specimen|"
            + "taxidermy|satellite|landsat|modis|sentinel|screenshot|render|rendering|cgi|3d|ai generated|"
            + "generated|nasa|banner|cartoon|clipart|vector|svg)\\b");
    private static final Pattern BAD_ANIMAL = Pattern.compile("\\b(statue|statues|sculpture|monument|toy|plush|"
            + "stuffed|heraldic|carving|figurine|mural|graffiti|street art|stained glass|tapestry|lego|costume|"
            + "mascot)\\b");
    private static final String[] BAD_CATS = {"paintings", "drawings", "illustrations", "maps", "diagrams", "flags",
            "logos", "coats of arms", "engravings", "posters", "postage stamps", "cartoons", "lithographs",
            "computer-generated", "renderings", "ai-generated", "satellite images", "black and white",
            "monochrome", "sepia", "tapestries", "sketches"};

    /** El nombre del archivo delata mapas, logos, collages, dibujos... */
    static boolean badName(String fileTitle, int topic) {
        String s = fileTitle == null ? "" : fileTitle.toLowerCase(Locale.ROOT).replace('_', ' ');
        if (s.startsWith("file:")) s = s.substring(5);
        s = s.replaceAll("\\.[a-z0-9]{3,4}$", "");
        if (BAD_ALL.matcher(s).find()) return true;
        return topic == ANIMALS && BAD_ANIMAL.matcher(s).find();
    }

    /** Las categorías de Commons delatan lo que no es una foto. */
    static boolean badCats(String cats) {
        if (cats == null || cats.isEmpty()) return false;
        String s = cats.toLowerCase(Locale.ROOT);
        for (String b : BAD_CATS) {
            if (s.contains(b)) return true;
        }
        return false;
    }

    /** Dominio público, CC0 y Creative Commons con permiso de uso (sin NC ni ND). */
    static boolean okLicense(String lic) {
        String s = lic == null ? "" : lic.toLowerCase(Locale.ROOT).trim();
        if (s.isEmpty()) return false;
        if (s.contains("-nc") || s.contains("-nd") || s.contains(" nc") || s.contains(" nd")) return false;
        return s.startsWith("public domain") || s.startsWith("pd") || s.startsWith("cc0") || s.startsWith("cc by");
    }

    private static String niceLicense(String lic) {
        String s = lic.toLowerCase(Locale.ROOT).trim();
        if (s.startsWith("public domain") || s.startsWith("pd")) return "dominio público";
        return lic.trim();
    }

    private static String val(JSONObject md, String key) {
        if (md == null) return "";
        JSONObject o = md.optJSONObject(key);
        return o == null ? "" : o.optString("value", "");
    }

    private static String strip(String html) {
        return html.replaceAll("<[^>]*>", "").replace("&amp;", "&").replace("&nbsp;", " ")
                .replace("&quot;", "\"").replace("&#39;", "'");
    }

    static String clean(String s, int max) {
        String t = s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim();
        while (t.contains("  ")) t = t.replace("  ", " ");
        if (t.length() > max) t = t.substring(0, max - 1).trim() + "…";
        return t;
    }

    private static JSONObject pagesOf(String json) throws Exception {
        JSONObject o = new JSONObject(json);
        JSONObject err = o.optJSONObject("error");
        if (err != null) throw new Exception("API: " + err.optString("code", "?"));
        JSONObject q = o.optJSONObject("query");
        if (q == null) return null;
        return q.optJSONObject("pages");
    }

    /**
     * Respuesta de Commons con "imageinfo" (de una búsqueda o de una lista de archivos) → fotos válidas.
     * {@code seen} son las direcciones que ya están en el índice; {@code bad} las que fallaron al bajarlas.
     */
    static List<Item> photos(String json, int topic, int minW, Set<String> seen, Set<String> bad) throws Exception {
        ArrayList<Item> out = new ArrayList<>();
        JSONObject pages = pagesOf(json);
        if (pages == null) return out;
        Iterator<String> it = pages.keys();
        while (it.hasNext()) {
            JSONObject pg = pages.optJSONObject(it.next());
            if (pg == null) continue;
            JSONArray ii = pg.optJSONArray("imageinfo");
            if (ii == null || ii.length() == 0) continue;
            JSONObject info = ii.optJSONObject(0);
            if (info == null) continue;
            String url = info.optString("thumburl", "");
            if (url.isEmpty()) url = info.optString("url", "");
            if (url.isEmpty() || seen.contains(url) || (bad != null && bad.contains(url))) continue;
            String mime = info.optString("mime", "");
            if (!mime.isEmpty() && !mime.equals("image/jpeg")) continue;
            int w = info.optInt("width"), h = info.optInt("height");
            if (h <= 0 || w < minW) continue;
            float ar = w / (float) h;
            // horizontales, pero no panoramas gigantes (su miniatura a veces no se puede generar)
            if (ar < 1.30f || ar > 2.40f || (long) w * h > 60000000L) continue;
            String fileTitle = pg.optString("title", "");
            if (badName(fileTitle, topic)) continue;
            JSONObject md = info.optJSONObject("extmetadata");
            String lic = val(md, "LicenseShortName");
            if (!okLicense(lic)) continue;
            if (badCats(val(md, "Categories"))) continue;
            String title = clean(fileTitle.replace("File:", "").replaceAll("\\.[A-Za-z0-9]{3,4}$", "")
                    .replace('_', ' '), 60);
            String artist = clean(strip(val(md, "Artist")), 40);
            String credit = title + (artist.isEmpty() ? "" : " · " + artist) + " · " + niceLicense(lic);
            seen.add(url);
            out.add(new Item(topic, url, title, credit));
        }
        return out;
    }

    /** Respuesta de Wikipedia (prop=pageimages) → nombres de las fotos principales ("File:Nombre.jpg"). */
    static List<String> leadFiles(String json, int topic) throws Exception {
        ArrayList<String> out = new ArrayList<>();
        JSONObject pages = pagesOf(json);
        if (pages == null) return out;
        Iterator<String> it = pages.keys();
        while (it.hasNext()) {
            JSONObject pg = pages.optJSONObject(it.next());
            if (pg == null) continue;
            String f = pg.optString("pageimage", "");
            if (f.isEmpty() || badName(f, topic)) continue;
            String t = "File:" + f;
            if (!out.contains(t)) out.add(t);
        }
        return out;
    }

    // ------------------------------------------------------------------ índice en texto

    static String line(Item it) {
        return it.topic + "\t" + it.url + "\t" + it.title + "\t" + it.credit;
    }

    static Item parseLine(String l) {
        if (l == null) return null;
        String[] p = l.split("\t");
        if (p.length < 4 || p[0].length() != 1) return null;
        int t = p[0].charAt(0) - '0';
        if (t < 1 || t > 4 || !p[1].startsWith("http")) return null;
        return new Item(t, p[1], p[2], p[3]);
    }

    static List<Item> parse(String text) {
        ArrayList<Item> out = new ArrayList<>();
        if (text == null || text.isEmpty()) return out;
        for (String l : text.split("\n")) {
            Item i = parseLine(l);
            if (i != null) out.add(i);
        }
        return out;
    }

    static String serialize(List<Item> items) {
        StringBuilder sb = new StringBuilder();
        for (Item i : items) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(line(i));
        }
        return sb.toString();
    }
}
