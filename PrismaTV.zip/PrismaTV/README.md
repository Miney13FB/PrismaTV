# Prisma TV 2
Launcher ligero para Fire TV: un solo Inicio (dock + todas las apps), fondo con fotos reales (animales, paisajes,
lugares del mundo y ciudades) y Centro de control propio (botón ≡ del mando o el engranaje): Wi-Fi, Bluetooth,
pantalla de bloqueo, tiempo, fondos y Mi Fire TV.

## Cómo compilar (importante)
El compilador de GitHub (el `build.yml` de la RAÍZ del repo) solo descomprime un archivo llamado exactamente **`PrismaTV.zip`**.
Para actualizar: sube este zip con ESE nombre (sustituye al anterior), espera a que Actions salga en verde (✓) y descarga el
artefacto `PrismaTV-apk` de la ejecución más reciente. Los zips con otro nombre (PrismaTV-2.8.zip, etc.) se guardan en el
repo pero NO se compilan: eso hizo que durante varias versiones se siguiera instalando siempre el APK de la 2.4.
Comprobación: al final de los Ajustes de Prisma debe poner la versión ("Prisma TV 2.8").

Opcional (ADB, una vez) para que Wi-Fi/Bluetooth busquen sin pedir permiso:
  adb shell pm grant dev.prisma.tv android.permission.ACCESS_FINE_LOCATION

## v2.1
- Ajustes propios estilo iPhone (interruptores verdes/grises): Wi-Fi, Bluetooth, pantalla de bloqueo, tiempo, dispositivo.
- Bluetooth junto al Wi-Fi en la barra superior; búsqueda y conexión corregidas.
- El tiempo por ciudad (opcional en Inicio) con Open-Meteo, sin claves.
- Pantalla de bloqueo con hora, fecha, nombre y tiempo tras unos minutos sin usar el mando.
- Quitados logo, animaciones y volumen.

Permisos opcionales por ADB:
    adb shell pm grant dev.prisma.tv android.permission.ACCESS_FINE_LOCATION
    adb shell settings put secure location_mode 3

## v2.2
- 12 fondos nuevos (colores, animales y lugares del mundo) con cambio suave entre fondos.
- Tiempo con los próximos 5 días (pulsa una tarjeta del Inicio) y en la pantalla de bloqueo.
- Pantalla de bloqueo con textos a la izquierda, fondos que cambian solos y animación al volver al Inicio.
- Animación de apertura de apps, ajustes y iconos animados, sonidos nuevos más suaves.

## v2.3
- Tiempo del Inicio sin foco, con la previsión de 5 días.
- Apps ocultas como lista con interruptores; Apps instaladas con menú por app (caché, datos, detener, desinstalar, permisos).
- Pantalla, Sonido y Mi Fire TV dentro de Prisma.
- Quitado "Ajustes completos".

## v2.4
- Fondos con fotos reales (animales, paisajes, lugares del mundo, ciudades) de Wikimedia Commons, que cambian solas con fundido suave.
- Pantalla, Sonido y suspensión funcionan dentro de Prisma; lista de todas las pantallas de ajustes del sistema.

Permisos por ADB (una vez):
    adb shell pm grant dev.prisma.tv android.permission.WRITE_SECURE_SETTINGS
    adb shell appops set dev.prisma.tv WRITE_SETTINGS allow

## v2.5
- Fondos: solo fotos reales de Wikimedia Commons (destacadas y de calidad) con licencia libre (dominio público, CC0, CC BY, CC BY-SA); ciudades, animales, paisajes y maravillas del mundo (Taj Mahal, Machu Picchu, Petra, Coliseo...). Crédito de la foto en la pantalla de bloqueo. La primera foto aparece en cuanto se indexan las primeras (sin esperar).
- Fila de apps del Inicio: el cristal ahora cambia de color con la app enfocada (modo top shelf).
- Pantalla y Sonido: cada opción abre su pantalla de Fire OS; si no existe, la de Android y, si tampoco, los ajustes principales de Fire TV. Añadido "Más ajustes de sonido de Fire TV". Quitada la lista "Pantallas del sistema".

## v2.6
- Pantalla y Sonido: se quitan todas las opciones propias; cada uno abre directamente los ajustes de Fire TV (launcher original), no su pantalla de inicio. Eliminada "Pantallas del sistema".
- Fondo: ahora es una lista por categorías (Mezcla, Animales, Paisajes, Lugares del mundo, Ciudades, Abstractos). Si una categoría aún no tiene fotos descargadas se usan fotos de otra en vez de un fondo azul; búsqueda de fotos con más fuentes de respaldo.
- Top Shelf más discreto: ya no tiñe toda la pantalla; el color de la app solo se nota, suave, en la fila de aplicaciones.

## v2.7
- Top Shelf eliminado (ya no hay color de app ni interruptor).
- Fondos del Inicio y de la pantalla de bloqueo: solo fotos reales (Animales, Paisajes, Lugares del mundo, Ciudades o Mezcla); se quitan los abstractos. Más búsquedas de respaldo, sobre todo para ciudades. Sin fotos descargadas (primera vez sin internet) se ve un fondo liso oscuro.
- Pantalla y Sonido: abren los ajustes de Fire TV (el original); desde ahí se entra en Pantalla y sonidos. Sin pantallas ni opciones propias.
- Mi Fire TV simplificado: nombre, tipo, capacidad, software, almacenamiento e IP; "Liberar RAM" ahora está aquí.
- Arreglado: YouTube (primera app del dock) se quedaba transparente al iniciar; opción de ajustes que quedaba marcada tras cerrar; la pantalla se mantiene siempre encendida para que la pantalla de bloqueo no pase a negro.

## v2.7.1
- Al final del menú de ajustes se muestra la versión instalada ("Prisma TV 2.7.1") para comprobar que se instaló el APK nuevo.

## v2.8
- **APK con firma fija** (`app/debug.keystore`): GitHub Actions firmaba cada compilación con una clave distinta y Android
  rechazaba instalar el APK nuevo encima del viejo (y se seguía viendo la versión vieja). Desde la 2.8 cada APK nuevo se
  instala encima del anterior. Esta vez hay que desinstalar Prisma TV UNA vez (Ajustes > Aplicaciones). El APK sale
  con la versión en el nombre (`PrismaTV-2.8.apk`) y al final de los ajustes de Prisma pone "Prisma TV 2.8".
- **Pantalla y Sonido** (y Wi-Fi / Bluetooth de la barra superior): abren los ajustes ORIGINALES de Fire TV. Fire OS tiene
  pantallas "vacías" que aceptan la orden y no abren nada, así que se prueba cada ruta y se comprueba que de verdad se
  abrió algo; si no, se pasa a la siguiente (y si ninguna funciona se muestra cuáles se probaron).
- **Mi Fire TV** sencillo: nombre, tipo, software y almacenamiento + Liberar RAM, buscar actualizaciones, opciones de
  desarrollador, apps desconocidas y reiniciar. Sin cuenta, versión del inicio, número de serie, MAC, SSID, IP, DNS,
  puerta de enlace ni fecha y hora. Ya no existe "Pantallas del sistema".
- **Fondos** (Inicio y pantalla de bloqueo): nuevo buscador en Wikipedia + Wikimedia Commons; solo fotos reales JPEG
  (sin mapas, logos, dibujos, montajes ni panoramas gigantes) con licencia libre y crédito. Las ciudades usan la foto
  principal de cada ciudad en Wikipedia y búsquedas "<ciudad> skyline" de fotos destacadas/de calidad. Nunca se dibuja un
  fondo falso: si una categoría aún no tiene fotos se queda la anterior. En Ajustes > Fondo se ve cuántas fotos hay de
  cada categoría, el error si lo hay y el botón "Actualizar fotos".
- **Top Shelf** eliminado del todo (sin color de app al seleccionar).
- **YouTube transparente** al iniciar: las tarjetas del dock ya no se animan con transparencia y siempre son opacas
  (si el banner de una app es casi transparente se usa su icono sobre un degradado).
- **Ajustes**: al volver a una página ya no queda ninguna opción marcada por error.
- **Pantalla de bloqueo permanente**: nuevo interruptor "Pantalla siempre encendida" (activado por defecto). Mientras
  Prisma está a la vista no se apaga la pantalla ni entra el salvapantallas de Fire OS. Con estos permisos de ADB (una
  sola vez) también se sube el tiempo del salvapantallas y de la suspensión de Fire OS y se devuelve a su valor al salir:
      adb shell pm grant dev.prisma.tv android.permission.WRITE_SECURE_SETTINGS
      adb shell appops set dev.prisma.tv WRITE_SETTINGS allow
