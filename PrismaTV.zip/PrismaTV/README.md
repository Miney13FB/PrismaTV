# Lumen (antes «Prisma TV»)
Launcher ligero para Fire TV: un solo Inicio (dock + todas las apps), fondo con fotos reales (animales, paisajes,
lugares del mundo y ciudades) o con los fondos oficiales de GTA VI, y Centro de control propio (botón ≡ del mando o el engranaje): Wi-Fi, Bluetooth,
pantalla de bloqueo, tiempo, fondo, apps y Mi Fire TV.

> Desde la 3.0 el launcher se llama **Lumen**. Las notas de las versiones anteriores (más abajo) conservan el nombre
> antiguo. Por dentro no cambia nada de lo que afecta a la instalación (identificador `dev.prisma.tv`, carpeta
> `PrismaTV`, archivo `PrismaTV.zip`, artefacto `PrismaTV-apk`): el APK nuevo se instala encima del anterior y
> conserva todos tus ajustes.

## Cómo compilar (importante)
El compilador de GitHub (el `build.yml` de la RAÍZ del repo) solo descomprime un archivo llamado exactamente **`PrismaTV.zip`**.
Para actualizar: sube este zip con ESE nombre (sustituye al anterior), espera a que Actions salga en verde (✓) y descarga el
artefacto `PrismaTV-apk` de la ejecución más reciente. Los zips con otro nombre (PrismaTV-2.8.zip, etc.) se guardan en el
repo pero NO se compilan: eso hizo que durante varias versiones se siguiera instalando siempre el APK de la 2.4.
Comprobación: al final de los Ajustes de Lumen debe poner la versión ("Lumen 3.7").

Opcional (ADB, una vez) para que Wi-Fi/Bluetooth busquen sin pedir permiso:
  adb shell pm grant dev.prisma.tv android.permission.ACCESS_FINE_LOCATION

Opcional (ADB, después de instalar CADA APK nuevo) para que Lumen vaya más fluido desde el primer momento:
  adb shell cmd package compile -m speed -f dev.prisma.tv
(Si la escribes en una terminal de ADB, como la de Bugjaeger, va sin el «adb shell» del principio.) Android compila las apps a
código nativo por su cuenta, pero lo hace con el aparato en reposo, y Lumen mantiene la pantalla siempre encendida, así que
ese momento puede no llegar nunca y la app se queda ejecutándose «a medias». Esta orden lo hace al momento: tarda unos
segundos y no cambia nada de lo que se ve. Hay que repetirla tras cada instalación (cada APK nuevo empieza sin compilar).

## v3.7 — Cuarta pasada: hilos inactivos y dibujo oculto (sin ningún cambio visual)
Sobre la 3.6: **mismo diseño, mismos efectos y mismos ajustes**. Tras revisar todo el código de principio a fin (hilos,
receptores, animaciones, descargas, dibujo y memoria) queda muy poco por recortar sin tocar lo que se ve; esto es lo último
que se ha encontrado:
- **Los hilos de segundo plano se cierran cuando no hacen nada:** Lumen tiene cuatro (fotos de fondo, iconos de las apps, lista
  de apps y tiempo) y casi siempre estaban parados pero vivos, cada uno con su pila y sus cachés de memoria. Ahora se cierran
  tras 20 segundos sin trabajo y se vuelven a crear solos cuando llega una tarea nueva (cuesta una fracción de milisegundo).
- **El icono del tiempo no se redibuja cuando está oculto:** al ponerse la pantalla de bloqueo, el Inicio se desvanece pero
  Android lo sigue considerando «visible», y los iconos del tiempo del Inicio (hasta doce, con las previsiones de 5 días)
  seguían dibujándose 15 veces por segundo sin que nadie los viera. Ahora se paran mientras están ocultos y se retoman solos
  al volver al Inicio. (Los iconos del tiempo de la propia pantalla de bloqueo, que sí se ven, se mueven igual que antes.)
- Se conserva la misma clave de firma: el APK se instala encima de la 3.6 (o de la 3.5 / 3.4 / 3.3) y mantiene los ajustes.
- Sigue sin activarse R8 (minificación) a propósito: no se puede comprobar el resultado antes de subirlo y un fallo ahí dejaría
  sin APK. Lo más notable que queda es la orden de ADB «compile -m speed» de arriba.

## v3.6 — Tercera pasada de optimización: menos trabajo para la GPU y menos RAM (sin ningún cambio visual)
Sobre la 3.5: **mismo diseño, mismos efectos y mismos ajustes**; no se quita ni se simplifica nada visual ni ninguna opción.
Es una pasada hecha tras revisar las guías de Google y de Amazon para Android TV / Fire TV (memoria, gráficos y compilación).
- **Menos trabajo de la GPU en cada fotograma:** antes cada fotograma pintaba tres capas a pantalla completa una encima de
  otra (el fondo negro de la ventana, el fondo del contenedor y la foto), y las dos primeras quedaban siempre tapadas por la
  foto. Ahora solo se pinta la foto (el color oscuro de antes lo pone ella misma mientras llega la primera, así que al
  arrancar se ve exactamente igual). Además la foto se marca como opaca, de modo que la GPU no la mezcla con lo que hay debajo.
- **La foto de fondo ocupa la mitad de memoria (Android 8 o superior):** una foto normal ocupa 3,7 MB de RAM y, para pintarla,
  la GPU guarda además su propia copia. Ahora la foto se deja solo en la memoria de la GPU (una única copia). Si el aparato no
  lo admite (Fire OS 5 y 6) o algo falla, se usa la foto normal, como en la 3.5.
- **Cargar una foto nueva gasta menos memoria:** el recorte a 16:9 y el ajuste a 1280×720 se hacen en un solo paso (antes se
  hacía una copia intermedia del recorte, de hasta unos 14 MB según la foto, que se soltaba al momento pero subía el pico de
  memoria cada vez que cambiaba el fondo).
- **Icono del tiempo:** su animación (tan lenta que se mueve una fracción de píxel por fotograma) despertaba al procesador 60
  veces por segundo. Ahora lo hace 15 veces, y solo mientras el icono está a la vista. Se ve igual de suave.
- **Ajustes:** al cerrar el panel se sueltan sus subpáginas (la lista de «Apps instaladas» guardaba un icono por cada app
  instalada); se rehacen al entrar, como siempre.
- No se ha activado R8 (minificación) a propósito: no se puede comprobar el resultado antes de subirlo y un fallo ahí dejaría
  sin APK. La orden opcional de ADB (arriba) sigue siendo la mejora de velocidad más notable que queda.
- Se conserva la misma clave de firma: el APK se instala encima de la 3.5 (o de la 3.4 / 3.3) y mantiene todos los ajustes.

## v3.5 — Segunda pasada de optimización (sin ningún cambio visual)
Sobre la 3.4: **mismo diseño, mismos efectos y mismos ajustes**; no se quita ni se simplifica nada visual. Solo se reduce
el trabajo que Lumen hace en el hilo que dibuja la pantalla al volver a Inicio y cuando el sistema avisa de cambios en apps.
- **Al volver a Inicio, sin escrituras al disco:** cada vez que Lumen salía o volvía a la pantalla guardaba un ajuste en el
  disco esperando a que terminara (dos veces por vuelta, aunque no hubiera nada que guardar). Sin los permisos opcionales de
  ADB para el salvapantallas ya no se hace ninguna; con ellos, se hace una y la de salida no espera. Los valores originales
  del salvapantallas se siguen guardando en el disco ANTES de cambiarlos, así que, si Lumen se cerrara de golpe, se devuelven
  igualmente. Tampoco se intenta ya cambiar ajustes sin permiso (cada intento acababa en un error dentro de Android).
- **Avisos de apps:** Fire OS actualiza servicios y apps del sistema en segundo plano y cada una avisa de que se instaló,
  actualizó o quitó. Lumen solo recarga la lista cuando el aviso es de una app que está en Inicio o que tiene icono para
  abrir; el resto se ignora (antes cada aviso releía la lista entera y reconstruía las filas del Inicio, y el foco saltaba
  mientras manejabas el mando). Una app nueva, actualizada o desinstalada se sigue reflejando igual que siempre.
- Orden opcional de ADB (arriba) para compilar Lumen a código nativo al momento.
- Se conserva la misma clave de firma: el APK se instala encima de la 3.4 (o de la 3.3) y mantiene todos los ajustes.

## v3.4 — Versión final: solo correcciones y optimización
Sobre la 3.3, **sin ningún cambio visual ni funciones nuevas**: mismo diseño, mismos efectos y mismos ajustes. Solo se arreglan
fallos y se aligera el trabajo que Lumen hace en segundo plano.
- **Fallos corregidos:**
  - Al salir de Lumen (por ejemplo, al abrir una app) podían quedar programados el temporizador de la pantalla de bloqueo y el
    cambio automático de fondos. Ahora se paran al salir y no se reanudan hasta volver.
  - Instalar, actualizar o desinstalar una app mientras Lumen estaba en segundo plano no se reflejaba al volver (la lista solo
    se avisaba si Lumen estaba delante). Ahora Lumen escucha esos cambios todo el tiempo y la lista se actualiza.
  - Un error raro dentro de una tarea de segundo plano (crear una tarjeta, leer la lista de apps, el tiempo, los iconos)
    podía cerrar Lumen entero, y sin Lumen el Fire TV se queda sin Inicio. Ahora esas tareas están protegidas: lo peor que
    puede pasar es que esa tarjeta o ese dato no se actualice.
  - «Info» en el menú de una app (mantener OK) abre su ficha por la ruta comprobada de Fire OS, con la de respaldo de siempre
    (antes lanzaba una orden normal de Android que en Fire OS puede dejar una pantalla vacía).
  - La lista de Wi-Fi se reconstruía entera en cada aviso del sistema y la fila enfocada volvía a empezar su animación. Ahora
    solo se reconstruye cuando cambia algo de lo que se ve (redes, señal o conexión).
  - La lista de «Apps instaladas» podía salir duplicada si se salía de la página y se volvía a entrar enseguida.
  - «Liberar RAM» ya no deja la pantalla parada mientras avisa al sistema app por app.
  - Buscar una ciudad y cerrar Lumen antes de que contestara podía cerrarlo al intentar enseñar la lista de resultados.
  - El tiempo dejaba abierta la conexión cuando el servidor contestaba con un error, y cada vez que se abría Lumen quedaba un
    hilo parado para siempre.
- **Optimización:**
  - Todo el trabajo en segundo plano (fotos, iconos, tarjetas, tiempo, listas) va con la prioridad baja que usa Android para
    sus propias tareas: el procesador es siempre primero para el mando y las animaciones.
  - El buscador de fondos ya no se crea en el hilo principal (leía su índice del disco justo al abrir).
  - Descargas de fondos más prudentes: tras un límite de peticiones o un bloqueo temporal (429, 503, 403) no se insiste a ese
    servidor durante 5 minutos, y la lista de GTA VI no se vuelve a leer de la web de Rockstar más de una vez cada 10 minutos,
    aunque alguna de sus direcciones falle.
  - Menos trabajo repetido: la fecha del reloj se calcula una vez por actualización, y una tarjeta cuyo icono no se deja
    dibujar sale igualmente.
- Se conserva la misma clave de firma: el APK se instala encima de la 3.3 y mantiene todos los ajustes.

## v3.3 — Sobre la 3.1: Bluetooth fijo, sin sonidos, fondos oficiales de GTA VI y optimización
Parte de la **3.1** (la 3.2 queda descartada: no lleva su tienda de sonidos, ni la placa del tiempo, ni las animaciones
nuevas). Diseño, estructura y efectos visuales: exactamente los de la 3.1.
- **Bluetooth siempre encendido:** ya no hay interruptor. En Ajustes → Bluetooth la fila de arriba solo informa («Siempre
  activado») y, si algo lo apagara, Lumen lo vuelve a encender enseguida (el mando del Fire TV funciona por Bluetooth).
- **Sin sonidos:** se quitan todos los sonidos del launcher (menú, mover el foco, abrir/cerrar, interruptores, bloqueo…) y
  el ajuste «Sonidos». Tampoco suena el «clic» de navegación del sistema. Los archivos de sonido que dejaron las versiones
  anteriores en la caché se borran solos, una sola vez.
- **Fondos oficiales de GTA VI:** nueva categoría en Ajustes → Fondo → «GTA VI · Oficial». Son los fondos que Rockstar Games
  ofrece en su página oficial (rockstargames.com/VI → Artwork & Wallpapers). No van dentro de Lumen: se descargan de la web
  de Rockstar (solo se guarda el que se ve y el siguiente, como con las fotos) y sirven para el Inicio y la pantalla de
  bloqueo, que muestra «Arte oficial: Rockstar Games · …». La lista se vuelve a leer de la página oficial una vez al día (los
  nombres de archivo cambian si Rockstar actualiza la web); si no se puede leer, usa la lista que ya tenía. Las imágenes son
  de Rockstar Games.
- **Optimización sin perder ningún efecto ni nada visual:**
  - El APK se compila **sin modo depurable** (lo más importante: una app depurable va con el código del sistema
    desoptimizado y es mucho más lenta). Contrapartida: ya no se puede «bajar» a una versión anterior encima con
    `adb install -d`; para volver atrás hay que desinstalar antes.
  - Sin motor de sonidos (nada que sintetizar al arrancar ni en memoria).
  - Los iconos animados del tiempo solo se animan mientras se ven, a 30 fotogramas por segundo (se mueven menos de 2 px/s).
  - Las tarjetas del tiempo solo se reconstruyen cuando cambia el tiempo (antes, en cada vuelta a Lumen).
  - La barra superior (Wi-Fi, Bluetooth) solo se actualiza cuando algo cambia, no en cada aviso de señal.
  - Las animaciones de foco/pulsación reutilizan sus interpoladores en vez de crear uno nuevo en cada pulsación.
  - Las fotos se bajan directamente al archivo, sin guardarlas enteras en memoria.

## v3.1 — Pulido, foco del mando y sonidos
Versión de limpieza y de estabilidad: el diseño, la estructura y todo lo visual siguen igual; lo que cambia es cómo
responde el mando, cómo se mezclan los fondos y cómo suena.
- **Opciones quitadas (siempre en su mejor valor):**
  - «Pantalla siempre encendida»: ya no es un ajuste, la pantalla se mantiene encendida mientras Lumen está a la vista.
  - **Fahrenheit** fuera (ajustes del tiempo y bienvenida): solo °C.
  - «Nombre del dispositivo» fuera de Mi Fire TV («Tu nombre», el que usa Lumen para saludarte, se queda).
- **Mando y foco (arreglo de fondo, no un parche):**
  - **Mi Fire TV → Ajustes generales** ya no deja el panel «a medias»: al cambiar de página el foco pasa a la fila nueva
    *antes* de ocultar la anterior, y las capas a pantalla completa y los contenedores de scroll ya no pueden quedarse con
    el foco. Al volver, el foco cae en la fila desde la que se entró.
  - Si por cualquier motivo el foco se perdiera, la siguiente flecha lo repone en una opción visible (en Inicio, en el menú
    de una app y en cada página de los ajustes) en vez de quedarse sin responder.
  - Las listas que se reconstruyen solas (Wi-Fi, Bluetooth, tiempo, fondo) conservan la fila enfocada (o la que ocupa su sitio).
  - **Inicio:** subir a la barra superior (Bluetooth, Wi-Fi, Ajustes) ya funciona a la primera; antes la primera pulsación
    la «gastaba» el scroll del Inicio.
- **Fondos:** el cambio de foto es un fundido limpio (sin parpadeos ni solapes): el cristal de los paneles se mezcla con el
  mismo reloj que la foto, solo hay una transición pendiente a la vez y la foto nueva llega ya preparada en la GPU. La deriva
  lenta de la foto se mueve ahora a 5 Hz (casi igual de suave, mucho menos trabajo).
- **Animaciones, más y más ligeras (solo opacidad, escala y desplazamiento):** las páginas de ajustes entran en cascada
  (más rápida) desde el lado por el que llegas, el panel y los menús de app tienen salida suave además de entrada (los menús
  «brotan» con un pequeño zoom), y los botones se hunden un poco al pulsar OK. Todo se corta solo a los 0,6 s si algo
  quedara a medias.
- **Sonidos rehechos:** se generan una sola vez al arrancar (se guardan en la caché), suenan más suaves y con pequeñas
  variaciones de tono para que el «tic» de moverse no canse; el sonido va a la vez que su animación (abrir/cerrar panel,
  menú, activar/desactivar, desbloquear). El clic del sistema que sonaba encima ya no suena. «Sonidos» sigue apagándolos todos.
- **Limpieza:** menos código repetido y sin usar (clases, funciones, textos y ajustes sin uso), y menos trabajo en segundo plano.

## v3.0 — Lumen
- **Nuevo nombre: Lumen.** «Prisma» tenía sentido con el diseño colorido del principio; con el cristal de ahora ya no
  encajaba. Cambio solo visual: nombre de la app, textos, icono, banner y bienvenida. La lógica y la estructura interna
  siguen igual (por eso el identificador, los nombres de archivo y los ajustes guardados no cambian).
- **Logo nuevo** (icono y banner del Fire TV): una lente de cristal con luz propia y un destello fino y horizontal, como el
  de una cámara de cine. Se dibuja por código en la bienvenida (`LumenMark`) y existe como imagen para el icono y el banner.
- **Bienvenida renovada** con la misma estética: un fondo de resplandores fríos con motas de luz que suben despacio; la
  lente se enciende desde un punto de luz, el nombre aparece espaciado como en un título de cine y el saludo va cambiando
  de idioma. Pasos: saludo → tu nombre → tu ciudad (tiempo, °C/°F, tiempo en Inicio) → «Todo listo», donde la lente
  estalla en una onda de luz al entrar. Se maneja con las flechas, OK y Atrás.
  - Se **quita la elección de fondo** de la bienvenida (el fondo de fotos se gestiona solo).
  - Sale **una vez** al instalar la 3.0 (con tu nombre y tu ciudad ya puestos) y no vuelve a salir.
- **Botones que sobraban, fuera:** «Actualizar fotos» y «Borrar fotos descargadas» (la app ya busca, cambia y borra las
  fotos sola) y «Ver la bienvenida».
- **Mi Fire TV:** ahora incluye «Tu nombre» (escribirlo o cambiarlo), además del nombre del dispositivo, tipo, software,
  almacenamiento, «Liberar RAM», «Todos los ajustes» y «Reiniciar».
- **Apps instaladas:** al elegir una app se abre directamente su ficha en los ajustes originales de Fire TV (y un aviso dice
  dónde está si Amazon solo deja abrir los ajustes principales). Se quitan las acciones propias que no funcionaban (borrar
  caché, datos, detener, desinstalar).
- **Opciones quitadas por no funcionar:** Pantalla, Sonido, Control de equipo, Opciones de desarrollador e Instalación de
  aplicaciones desconocidas. «Todos los ajustes» se mantiene como acceso principal a los ajustes originales.
- **Reiniciar, corregido.** En 2.8/2.9 el botón intentaba reiniciar directamente; Fire OS solo permite eso a las apps de
  Amazon (el permiso de reinicio es de sistema) y, al fallar, la pantalla de respaldo ya no se abría. Ahora Lumen avisa con
  un mensaje y abre el botón «Reiniciar» de los ajustes originales (Mi Fire TV) probando varias rutas, hasta la pantalla
  principal de ajustes si Amazon bloquea el resto. Si algún equipo concede el permiso, pregunta y reinicia al momento.
- Se declara el permiso `REBOOT` en el manifiesto (el sistema solo lo concede a apps de Amazon: en un Fire TV normal no tiene
  ningún efecto, pero el botón lo comprueba antes de intentar nada).

Permisos opcionales por ADB (una vez), para que la pantalla no se apague nunca mientras Lumen está a la vista:
    adb shell pm grant dev.prisma.tv android.permission.WRITE_SECURE_SETTINGS
    adb shell appops set dev.prisma.tv WRITE_SETTINGS allow

## v2.1
- Ajustes propios estilo iPhone (interruptores verdes/grises): Wi-Fi, Bluetooth, pantalla de bloqueo, tiempo, dispositivo.
- Bluetooth junto al Wi-Fi en la barra superior; búsqueda y conexión corregidas.
- El tiempo por ciudad (opcional en Inicio) con Open-Meteo, sin claves.
- Pantalla de bloqueo con hora, fecha, nombre y tiempo tras unos minutos sin usar el mando.
- Quitados logo, animaciones y volumen.

Permisos opcionales por ADB:
    adb shell pm grant dev.prisma.tv android.permission.ACCESS_FINE_LOCATION
    adb shell settings put secure location_mode 3

## v2.2
- 12 fondos nuevos (colores, animales y lugares del mundo) con cambio suave entre fondos.
- Tiempo con los próximos 5 días (pulsa una tarjeta del Inicio) y en la pantalla de bloqueo.
- Pantalla de bloqueo con textos a la izquierda, fondos que cambian solos y animación al volver al Inicio.
- Animación de apertura de apps, ajustes y iconos animados, sonidos nuevos más suaves.

## v2.3
- Tiempo del Inicio sin foco, con la previsión de 5 días.
- Apps ocultas como lista con interruptores; Apps instaladas con menú por app (caché, datos, detener, desinstalar, permisos).
- Pantalla, Sonido y Mi Fire TV dentro de Prisma.
- Quitado "Ajustes completos".

## v2.4
- Fondos con fotos reales (animales, paisajes, lugares del mundo, ciudades) de Wikimedia Commons, que cambian solas con fundido suave.
- Pantalla, Sonido y suspensión funcionan dentro de Prisma; lista de todas las pantallas de ajustes del sistema.

## v2.5
- Fondos: solo fotos reales de Wikimedia Commons (destacadas y de calidad) con licencia libre (dominio público, CC0, CC BY, CC BY-SA); ciudades, animales, paisajes y maravillas del mundo (Taj Mahal, Machu Picchu, Petra, Coliseo...). Crédito de la foto en la pantalla de bloqueo. La primera foto aparece en cuanto se indexan las primeras (sin esperar).
- Fila de apps del Inicio: el cristal ahora cambia de color con la app enfocada (modo top shelf).
- Pantalla y Sonido: cada opción abre su pantalla de Fire OS; si no existe, la de Android y, si tampoco, los ajustes principales de Fire TV. Añadido "Más ajustes de sonido de Fire TV". Quitada la lista "Pantallas del sistema".

## v2.6
- Pantalla y Sonido: se quitan todas las opciones propias; cada uno abre directamente los ajustes de Fire TV (launcher original), no su pantalla de inicio. Eliminada "Pantallas del sistema".
- Fondo: ahora es una lista por categorías (Mezcla, Animales, Paisajes, Lugares del mundo, Ciudades, Abstractos). Si una categoría aún no tiene fotos descargadas se usan fotos de otra en vez de un fondo azul; búsqueda de fotos con más fuentes de respaldo.
- Top Shelf más discreto: ya no tiñe toda la pantalla; el color de la app solo se nota, suave, en la fila de aplicaciones.

## v2.7
- Top Shelf eliminado (ya no hay color de app ni interruptor).
- Fondos del Inicio y de la pantalla de bloqueo: solo fotos reales (Animales, Paisajes, Lugares del mundo, Ciudades o Mezcla); se quitan los abstractos. Más búsquedas de respaldo, sobre todo para ciudades. Sin fotos descargadas (primera vez sin internet) se ve un fondo liso oscuro.
- Pantalla y Sonido: abren los ajustes de Fire TV (el original); desde ahí se entra en Pantalla y sonidos. Sin pantallas ni opciones propias.
- Mi Fire TV simplificado: nombre, tipo, capacidad, software, almacenamiento e IP; "Liberar RAM" ahora está aquí.
- Arreglado: YouTube (primera app del dock) se quedaba transparente al iniciar; opción de ajustes que quedaba marcada tras cerrar; la pantalla se mantiene siempre encendida para que la pantalla de bloqueo no pase a negro.

## v2.7.1
- Al final del menú de ajustes se muestra la versión instalada para comprobar que se instaló el APK nuevo.

## v2.8
- **APK con firma fija** (`app/debug.keystore`): GitHub Actions firmaba cada compilación con una clave distinta y Android
  rechazaba instalar el APK nuevo encima del viejo (y se seguía viendo la versión vieja). Desde la 2.8 cada APK nuevo se
  instala encima del anterior.
- **Pantalla y Sonido** (y Wi-Fi / Bluetooth de la barra superior): abren los ajustes ORIGINALES de Fire TV. Fire OS tiene
  pantallas "vacías" que aceptan la orden y no abren nada, así que se prueba cada ruta y se comprueba que de verdad se
  abrió algo; si no, se pasa a la siguiente (y si ninguna funciona se muestra cuáles se probaron).
- **Mi Fire TV** sencillo: nombre, tipo, software y almacenamiento + Liberar RAM, buscar actualizaciones, opciones de
  desarrollador, apps desconocidas y reiniciar.
- **Fondos** (Inicio y pantalla de bloqueo): nuevo buscador en Wikipedia + Wikimedia Commons; solo fotos reales JPEG
  (sin mapas, logos, dibujos, montajes ni panoramas gigantes) con licencia libre y crédito. Las ciudades usan la foto
  principal de cada ciudad en Wikipedia y búsquedas "<ciudad> skyline" de fotos destacadas/de calidad. Nunca se dibuja un
  fondo falso: si una categoría aún no tiene fotos se queda la anterior.
- **Top Shelf** eliminado del todo (sin color de app al seleccionar).
- **YouTube transparente** al iniciar: las tarjetas del dock ya no se animan con transparencia y siempre son opacas
  (si el banner de una app es casi transparente se usa su icono sobre un degradado).
- **Pantalla de bloqueo permanente**: interruptor "Pantalla siempre encendida" (activado por defecto). Mientras
  Lumen está a la vista no se apaga la pantalla ni entra el salvapantallas de Fire OS.

## v2.9
- **Bienvenida y configuración inicial** (solo la primera vez): saludo con logo, tu nombre, tu ciudad para el tiempo, tus
  fondos de fotos y «Todo listo». Al terminar queda guardado y no vuelve a salir; si algo fallara dentro de ella se salta
  sola y entra al Inicio.
- **Fondos con poco espacio**: solo se guarda en el Fire TV la foto que se ve y la siguiente; al cambiar de foto se borra
  la anterior y se descarga la que viene (nunca se acumulan).
- **Reloj siempre en 24 horas**: quitada la opción 12/24 h.
- «Buscar actualizaciones» se llama ahora **«Todos los ajustes»**: abre los ajustes completos de Fire TV. Mantén pulsado OK
  en esa fila para ver un informe de qué pantallas de Amazon deja abrir tu Fire TV (útil para depurar).
- Arreglado un texto duplicado en los recursos que habría impedido compilar en GitHub y un apóstrofe sin escapar en la
  traducción inglesa.
