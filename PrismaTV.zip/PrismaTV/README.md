# Prisma TV
Launcher ligero para Fire TV Stick (Fire OS 5+). Cristal estilo tvOS, Inicio con dock, pestañas Inicio/Apps/Ajustes,
barra superior con Wi-Fi y ajustes, reloj en reposo y ajustes rápidos. Sin librerías, sin anuncios, sin analítica.

## Compilar el APK (sin instalar nada)
1. Crea un repositorio en GitHub y sube todo el contenido de esta carpeta (incluida `.github`).
2. Pestaña Actions -> "Compilar APK" -> espera ~3 min -> descarga el artefacto `PrismaTV-apk`.
3. Instala el `app-debug.apk` en el Fire TV (Downloader/ADB).

## Usarlo como inicio
Home on Fire (como ya tienes con Glass): elige Prisma TV como launcher.
