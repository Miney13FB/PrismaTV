# Prisma TV 2
Launcher ligero para Fire TV: un solo Inicio (dock + todas las apps), fondo que toma el color de cada app,
y Centro de control propio (botón ≡ del mando o el engranaje): Wi-Fi, Bluetooth, volumen, RAM, fondos y atajos.

Opcional (ADB, una vez) para que Wi-Fi/Bluetooth busquen sin pedir permiso:
  adb shell pm grant dev.prisma.tv android.permission.ACCESS_FINE_LOCATION

## v2.1
- Ajustes propios estilo iPhone (interruptores verdes/grises): Wi-Fi, Bluetooth, pantalla de bloqueo, tiempo, dispositivo.
- Bluetooth junto al Wi-Fi en la barra superior; búsqueda y conexión corregidas.
- El tiempo por ciudad (opcional en Inicio) con Open-Meteo, sin claves.
- Pantalla de bloqueo con hora, fecha, nombre y tiempo tras unos minutos sin usar el mando.
- Quitados logo, animaciones y volumen.

Permisos opcionales por ADB:
    adb shell pm grant dev.prisma.tv android.permission.ACCESS_FINE_LOCATION
    adb shell settings put secure location_mode 3

## v2.2
- 12 fondos nuevos (colores, animales y lugares del mundo) con cambio suave entre fondos.
- Tiempo con los próximos 5 días (pulsa una tarjeta del Inicio) y en la pantalla de bloqueo.
- Pantalla de bloqueo con textos a la izquierda, fondos que cambian solos y animación al volver al Inicio.
- Animación de apertura de apps, ajustes y iconos animados, sonidos nuevos más suaves.
