# Prisma TV 2
Launcher ligero para Fire TV: un solo Inicio (dock + todas las apps), fondo que toma el color de cada app,
y Centro de control propio (botón ≡ del mando o el engranaje): Wi-Fi, Bluetooth, volumen, RAM, fondos y atajos.

Opcional (ADB, una vez) para que Wi-Fi/Bluetooth busquen sin pedir permiso:
  adb shell pm grant dev.prisma.tv android.permission.ACCESS_FINE_LOCATION
