package dev.prisma.tv;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** Icono del tiempo dibujado por código a partir del código meteorológico WMO. */
final class WxView extends View {
    private int code = -1;
    private boolean day = true;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF r = new RectF();
    private float ph;
    private ValueAnimator anim;
    private long drawn;

    /**
     * El movimiento del icono (el vaivén, los rayos del sol, la lluvia) es de 5 segundos por vuelta y de menos de dos
     * píxeles por segundo: con 30 fotogramas por segundo se ve igual de suave que con 60. Además el reloj solo corre
     * mientras el icono se ve de verdad (en pantalla y con la ventana visible); oculto no gasta nada.
     */
    private void sync() {
        boolean run = isAttachedToWindow() && isShown() && getWindowVisibility() == VISIBLE;
        if (run) {
            if (anim == null) {
                anim = ValueAnimator.ofFloat(0f, 1f);
                anim.setDuration(5000);
                anim.setRepeatCount(ValueAnimator.INFINITE);
                anim.setInterpolator(new LinearInterpolator());
                anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override
                    public void onAnimationUpdate(ValueAnimator a) {
                        long now = SystemClock.uptimeMillis();
                        if (now - drawn < 30) return;
                        drawn = now;
                        ph = (now % 5000L) / 5000f;
                        invalidate();
                    }
                });
            }
            if (!anim.isStarted()) anim.start();
        } else if (anim != null && anim.isStarted()) {
            anim.cancel();
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        sync();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (anim != null && anim.isStarted()) anim.cancel();
    }

    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        sync();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        sync();
    }

    WxView(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
    }

    void set(int code, boolean day) {
        this.code = code;
        this.day = day;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float s = Math.min(getWidth(), getHeight());
        c.save();
        c.translate((getWidth() - s) / 2f, (getHeight() - s) / 2f);
        if (code != 0) c.translate((float) Math.sin(ph * 2 * Math.PI) * s * 0.03f, 0f);
        if (code < 0) {
            drawCloud(c, s, 0x66FFFFFF);
        } else if (code == 0) {
            sunOrMoon(c, s, 0.5f, 0.5f, 0.24f);
        } else if (code == 1 || code == 2) {
            sunOrMoon(c, s, 0.38f, 0.36f, 0.18f);
            drawCloud(c, s, 0xFFF2F4F8);
        } else if (code == 3) {
            drawCloud(c, s, 0xFFDDE2EA);
        } else if (code == 45 || code == 48) {
            drawCloud(c, s, 0xCCDDE2EA);
            stroke.setColor(0xCCFFFFFF);
            stroke.setStrokeWidth(s * 0.05f);
            c.drawLine(s * 0.22f, s * 0.78f, s * 0.78f, s * 0.78f, stroke);
            c.drawLine(s * 0.30f, s * 0.88f, s * 0.70f, s * 0.88f, stroke);
        } else if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) {
            drawCloud(c, s, 0xFFC9D1DD);
            stroke.setColor(0xFF5AC8FA);
            stroke.setStrokeWidth(s * 0.05f);
            for (int i = 0; i < 3; i++) {
                float x = s * (0.32f + i * 0.17f);
                float dy = ((ph * 2f + i / 3f) % 1f) * s * 0.07f;
                stroke.setAlpha(255 - (int) (dy / (s * 0.07f) * 150));
                c.drawLine(x, s * 0.72f + dy, x - s * 0.05f, s * 0.84f + dy, stroke);
            }
        } else if ((code >= 71 && code <= 77) || code == 85 || code == 86) {
            drawCloud(c, s, 0xFFDDE2EA);
            p.setColor(0xFFFFFFFF);
            for (int i = 0; i < 3; i++) {
                c.drawCircle(s * (0.32f + i * 0.17f), s * (0.80f + (i % 2) * 0.06f), s * 0.035f, p);
            }
        } else if (code >= 95) {
            drawCloud(c, s, 0xFF9AA3B2);
            p.setColor(0xFFFFD60A);
            path.reset();
            path.moveTo(s * 0.54f, s * 0.62f);
            path.lineTo(s * 0.42f, s * 0.80f);
            path.lineTo(s * 0.52f, s * 0.80f);
            path.lineTo(s * 0.46f, s * 0.96f);
            path.lineTo(s * 0.64f, s * 0.74f);
            path.lineTo(s * 0.53f, s * 0.74f);
            path.close();
            c.drawPath(path, p);
        } else {
            drawCloud(c, s, 0xFFDDE2EA);
        }
        c.restore();
    }

    private void sunOrMoon(Canvas c, float s, float cx, float cy, float rad) {
        if (day) {
            p.setColor(0xFFFFD60A);
            c.drawCircle(s * cx, s * cy, s * rad * 0.62f, p);
            stroke.setColor(0xFFFFD60A);
            stroke.setStrokeWidth(s * 0.045f);
            c.save();
            c.translate(s * cx, s * cy);
            c.rotate(ph * 45f);
            for (int i = 0; i < 8; i++) {
                c.drawLine(0, -s * rad * 0.82f, 0, -s * rad * 1.08f, stroke);
                c.rotate(45f);
            }
            c.restore();
        } else {
            p.setColor(0xFFE8ECF4);
            c.drawCircle(s * cx, s * cy, s * rad * 0.85f, p);
            p.setColor(0xFF202638);
            c.drawCircle(s * (cx + 0.10f), s * (cy - 0.06f), s * rad * 0.78f, p);
        }
    }

    private void drawCloud(Canvas c, float s, int color) {
        p.setColor(color);
        c.drawCircle(s * 0.38f, s * 0.58f, s * 0.15f, p);
        c.drawCircle(s * 0.56f, s * 0.50f, s * 0.19f, p);
        c.drawCircle(s * 0.72f, s * 0.60f, s * 0.13f, p);
        r.set(s * 0.26f, s * 0.58f, s * 0.80f, s * 0.73f);
        c.drawRoundRect(r, s * 0.07f, s * 0.07f, p);
    }
}
