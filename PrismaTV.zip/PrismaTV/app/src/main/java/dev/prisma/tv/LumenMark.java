package dev.prisma.tv;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.LinearInterpolator;

/**
 * Logo de Lumen, dibujado por código: una lente de cristal con luz propia en el centro y un destello fino y horizontal,
 * como el de una cámara de cine. Puede dibujarse quieto o con vida: el brillo del borde se mueve despacio y el núcleo
 * «respira»; al aparecer se enciende desde un punto de luz y, al terminar la bienvenida, estalla en una onda.
 */
final class LumenMark extends View {
    private final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint core = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint spec = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint caustic = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint flare = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint wave = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint burst = new Paint(Paint.ANTI_ALIAS_FLAG);

    private float built = -1f;          // tamaño para el que están hechos los degradados
    private float t;                    // tiempo de la animación suave (0..1 cada 24 s)
    private float lit = 1f;             // 0..1: se enciende al aparecer (1 = ya encendida)
    private float bloom;                // 0..1: estallido final (0 = no hay)
    private boolean wantIdle;
    private ValueAnimator idle;
    private ValueAnimator lighting;
    private ValueAnimator blooming;

    LumenMark(Context c) {
        super(c);
        rim.setStyle(Paint.Style.STROKE);
        spec.setStyle(Paint.Style.STROKE);
        caustic.setStyle(Paint.Style.STROKE);
        wave.setStyle(Paint.Style.STROKE);
        wave.setColor(0xFFFFFFFF);
    }

    // ------------------------------------------------------------------ animación

    /** Brillo del borde y núcleo con vida (mientras el logo está a la vista). */
    void setIdle(boolean on) {
        wantIdle = on;
        sync();
    }

    private void sync() {
        boolean run = wantIdle && isAttachedToWindow() && getWindowVisibility() == View.VISIBLE;
        if (run && idle == null) {
            idle = ValueAnimator.ofFloat(0f, 1f);
            idle.setDuration(24000);
            idle.setInterpolator(new LinearInterpolator());
            idle.setRepeatCount(ValueAnimator.INFINITE);
            idle.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator va) {
                    t = (Float) va.getAnimatedValue();
                    invalidate();
                }
            });
            idle.start();
        } else if (!run && idle != null) {
            idle.cancel();
            idle = null;
        }
    }

    /** Se enciende desde un punto de luz (lente, destello y una onda). {@code delay} en milisegundos. */
    void ignite(long delay) {
        if (lighting != null) lighting.cancel();
        lit = 0f;
        invalidate();
        lighting = ValueAnimator.ofFloat(0f, 1f);
        lighting.setStartDelay(delay);
        lighting.setDuration(1700);
        lighting.setInterpolator(new LinearInterpolator());
        lighting.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator va) {
                lit = (Float) va.getAnimatedValue();
                invalidate();
            }
        });
        lighting.start();
    }

    /** Estallido final: la luz se expande en una onda y el logo se desvanece. */
    void bloom() {
        if (blooming != null) return;
        blooming = ValueAnimator.ofFloat(0f, 1f);
        blooming.setDuration(560);
        blooming.setInterpolator(new AccelerateDecelerateInterpolator());
        blooming.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator va) {
                bloom = (Float) va.getAnimatedValue();
                invalidate();
            }
        });
        blooming.start();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        sync();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        sync();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (idle != null) {
            idle.cancel();
            idle = null;
        }
        if (lighting != null) {
            lighting.cancel();
            lighting = null;
        }
        if (blooming != null) {
            blooming.cancel();
            blooming = null;
        }
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ dibujo

    private static float clamp(float v) {
        return v < 0f ? 0f : (v > 1f ? 1f : v);
    }

    private static float smooth(float a, float b, float x) {
        float k = clamp((x - a) / (b - a));
        return k * k * (3f - 2f * k);
    }

    private static int argb(float a, int r, int g, int b) {
        return (Math.round(clamp(a) * 255f) << 24) | (r << 16) | (g << 8) | b;
    }

    /** Degradados que dependen del tamaño: se rehacen solo cuando cambia. */
    private void build(float s) {
        built = s;
        float cx = s / 2f, cy = s / 2f, r = 0.27f * s;
        halo.setShader(new RadialGradient(cx, cy, 0.5f * s,
                new int[]{0x5A78AFFF, 0x3A548CFF, 0x103C6EFF, 0x00325AF0},
                new float[]{0f, r / (0.5f * s), 0.7f, 1f}, Shader.TileMode.CLAMP));
        body.setShader(new RadialGradient(cx, cy, r,
                new int[]{0xFFFFFFFF, 0xFCF0F8FF, 0xF0A0D0FF, 0xE84C80EE, 0xEC1E388C, 0xF7101E54},
                new float[]{0f, 0.14f, 0.34f, 0.58f, 0.84f, 1f}, Shader.TileMode.CLAMP));
        core.setShader(new RadialGradient(cx, cy, 0.40f * r,
                new int[]{0xB3FFFFFF, 0x4DFFFFFF, 0x00FFFFFF}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        burst.setShader(new RadialGradient(cx, cy, r,
                new int[]{0xFFFFFFFF, 0x99DCEEFF, 0x00B4D2FF}, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));

        // borde: brillo en el ángulo 0 del degradado (se gira con el lienzo)
        int n = 17;
        int[] rc = new int[n];
        float[] rp = new float[n];
        for (int i = 0; i < n; i++) {
            float p = i / (float) (n - 1);
            float dd = 2f * Math.min(p, 1f - p);
            float k = 1f - smooth(0f, 1f, dd);
            float al = (46f + 209f * (float) Math.pow(k, 1.6f)) / 255f;
            rc[i] = argb(al, 255, 255, 255);
            rp[i] = p;
        }
        rim.setShader(new SweepGradient(cx, cy, rc, rp));
        rim.setStrokeWidth(Math.max(1.5f, 0.0144f * s));

        // brillo especular: un arco corto arriba a la izquierda
        float half = 22f / 360f;
        spec.setShader(new SweepGradient(cx, cy, new int[]{0xCCFFFFFF, 0x00FFFFFF, 0x00FFFFFF, 0xCCFFFFFF},
                new float[]{0f, half, 1f - half, 1f}));
        spec.setStrokeWidth(Math.max(1.5f, 0.015f * s));

        // cáustica: la luz que atraviesa el cristal, abajo a la derecha
        float ch = 62f / 360f;
        caustic.setShader(new SweepGradient(cx, cy, new int[]{0x33B2E0FF, 0x00B2E0FF, 0x00B2E0FF, 0x33B2E0FF},
                new float[]{0f, ch, 1f - ch, 1f}));

        // destello horizontal: línea fina que se apaga hacia los extremos y brillo difuso a su alrededor
        float half2 = 0.42f * s;
        int m = 9;
        int[] lc = new int[m];
        float[] lp = new float[m];
        for (int i = 0; i < m; i++) {
            float p = i / (float) (m - 1);
            float x = (p - 0.5f) * 4f;
            lc[i] = argb(0.95f * (float) Math.exp(-x * x), 0xDB, 0xEE, 0xFF);
            lp[i] = p;
        }
        line.setShader(new LinearGradient(cx - half2, 0, cx + half2, 0, lc, lp, Shader.TileMode.CLAMP));
        flare.setShader(new RadialGradient(cx, cy, 0.32f * s, new int[]{0x3DDCEEFF, 0x00DCEEFF}, null,
                Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas c) {
        float s = Math.min(getWidth(), getHeight());
        if (s <= 0f) return;
        if (built != s) build(s);
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float r = 0.27f * s;

        // tiempo de vida del logo
        float breathe = 0.5f + 0.5f * (float) Math.sin(t * 6.2831853f * 6f);          // cada 4 s
        float sway = 32f * (float) Math.sin(t * 6.2831853f * 2.667f);                 // el brillo del borde se mueve ±32°
        float phase = 228f + sway;

        // encendido: lente (0–45 %), destello (20–70 %), onda (22–100 %)
        float discK = 1f;
        float discA = 1f;
        float flareK = 1f;
        float waveP = 0f;
        if (lit < 1f) {
            float p1 = clamp(lit / 0.45f);
            float e = 1f - (1f - p1) * (1f - p1);
            discK = p1 <= 0f ? 0.02f : (0.12f + 0.88f * e) + 0.06f * (float) Math.sin(p1 * 3.1415927f);
            discA = clamp(p1 * 1.6f);
            float p2 = clamp((lit - 0.20f) / 0.50f);
            flareK = 1f - (1f - p2) * (1f - p2) * (1f - p2);
            waveP = clamp((lit - 0.22f) / 0.78f);
        }
        float fade = 1f - smooth(0.55f, 1f, bloom);
        float grow = 1f + 0.30f * (1f - (1f - bloom) * (1f - bloom));
        int layerA = Math.round(255f * discA * fade);
        if (layerA <= 0 && waveP <= 0f && bloom <= 0f) return;

        c.save();
        c.scale(discK * grow, discK * grow, cx, cy);

        // resplandor exterior
        halo.setAlpha(Math.round(layerA * (0.82f + 0.18f * breathe)));
        c.drawCircle(cx, cy, 0.5f * s, halo);

        // lente de cristal
        body.setAlpha(layerA);
        c.drawCircle(cx, cy, r, body);

        // núcleo de luz (respira)
        core.setAlpha(Math.round(layerA * (0.62f + 0.38f * breathe)));
        c.save();
        float ck = 1f + 0.10f * breathe;
        c.scale(ck, ck, cx, cy);
        c.drawCircle(cx, cy, 0.40f * r, core);
        c.restore();

        // cáustica
        caustic.setAlpha(layerA);
        c.save();
        c.rotate(50f, cx, cy);
        for (int i = 0; i < 3; i++) {
            float w = (i == 0 ? 0.17f : (i == 1 ? 0.11f : 0.05f)) * r;
            caustic.setStrokeWidth(w);
            c.drawCircle(cx, cy, 0.84f * r, caustic);
        }
        c.restore();

        // borde de cristal
        float rw = rim.getStrokeWidth();
        rim.setAlpha(layerA);
        c.save();
        c.rotate(phase, cx, cy);
        c.drawCircle(cx, cy, r - rw / 2f, rim);
        c.restore();

        // brillo especular (fijo, arriba a la izquierda)
        spec.setAlpha(layerA);
        c.save();
        c.rotate(228f, cx, cy);
        c.drawCircle(cx, cy, 0.82f * r, spec);
        c.restore();
        c.restore();

        // destello horizontal
        float sx = flareK * (1f + 0.05f * breathe) * (1f + 0.55f * bloom);
        if (sx > 0.001f && layerA > 0) {
            float th = Math.max(1.2f, 0.0050f * s);
            c.save();
            c.scale(sx, 1f, cx, cy);
            flare.setAlpha(Math.round(layerA * (0.8f + 0.2f * breathe)));
            c.save();
            c.scale(1f, 0.10f, cx, cy);
            c.drawCircle(cx, cy, 0.32f * s, flare);
            c.restore();
            line.setAlpha(layerA);
            c.drawRect(cx - 0.42f * s, cy - th / 2f, cx + 0.42f * s, cy + th / 2f, line);
            c.drawRect(cx - 0.12f * s, cy - th * 0.8f, cx + 0.12f * s, cy + th * 0.8f, line);
            c.restore();
        }

        // destello de luz del estallido final
        if (bloom > 0f) {
            float bp = 1f - (1f - bloom) * (1f - bloom);
            burst.setAlpha(Math.round(255f * 0.95f * (1f - bloom * 0.85f)));
            c.save();
            float bk = 0.5f + 3.0f * bp;
            c.scale(bk, bk, cx, cy);
            c.drawCircle(cx, cy, r, burst);
            c.restore();
        }

        // onda de luz que sale del centro (al encenderse y al estallar)
        float wp = bloom > 0f ? bloom : waveP;
        if (wp > 0f && wp < 1f) {
            float rad = r * (1f + (bloom > 0f ? 2.8f : 2.3f) * wp);
            wave.setStrokeWidth(Math.max(1f, 0.010f * s * (1f - wp)));
            wave.setAlpha(Math.round(255f * (bloom > 0f ? 0.6f : 0.5f) * (1f - wp)));
            c.drawCircle(cx, cy, rad, wave);
        }
    }
}
