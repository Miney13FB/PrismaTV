package dev.prisma.tv;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Fila enfocable de ajustes o de menú (título a la izquierda, valor a la derecha). */
final class Row extends LinearLayout implements FocusFx {
    final TextView title;
    final TextView value;
    private final GradientDrawable on;
    private final GradientDrawable off;

    Row(Context c, float u, String t) {
        super(c);
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        setFocusable(true);
        setClickable(true);
        int pad = Math.round(22f * u);
        setPadding(pad, 0, pad, 0);

        off = new GradientDrawable();
        off.setColor(0x00FFFFFF);
        off.setCornerRadius(16f * u);
        on = new GradientDrawable();
        on.setColor(0x3AFFFFFF);
        on.setCornerRadius(16f * u);
        on.setStroke(Math.max(2, Math.round(2f * u)), 0xAAFFFFFF);
        setBackground(off);

        title = new TextView(c);
        title.setText(t);
        title.setTextSize(TypedValue.COMPLEX_UNIT_PX, 21f * u);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        title.setSingleLine(true);
        title.setIncludeFontPadding(false);
        addView(title, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));

        value = new TextView(c);
        value.setTextSize(TypedValue.COMPLEX_UNIT_PX, 21f * u);
        value.setTextColor(0xB8FFFFFF);
        value.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        value.setSingleLine(true);
        value.setIncludeFontPadding(false);
        value.setGravity(Gravity.END);
        addView(value, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
    }

    @Override
    public void fx(boolean focused, int dir, boolean animate) {
        setBackground(focused ? on : off);
        value.setTextColor(focused ? 0xFFFFFFFF : 0xB8FFFFFF);
    }
}
