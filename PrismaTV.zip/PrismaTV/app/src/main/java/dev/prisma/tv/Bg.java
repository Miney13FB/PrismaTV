package dev.prisma.tv;

import android.os.Process;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/**
 * Hilos de segundo plano de Lumen (fotos, iconos, lista de apps, tiempo...). Corren con la prioridad de «segundo plano» que
 * usa Android para sus propias tareas: así, cuando hay que decodificar una foto o crear los iconos justo mientras se mueve
 * el foco o hace un fundido, el procesador (solo 4 núcleos flojos en un Fire TV Stick) se lo queda la pantalla y el trabajo
 * en segundo plano termina en cuanto hay hueco. Además, si una de esas tareas fallara por lo que fuera, el hilo no tumba
 * el launcher entero: sin Lumen, el Fire TV se queda sin Inicio.
 */
final class Bg {
    private Bg() {
    }

    /** Pone el hilo que la llama con prioridad de segundo plano. */
    static void low() {
        try {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
        } catch (Throwable ignored) {
        }
    }

    /** Un hilo (sin arrancar) con prioridad baja que nunca deja escapar un fallo al sistema. */
    static Thread thread(String name, final Runnable r) {
        return new Thread(new Runnable() {
            @Override
            public void run() {
                low();
                try {
                    r.run();
                } catch (Throwable ignored) {
                }
            }
        }, name);
    }

    /** Un ejecutor de un solo hilo con esas mismas características. */
    static ExecutorService single(final String name) {
        return Executors.newSingleThreadExecutor(new ThreadFactory() {
            @Override
            public Thread newThread(Runnable r) {
                return thread(name, r);
            }
        });
    }
}
