package dev.prisma.tv;

import android.graphics.Bitmap;

/**
 * Desenfoque gaussiano aproximado (3 pasadas de caja) que se calcula UNA sola vez.
 * Así el "cristal" no cuesta nada por fotograma, ni siquiera en un Fire TV Stick.
 */
final class Blur {
    static Bitmap frost(Bitmap src, int tw, int th, int radius, int passes) {
        Bitmap s = Bitmap.createScaledBitmap(src, tw, th, true);
        int[] px = new int[tw * th];
        s.getPixels(px, 0, tw, 0, 0, tw, th);
        for (int i = 0; i < passes; i++) {
            boxH(px, tw, th, radius);
            boxV(px, tw, th, radius);
        }
        Bitmap out = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
        out.setPixels(px, 0, tw, 0, 0, tw, th);
        return out;
    }

    private static int clamp(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    private static void boxH(int[] px, int w, int h, int r) {
        int div = 2 * r + 1;
        int[] row = new int[w];
        for (int y = 0; y < h; y++) {
            int o = y * w;
            int sr = 0, sg = 0, sb = 0;
            for (int i = -r; i <= r; i++) {
                int p = px[o + clamp(i, 0, w - 1)];
                sr += (p >> 16) & 255;
                sg += (p >> 8) & 255;
                sb += p & 255;
            }
            for (int x = 0; x < w; x++) {
                row[x] = 0xFF000000 | ((sr / div) << 16) | ((sg / div) << 8) | (sb / div);
                int add = px[o + clamp(x + r + 1, 0, w - 1)];
                int sub = px[o + clamp(x - r, 0, w - 1)];
                sr += ((add >> 16) & 255) - ((sub >> 16) & 255);
                sg += ((add >> 8) & 255) - ((sub >> 8) & 255);
                sb += (add & 255) - (sub & 255);
            }
            System.arraycopy(row, 0, px, o, w);
        }
    }

    private static void boxV(int[] px, int w, int h, int r) {
        int div = 2 * r + 1;
        int[] col = new int[h];
        for (int x = 0; x < w; x++) {
            int sr = 0, sg = 0, sb = 0;
            for (int i = -r; i <= r; i++) {
                int p = px[clamp(i, 0, h - 1) * w + x];
                sr += (p >> 16) & 255;
                sg += (p >> 8) & 255;
                sb += p & 255;
            }
            for (int y = 0; y < h; y++) {
                col[y] = 0xFF000000 | ((sr / div) << 16) | ((sg / div) << 8) | (sb / div);
                int add = px[clamp(y + r + 1, 0, h - 1) * w + x];
                int sub = px[clamp(y - r, 0, h - 1) * w + x];
                sr += ((add >> 16) & 255) - ((sub >> 16) & 255);
                sg += ((add >> 8) & 255) - ((sub >> 8) & 255);
                sb += (add & 255) - (sub & 255);
            }
            for (int y = 0; y < h; y++) px[y * w + x] = col[y];
        }
    }
}
