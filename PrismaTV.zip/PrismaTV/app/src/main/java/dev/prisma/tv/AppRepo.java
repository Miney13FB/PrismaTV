package dev.prisma.tv;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;

final class AppRepo {
    /** Apps que se ponen en Inicio la primera vez, si están instaladas. */
    static final String[] PREFERRED = {
            "com.netflix.ninja",
            "com.amazon.firetv.youtube",
            "com.amazon.avod",
            "com.disney.disneyplus",
            "com.spotify.tv.android",
            "com.wbd.stream",
            "org.xbmc.kodi",
            "com.teamsmart.videomanager.tv",
            "com.plexapp.android",
            "org.videolan.vlc",
            "tv.twitch.android.app",
            "com.google.android.youtube.tv"
    };

    /** Las dos clases de icono que se muestran en Inicio (primero las de Android TV). */
    private static final String[] CATS = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};

    /**
     * ¿Tiene esta app icono en Inicio? Mismo criterio que load(), pero para un solo paquete (una consulta barata).
     * Sirve para no recargar toda la lista cuando el sistema avisa de paquetes sin icono (servicios, actualizaciones).
     */
    static boolean hasLauncher(Context ctx, String pkg) {
        PackageManager pm = ctx.getPackageManager();
        for (String cat : CATS) {
            Intent q = new Intent(Intent.ACTION_MAIN);
            q.addCategory(cat);
            q.setPackage(pkg);
            List<ResolveInfo> found = pm.queryIntentActivities(q, 0);
            if (found != null && !found.isEmpty()) return true;
        }
        return false;
    }

    static List<AppItem> load(Context ctx) {
        PackageManager pm = ctx.getPackageManager();
        LinkedHashMap<String, AppItem> map = new LinkedHashMap<>();
        for (String cat : CATS) {
            Intent q = new Intent(Intent.ACTION_MAIN);
            q.addCategory(cat);
            List<ResolveInfo> found = pm.queryIntentActivities(q, 0);
            for (ResolveInfo ri : found) {
                if (ri.activityInfo == null) continue;
                String p = ri.activityInfo.packageName;
                if (p.equals(ctx.getPackageName()) || map.containsKey(p)) continue;
                AppItem a = new AppItem();
                a.pkg = p;
                a.cn = new ComponentName(p, ri.activityInfo.name);
                a.ri = ri;
                a.leanback = Intent.CATEGORY_LEANBACK_LAUNCHER.equals(cat);
                CharSequence l = null;
                try {
                    l = ri.loadLabel(pm);
                } catch (Throwable ignored) {
                }
                a.label = l == null ? p : l.toString();
                map.put(p, a);
            }
        }
        ArrayList<AppItem> out = new ArrayList<>(map.values());
        Collections.sort(out, new Comparator<AppItem>() {
            @Override
            public int compare(AppItem x, AppItem y) {
                return x.label.compareToIgnoreCase(y.label);
            }
        });
        return out;
    }
}
