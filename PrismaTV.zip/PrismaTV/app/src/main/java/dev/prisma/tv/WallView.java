package dev.prisma.tv;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

/**
 * Fondo de fotos con cambio suave (fundido cruzado). La foto y el cristal desenfocado que se ve en los paneles se
 * funden a la vez con el mismo reloj, así el cristal nunca enseña una foto distinta de la que hay detrás.
 * Un fundido en marcha no se corta nunca: si llega otro fondo, espera su turno (así no hay saltos ni parpadeos).
 */
final class WallView extends View {
    /** El azul casi negro de fondo del Inicio (el que se ve hasta que llega la primera foto). */
    private static final int BASE = 0xFF05070C;

    private Bitmap bmp, prev;
    private Bitmap nextBmp, nextFrost;   // el fondo que espera a que termine el fundido en marcha
    private int nextMs;
    private float t = 1f;
    private ValueAnimator anim;
    private final Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Rect src = new Rect();
    private final Rect dst = new Rect();

    WallView(Context c) {
        super(c);
    }

    /**
     * Pone un fondo nuevo: {@code b} es la foto y {@code frost} su versión desenfocada para el cristal. Con
     * {@code fadeMs > 0} se funden la foto y el cristal a la vez.
     */
    void show(Bitmap b, Bitmap frost, int fadeMs) {
        if (anim != null) {
            nextBmp = b;
            nextFrost = frost;
            nextMs = fadeMs;
            return;
        }
        begin(b, frost, fadeMs);
    }

    private void begin(Bitmap b, Bitmap frost, int fadeMs) {
        if (bmp == null || fadeMs <= 0) {
            bmp = b;
            prev = null;
            t = 1f;
            GlassView.setBackdrop(frost);
            invalidate();
            return;
        }
        prev = bmp;
        bmp = b;
        t = 0f;
        GlassView.fadeTo(frost);
        final ValueAnimator an = ValueAnimator.ofFloat(0f, 1f);
        anim = an;
        an.setDuration(fadeMs);
        an.setInterpolator(new AccelerateDecelerateInterpolator());
        an.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                if (anim != an) return;
                t = (Float) a.getAnimatedValue();
                GlassView.setMix(t);
                invalidate();
            }
        });
        an.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator a) {
                if (anim != an) return;   // ya lo cerró finish()
                anim = null;
                prev = null;
                t = 1f;
                GlassView.setMix(1f);
                invalidate();
                if (nextBmp != null) {
                    Bitmap nb = nextBmp, nf = nextFrost;
                    int ms = nextMs;
                    nextBmp = null;
                    nextFrost = null;
                    begin(nb, nf, ms);
                }
            }
        });
        an.start();
    }

    /** Termina ahora mismo el fundido en marcha y se queda con el último fondo pedido (al pausar la app). */
    void finish() {
        ValueAnimator an = anim;
        anim = null;
        if (an != null) an.cancel();
        if (nextBmp != null) {
            bmp = nextBmp;
            GlassView.setBackdrop(nextFrost);
            nextBmp = null;
            nextFrost = null;
        } else {
            GlassView.setMix(1f);
        }
        prev = null;
        t = 1f;
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        finish();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (bmp == null) {
            // aún no hay foto: el color de fondo lo pinta esta vista. La ventana y el contenedor ya no pintan uno debajo de
            // todo, y era un relleno de pantalla completa de más en cada fotograma
            canvas.drawColor(BASE);
            return;
        }
        dst.set(0, 0, getWidth(), getHeight());
        int a = Math.round(255 * t);
        // con la foto nueva a opacidad completa la anterior ya no se ve: no se pinta
        if (prev != null && a < 255) {
            src.set(0, 0, prev.getWidth(), prev.getHeight());
            p.setAlpha(255);
            canvas.drawBitmap(prev, src, dst, p);
        }
        src.set(0, 0, bmp.getWidth(), bmp.getHeight());
        p.setAlpha(a);
        canvas.drawBitmap(bmp, src, dst, p);
    }
}
