package dev.prisma.tv;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;

final class WallView extends View {
    private Bitmap bmp;
    private final Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Rect src = new Rect();
    private final Rect dst = new Rect();

    WallView(Context c) {
        super(c);
    }

    void setBitmap(Bitmap b) {
        bmp = b;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (bmp == null) return;
        src.set(0, 0, bmp.getWidth(), bmp.getHeight());
        dst.set(0, 0, getWidth(), getHeight());
        canvas.drawBitmap(bmp, src, dst, p);
    }
}
