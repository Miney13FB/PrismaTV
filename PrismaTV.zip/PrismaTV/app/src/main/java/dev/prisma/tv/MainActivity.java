package dev.prisma.tv;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.provider.Settings;
import android.text.format.Formatter;
import android.util.DisplayMetrics;
import android.util.LruCache;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Prisma TV: launcher ligero para Fire TV.
 * Estilo: cristal tipo tvOS (inspirado en Glass), Inicio tranquilo con barra de pestañas
 * (inspirado en Luma) y barra superior con acciones + reloj en reposo (inspirado en CleanYourTV).
 * Código propio, sin librerías externas.
 */
public class MainActivity extends Activity {

    interface Val { String get(); }
    interface Step { void step(int dir); }
    interface TabCb { void onTab(int idx, boolean focused); }

    /** Pestaña de la barra superior. */
    static final class Tab extends TextView implements FocusFx {
        final int idx;
        private final TabCb cb;

        Tab(Context c, int i, TabCb cb) {
            super(c);
            this.idx = i;
            this.cb = cb;
        }

        @Override
        public void fx(boolean focused, int dir, boolean animate) {
            cb.onTab(idx, focused);
        }
    }

    private static final int TW = 240, TH = 135;
    private static final Typeface LIGHT = Typeface.create("sans-serif-light", Typeface.NORMAL);
    private static final Typeface MEDIUM = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    private static final Typeface REG = Typeface.create("sans-serif", Typeface.NORMAL);
    private static final int[] WP_NAMES = {R.string.wp_0, R.string.wp_1, R.string.wp_2,
            R.string.wp_3, R.string.wp_4, R.string.wp_5};
    private static final int[] IDLE_OPTS = {0, 3, 5, 10, 20};

    private Store st;
    private float u;
    private int sw, sh;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private Sfx sfx;
    private boolean soundReady;

    private FrameLayout root, content;
    private WallView wall;
    private final View[] pages = new View[3];
    private int cur = 0;

    // barra superior
    private View pill;
    private final Tab[] tabs = new Tab[3];
    private int tabW;
    private boolean tabFocused;
    private TextView netText;
    private WifiView wifiIcon;

    // inicio
    private TextView greetTv, clockTv, dateTv, capName, capSub;
    private View capBox;
    private LinearLayout dockRow;
    private HorizontalScrollView dockScroll;

    // apps
    private LinearLayout appsBox;
    private ScrollView appsScroll;
    private TextView appsCount;
    private boolean appsDirty = true;

    // ajustes
    private final ArrayList<Row> rows = new ArrayList<>();
    private final ArrayList<Val> rowVals = new ArrayList<>();
    private final ArrayList<Boolean> rowArrows = new ArrayList<>();
    private TextView sysRam, sysStore, sysIp;

    // datos
    private List<AppItem> apps = new ArrayList<>();
    private final HashMap<String, AppItem> byPkg = new HashMap<>();
    private final LruCache<String, Bitmap> tiles = new LruCache<String, Bitmap>(16 * 1024 * 1024) {
        @Override
        protected int sizeOf(String k, Bitmap b) {
            return b.getByteCount();
        }
    };

    // menú contextual
    private FrameLayout menuLayer;
    private View menuPrevFocus;

    // reloj en reposo
    private FrameLayout saver;
    private TextView saverClock;
    private boolean saverOn;
    private final Random rnd = new Random();

    private ValueAnimator drift;

    // ------------------------------------------------------------------ ciclo de vida

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        st = new Store(this);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        sw = Math.max(dm.widthPixels, dm.heightPixels);
        sh = Math.min(dm.widthPixels, dm.heightPixels);
        u = Math.min(sw / 1280f, sh / 720f);
        sfx = new Sfx();
        sfx.enabled = st.sound();

        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF05070C);

        wall = new WallView(this);
        wall.setScaleX(1.06f);
        wall.setScaleY(1.06f);
        root.addView(wall, new FrameLayout.LayoutParams(-1, -1));

        content = new FrameLayout(this);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        buildTopBar();
        pages[0] = buildHome();
        pages[1] = buildApps();
        pages[2] = buildSettings();
        for (int i = 0; i < 3; i++) {
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -1);
            lp.topMargin = px(96);
            content.addView(pages[i], lp);
            pages[i].setVisibility(i == 0 ? View.VISIBLE : View.GONE);
        }
        buildSaver();
        setContentView(root);

        root.getViewTreeObserver().addOnGlobalFocusChangeListener(focusL);

        handleIntentExtras(getIntent());
        applyWallpaper();
        reloadApps(true);
        updateClock();
        updateNet();
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                soundReady = true;
            }
        }, 900);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleIntentExtras(i);
        dismissMenu(false);
        if (saverOn) hideSaver();
        tabs[0].requestFocus();
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                focusFirstFav();
            }
        }, 80);
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter f1 = new IntentFilter();
        f1.addAction(Intent.ACTION_TIME_TICK);
        f1.addAction(Intent.ACTION_TIME_CHANGED);
        f1.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        f1.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        f1.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        f1.addAction(WifiManager.RSSI_CHANGED_ACTION);
        f1.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        registerReceiver(rx, f1);
        IntentFilter f2 = new IntentFilter();
        f2.addAction(Intent.ACTION_PACKAGE_ADDED);
        f2.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f2.addAction(Intent.ACTION_PACKAGE_REPLACED);
        f2.addDataScheme("package");
        registerReceiver(rx, f2);
        updateClock();
        updateNet();
        if (cur == 2) updateSys();
        startDrift();
        resetIdle();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            unregisterReceiver(rx);
        } catch (Throwable ignored) {
        }
        stopDrift();
        ui.removeCallbacks(idleR);
        if (saverOn) hideSaver();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bg.shutdownNow();
        io.shutdownNow();
        sfx.release();
    }

    @Override
    public void onBackPressed() {
        if (menuLayer != null) {
            sfx.play(Sfx.BACK);
            dismissMenu(true);
            return;
        }
        if (cur != 0) {
            sfx.play(Sfx.BACK);
            tabs[0].requestFocus();
            ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    focusFirstFav();
                }
            }, 80);
        }
        // En Inicio no se hace nada: un launcher no se cierra.
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (saverOn) {
            if (e.getAction() == KeyEvent.ACTION_DOWN) hideSaver();
            return true;
        }
        resetIdle();
        return super.dispatchKeyEvent(e);
    }

    @Override
    public void onUserInteraction() {
        resetIdle();
    }

    private void handleIntentExtras(Intent i) {
        if (i != null && i.hasExtra("name")) {
            st.setName(i.getStringExtra("name"));
            updateClock();
        }
    }

    // ------------------------------------------------------------------ utilidades

    private int px(float v) {
        return Math.round(v * u);
    }

    private TextView text(String s, float sizeDesign, int color, Typeface tf) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizeDesign * u);
        t.setTextColor(color);
        if (tf != null) t.setTypeface(tf);
        t.setIncludeFontPadding(false);
        return t;
    }

    private void toast(int res) {
        Toast.makeText(this, res, Toast.LENGTH_SHORT).show();
    }

    private static int centerX(View v) {
        int[] l = new int[2];
        v.getLocationOnScreen(l);
        return l[0] + v.getWidth() / 2;
    }

    private void invalidateGlass(View v) {
        if (v instanceof GlassView) v.invalidate();
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) invalidateGlass(g.getChildAt(i));
        }
    }

    private static String cap(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase(Locale.getDefault()) + s.substring(1);
    }

    // ------------------------------------------------------------------ foco global

    private final ViewTreeObserver.OnGlobalFocusChangeListener focusL =
            new ViewTreeObserver.OnGlobalFocusChangeListener() {
                @Override
                public void onGlobalFocusChanged(View oldF, View newF) {
                    boolean anim = st.anim();
                    int dir = 0;
                    if (oldF != null && newF != null) {
                        dir = Integer.signum(centerX(newF) - centerX(oldF));
                    }
                    if (oldF instanceof FocusFx) ((FocusFx) oldF).fx(false, 0, anim);
                    if (newF instanceof FocusFx) ((FocusFx) newF).fx(true, dir, anim);
                    if (newF != null && soundReady) sfx.play(Sfx.MOVE);
                    updateCaption(newF);
                }
            };

    private void updateCaption(View f) {
        if (capBox == null || cur != 0) return;
        if (f instanceof Cell && ((Cell) f).capName != null) {
            Cell c = (Cell) f;
            capName.setText(c.capName);
            capSub.setText(c.capSub);
            capBox.setVisibility(View.VISIBLE);
        } else if (menuLayer == null) {
            capBox.setVisibility(View.INVISIBLE);
        }
    }

    // ------------------------------------------------------------------ barra superior

    private void buildTopBar() {
        FrameLayout bar = new FrameLayout(this);
        content.addView(bar, new FrameLayout.LayoutParams(-1, px(96)));

        // Marca a la izquierda
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.HORIZONTAL);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher);
        brand.addView(logo, new LinearLayout.LayoutParams(px(44), px(44)));
        TextView bn = text(getString(R.string.app_name), 22, 0xF2FFFFFF, MEDIUM);
        LinearLayout.LayoutParams bnp = new LinearLayout.LayoutParams(-2, -2);
        bnp.leftMargin = px(12);
        brand.addView(bn, bnp);
        FrameLayout.LayoutParams brandLp = new FrameLayout.LayoutParams(-2, px(48),
                Gravity.START | Gravity.CENTER_VERTICAL);
        brandLp.leftMargin = px(64);
        bar.addView(brand, brandLp);

        // Pestañas en el centro, con una píldora que se desliza
        tabW = px(124);
        GlassView holder = new GlassView(this, px(30), 0x4410182A);
        FrameLayout.LayoutParams hl = new FrameLayout.LayoutParams(tabW * 3 + px(12), px(60), Gravity.CENTER);
        bar.addView(holder, hl);

        pill = new View(this);
        GradientDrawable pd = new GradientDrawable();
        pd.setColor(0x52FFFFFF);
        pd.setCornerRadius(px(24));
        pd.setStroke(Math.max(1, px(1.5f)), 0x80FFFFFF);
        pill.setBackground(pd);
        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(tabW, px(48));
        pl.leftMargin = px(6);
        pl.topMargin = px(6);
        holder.addView(pill, pl);

        LinearLayout tr = new LinearLayout(this);
        tr.setOrientation(LinearLayout.HORIZONTAL);
        tr.setPadding(px(6), px(6), px(6), px(6));
        holder.addView(tr, new FrameLayout.LayoutParams(-1, -1));

        int[] names = {R.string.tab_home, R.string.tab_apps, R.string.tab_settings};
        TabCb cb = new TabCb() {
            @Override
            public void onTab(int idx, boolean focused) {
                tabFocused = focused;
                if (focused) selectTab(idx);
                pill.setAlpha(tabFocused ? 1f : 0.6f);
            }
        };
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            Tab t = new Tab(this, i, cb);
            t.setText(names[i]);
            t.setGravity(Gravity.CENTER);
            t.setTextSize(TypedValue.COMPLEX_UNIT_PX, 20f * u);
            t.setTextColor(0xFFFFFFFF);
            t.setTypeface(MEDIUM);
            t.setIncludeFontPadding(false);
            t.setFocusable(true);
            t.setClickable(true);
            t.setAlpha(i == 0 ? 1f : 0.7f);
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    sfx.play(Sfx.SELECT);
                    ui.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            View f = tabs[idx].focusSearch(View.FOCUS_DOWN);
                            if (f != null) f.requestFocus();
                        }
                    }, 80);
                }
            });
            tabs[i] = t;
            tr.addView(t, new LinearLayout.LayoutParams(tabW, px(48)));
        }

        // Acciones a la derecha: Wi-Fi y ajustes
        Chip gear = new Chip(this, px(24));
        GearView gv = new GearView(this);
        FrameLayout.LayoutParams gvl = new FrameLayout.LayoutParams(px(30), px(30), Gravity.CENTER);
        gear.addView(gv, gvl);
        FrameLayout.LayoutParams gl = new FrameLayout.LayoutParams(px(48), px(48),
                Gravity.END | Gravity.CENTER_VERTICAL);
        gl.rightMargin = px(64);
        gear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sfx.play(Sfx.SELECT);
                openSystemSettings();
            }
        });
        bar.addView(gear, gl);

        Chip wifi = new Chip(this, px(24));
        LinearLayout wl = new LinearLayout(this);
        wl.setOrientation(LinearLayout.HORIZONTAL);
        wl.setGravity(Gravity.CENTER_VERTICAL);
        wl.setPadding(px(14), 0, px(18), 0);
        wifiIcon = new WifiView(this);
        wl.addView(wifiIcon, new LinearLayout.LayoutParams(px(28), px(28)));
        netText = text("", 17, 0xE6FFFFFF, REG);
        netText.setSingleLine(true);
        LinearLayout.LayoutParams ntp = new LinearLayout.LayoutParams(-2, -2);
        ntp.leftMargin = px(8);
        wl.addView(netText, ntp);
        wifi.addView(wl, new FrameLayout.LayoutParams(-2, -1));
        FrameLayout.LayoutParams wlp = new FrameLayout.LayoutParams(-2, px(48),
                Gravity.END | Gravity.CENTER_VERTICAL);
        wlp.rightMargin = px(64 + 48 + 14);
        wifi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sfx.play(Sfx.SELECT);
                openWifiSettings();
            }
        });
        bar.addView(wifi, wlp);
    }

    private void selectTab(int i) {
        for (int k = 0; k < 3; k++) tabs[k].setAlpha(k == i ? 1f : 0.7f);
        long d = st.anim() ? 230 : 0;
        pill.animate().cancel();
        pill.animate().translationX(i * tabW).setDuration(d)
                .setInterpolator(new OvershootInterpolator(0.9f)).start();
        showPage(i);
    }

    private void showPage(int i) {
        if (i == cur) return;
        View old = pages[cur];
        View nw = pages[i];
        cur = i;
        old.animate().cancel();
        old.setVisibility(View.GONE);
        nw.animate().cancel();
        nw.setAlpha(0f);
        nw.setVisibility(View.VISIBLE);
        nw.animate().alpha(1f).setDuration(st.anim() ? 220 : 0).start();
        if (i == 0) {
            capBox.setVisibility(View.INVISIBLE);
        }
        if (i == 1) ensureApps();
        if (i == 2) {
            refreshRows();
            updateSys();
        }
    }

    // ------------------------------------------------------------------ inicio

    private View buildHome() {
        FrameLayout page = new FrameLayout(this);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        greetTv = text("", 24, 0xE6FFFFFF, MEDIUM);
        clockTv = text("", 104, 0xFFFFFFFF, LIGHT);
        dateTv = text("", 24, 0xB8FFFFFF, REG);
        head.addView(greetTv);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
        cp.topMargin = px(4);
        head.addView(clockTv, cp);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-2, -2);
        dp.topMargin = px(2);
        head.addView(dateTv, dp);
        FrameLayout.LayoutParams hl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        hl.leftMargin = px(72);
        hl.topMargin = px(4);
        page.addView(head, hl);

        LinearLayout cap = new LinearLayout(this);
        cap.setOrientation(LinearLayout.VERTICAL);
        capName = text("", 36, 0xFFFFFFFF, MEDIUM);
        capSub = text("", 17, 0xB8FFFFFF, REG);
        cap.addView(capName);
        LinearLayout.LayoutParams csp = new LinearLayout.LayoutParams(-2, -2);
        csp.topMargin = px(6);
        cap.addView(capSub, csp);
        cap.setVisibility(View.INVISIBLE);
        capBox = cap;
        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START);
        cl.leftMargin = px(72);
        cl.bottomMargin = px(44 + 172 + 18);
        page.addView(cap, cl);

        GlassView band = new GlassView(this, px(36), 0x4D0E1424);
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(-1, px(172), Gravity.BOTTOM);
        bl.leftMargin = px(48);
        bl.rightMargin = px(48);
        bl.bottomMargin = px(44);
        page.addView(band, bl);

        dockScroll = new HorizontalScrollView(this);
        dockScroll.setHorizontalScrollBarEnabled(false);
        dockScroll.setSmoothScrollingEnabled(true);
        dockScroll.setClipToPadding(false);
        dockScroll.setClipChildren(false);
        dockScroll.setPadding(px(32), px(34), px(32), px(34));
        dockScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        dockRow = new LinearLayout(this);
        dockRow.setOrientation(LinearLayout.HORIZONTAL);
        dockRow.setClipChildren(false);
        dockScroll.addView(dockRow, new FrameLayout.LayoutParams(-2, -1));
        band.addView(dockScroll, new FrameLayout.LayoutParams(-1, -1));
        return page;
    }

    private List<AppItem> favApps() {
        ArrayList<AppItem> out = new ArrayList<>();
        Set<String> hid = st.hidden();
        for (String p : st.favs()) {
            AppItem a = byPkg.get(p);
            if (a != null && !hid.contains(p)) out.add(a);
        }
        return out;
    }

    private void buildDock() {
        dockRow.removeAllViews();
        int cw = px(184), ch = px(104);
        for (final AppItem a : favApps()) {
            Cell c = new Cell(this, u, cw, ch, cw, ch, 0, false);
            c.pkg = a.pkg;
            c.capName = a.label;
            c.capSub = getString(R.string.cap_hint);
            c.img.setTag(a.pkg);
            loadTile(a, c.img);
            c.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    launch(a);
                }
            });
            c.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    showAppMenu(a, true);
                    return true;
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(cw, ch);
            lp.rightMargin = px(18);
            dockRow.addView(c, lp);
        }
        Cell all = new Cell(this, u, cw, ch, cw, ch, 0, false);
        all.img.setImageBitmap(TileFactory.allApps(TW, TH));
        all.capName = getString(R.string.all_apps);
        all.capSub = getString(R.string.all_apps_sub);
        all.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sfx.play(Sfx.SELECT);
                tabs[1].requestFocus();
                ui.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        View f = tabs[1].focusSearch(View.FOCUS_DOWN);
                        if (f != null) f.requestFocus();
                    }
                }, 120);
            }
        });
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(cw, ch);
        dockRow.addView(all, alp);
    }

    private void focusFirstFav() {
        if (dockRow != null && dockRow.getChildCount() > 0) {
            dockScroll.scrollTo(0, 0);
            dockRow.getChildAt(0).requestFocus();
        }
    }

    private void focusDock(final String pkg) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < dockRow.getChildCount(); i++) {
                    View v = dockRow.getChildAt(i);
                    if (v instanceof Cell && pkg.equals(((Cell) v).pkg)) {
                        v.requestFocus();
                        return;
                    }
                }
                focusFirstFav();
            }
        });
    }

    // ------------------------------------------------------------------ todas las apps

    private View buildApps() {
        FrameLayout page = new FrameLayout(this);
        TextView title = text(getString(R.string.all_apps), 30, 0xFFFFFFFF, MEDIUM);
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        tl.leftMargin = px(72);
        tl.topMargin = px(4);
        page.addView(title, tl);

        appsCount = text("", 18, 0xA8FFFFFF, REG);
        FrameLayout.LayoutParams ctl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        ctl.rightMargin = px(72);
        ctl.topMargin = px(14);
        page.addView(appsCount, ctl);

        appsScroll = new ScrollView(this);
        appsScroll.setVerticalScrollBarEnabled(false);
        appsScroll.setSmoothScrollingEnabled(true);
        appsScroll.setClipToPadding(false);
        appsScroll.setClipChildren(false);
        appsScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        appsScroll.setPadding(px(52), px(14), px(52), px(40));
        appsBox = new LinearLayout(this);
        appsBox.setOrientation(LinearLayout.VERTICAL);
        appsBox.setClipChildren(false);
        appsScroll.addView(appsBox, new FrameLayout.LayoutParams(-1, -2));
        FrameLayout.LayoutParams sl = new FrameLayout.LayoutParams(-1, -1);
        sl.topMargin = px(48);
        page.addView(appsScroll, sl);
        return page;
    }

    private List<AppItem> visibleApps() {
        ArrayList<AppItem> out = new ArrayList<>();
        Set<String> hid = st.hidden();
        for (AppItem a : apps) {
            if (!hid.contains(a.pkg)) out.add(a);
        }
        return out;
    }

    private void ensureApps() {
        if (appsDirty) buildAppsGrid();
    }

    private void buildAppsGrid() {
        appsDirty = false;
        appsBox.removeAllViews();
        List<AppItem> vis = visibleApps();
        appsCount.setText(getString(R.string.apps_count, vis.size()));
        int cols = 6;
        int cw = (sw - px(104)) / cols;
        int tw = px(164);
        int th = Math.round(tw * TH / (float) TW);
        int topPad = px(12);
        int ch = topPad + th + px(9) + px(22) + px(14);
        for (int i = 0; i < vis.size(); i += cols) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setClipChildren(false);
            for (int j = 0; j < cols && i + j < vis.size(); j++) {
                final AppItem a = vis.get(i + j);
                Cell c = new Cell(this, u, cw, ch, tw, th, topPad, true);
                c.pkg = a.pkg;
                c.label.setText(a.label);
                c.img.setTag(a.pkg);
                loadTile(a, c.img);
                c.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        launch(a);
                    }
                });
                c.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        showAppMenu(a, false);
                        return true;
                    }
                });
                row.addView(c, new LinearLayout.LayoutParams(cw, ch));
            }
            appsBox.addView(row, new LinearLayout.LayoutParams(-1, ch));
        }
    }

    // ------------------------------------------------------------------ ajustes

    private View buildSettings() {
        FrameLayout page = new FrameLayout(this);

        GlassView panel = new GlassView(this, px(30), 0x520E1424);
        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(px(660), -1, Gravity.START);
        pl.leftMargin = px(64);
        pl.bottomMargin = px(36);
        page.addView(panel, pl);

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setSmoothScrollingEnabled(true);
        sv.setClipToPadding(false);
        sv.setPadding(px(18), px(18), px(18), px(18));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        sv.addView(col, new FrameLayout.LayoutParams(-1, -2));
        panel.addView(sv, new FrameLayout.LayoutParams(-1, -1));

        addRow(col, R.string.set_wallpaper, new Val() {
            @Override
            public String get() {
                return getString(WP_NAMES[st.wallpaper()]);
            }
        }, new Step() {
            @Override
            public void step(int dir) {
                int n = WallpaperFactory.COUNT;
                st.setWallpaper((st.wallpaper() + dir + n) % n);
                applyWallpaper();
            }
        }, null, true);

        addRow(col, R.string.set_anim, new Val() {
            @Override
            public String get() {
                return getString(st.anim() ? R.string.anim_full : R.string.anim_reduced);
            }
        }, new Step() {
            @Override
            public void step(int dir) {
                st.setAnim(!st.anim());
                stopDrift();
                startDrift();
            }
        }, null, true);

        addRow(col, R.string.set_sound, new Val() {
            @Override
            public String get() {
                return getString(st.sound() ? R.string.yes : R.string.no);
            }
        }, new Step() {
            @Override
            public void step(int dir) {
                st.setSound(!st.sound());
                sfx.enabled = st.sound();
                sfx.play(Sfx.SELECT);
            }
        }, null, true);

        addRow(col, R.string.set_clock, new Val() {
            @Override
            public String get() {
                return getString(st.h24() ? R.string.h24 : R.string.h12);
            }
        }, new Step() {
            @Override
            public void step(int dir) {
                st.setH24(!st.h24());
                updateClock();
            }
        }, null, true);

        addRow(col, R.string.set_idle, new Val() {
            @Override
            public String get() {
                int m = st.idleMin();
                return m == 0 ? getString(R.string.idle_off) : getString(R.string.idle_min, m);
            }
        }, new Step() {
            @Override
            public void step(int dir) {
                int idx = 0;
                for (int i = 0; i < IDLE_OPTS.length; i++) {
                    if (IDLE_OPTS[i] == st.idleMin()) idx = i;
                }
                idx = (idx + dir + IDLE_OPTS.length) % IDLE_OPTS.length;
                st.setIdleMin(IDLE_OPTS[idx]);
                resetIdle();
            }
        }, null, true);

        addRow(col, R.string.set_name, new Val() {
            @Override
            public String get() {
                String n = st.name();
                return n.isEmpty() ? getString(R.string.name_none) : n;
            }
        }, null, new Runnable() {
            @Override
            public void run() {
                askName();
            }
        }, false);

        addRow(col, R.string.set_hidden, new Val() {
            @Override
            public String get() {
                int n = st.hidden().size();
                return n == 0 ? getString(R.string.hidden_none) : getString(R.string.hidden_show, n);
            }
        }, null, new Runnable() {
            @Override
            public void run() {
                if (!st.hidden().isEmpty()) {
                    st.setHidden(new HashSet<String>());
                    appsDirty = true;
                    toast(R.string.toast_restored);
                }
            }
        }, false);

        addRow(col, R.string.set_wifi, new Val() {
            @Override
            public String get() {
                return "›";
            }
        }, null, new Runnable() {
            @Override
            public void run() {
                openWifiSettings();
            }
        }, false);

        addRow(col, R.string.set_bt, new Val() {
            @Override
            public String get() {
                return "›";
            }
        }, null, new Runnable() {
            @Override
            public void run() {
                openBluetoothSettings();
            }
        }, false);

        addRow(col, R.string.set_sys, new Val() {
            @Override
            public String get() {
                return "›";
            }
        }, null, new Runnable() {
            @Override
            public void run() {
                openSystemSettings();
            }
        }, false);

        // Tarjeta de sistema a la derecha
        GlassView info = new GlassView(this, px(30), 0x520E1424);
        FrameLayout.LayoutParams il = new FrameLayout.LayoutParams(px(380), -2, Gravity.END | Gravity.TOP);
        il.rightMargin = px(64);
        page.addView(info, il);
        LinearLayout ic = new LinearLayout(this);
        ic.setOrientation(LinearLayout.VERTICAL);
        ic.setPadding(px(30), px(26), px(30), px(30));
        info.addView(ic, new FrameLayout.LayoutParams(-1, -2));
        ic.addView(text(getString(R.string.sys_title), 26, 0xFFFFFFFF, MEDIUM));
        sysRam = statBlock(ic, R.string.sys_ram);
        sysStore = statBlock(ic, R.string.sys_store);
        sysIp = statBlock(ic, R.string.sys_ip);
        TextView ver = statBlock(ic, R.string.sys_ver);
        ver.setText("Prisma TV " + versionName());
        return page;
    }

    private TextView statBlock(LinearLayout parent, int labelRes) {
        TextView l = text(getString(labelRes), 15, 0x99FFFFFF, REG);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = px(22);
        parent.addView(l, lp);
        TextView v = text("", 21, 0xFFFFFFFF, REG);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-2, -2);
        vp.topMargin = px(4);
        parent.addView(v, vp);
        return v;
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Throwable t) {
            return "";
        }
    }

    private void addRow(LinearLayout col, int titleRes, final Val val, final Step step,
                        final Runnable act, boolean arrows) {
        final Row r = new Row(this, u, getString(titleRes));
        rows.add(r);
        rowVals.add(val);
        rowArrows.add(arrows);
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sfx.play(Sfx.SELECT);
                if (act != null) act.run();
                else if (step != null) step.step(1);
                refreshRows();
            }
        });
        if (step != null) {
            r.setOnKeyListener(new View.OnKeyListener() {
                @Override
                public boolean onKey(View v, int code, KeyEvent e) {
                    if (e.getAction() != KeyEvent.ACTION_DOWN) return false;
                    if (code == KeyEvent.KEYCODE_DPAD_LEFT) {
                        step.step(-1);
                        refreshRows();
                        return true;
                    }
                    if (code == KeyEvent.KEYCODE_DPAD_RIGHT) {
                        step.step(1);
                        refreshRows();
                        return true;
                    }
                    return false;
                }
            });
        }
        col.addView(r, new LinearLayout.LayoutParams(-1, px(60)));
    }

    private void refreshRows() {
        for (int i = 0; i < rows.size(); i++) {
            String v = rowVals.get(i).get();
            rows.get(i).value.setText(rowArrows.get(i) ? "‹  " + v + "  ›" : v);
        }
    }

    private void askName() {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(st.name());
        et.setSelection(et.getText().length());
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(R.string.set_name)
                .setView(et)
                .setPositiveButton(android.R.string.ok, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        st.setName(et.getText().toString());
                        updateClock();
                        refreshRows();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void updateSys() {
        try {
            ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            sysRam.setText(getString(R.string.sys_free_of,
                    Formatter.formatFileSize(this, mi.availMem), Formatter.formatFileSize(this, mi.totalMem)));
            StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
            sysStore.setText(getString(R.string.sys_free_of,
                    Formatter.formatFileSize(this, sf.getAvailableBytes()),
                    Formatter.formatFileSize(this, sf.getTotalBytes())));
        } catch (Throwable ignored) {
        }
        sysIp.setText(localIp());
        if (cur == 2) {
            ui.removeCallbacks(sysTick);
            ui.postDelayed(sysTick, 5000);
        }
    }

    private final Runnable sysTick = new Runnable() {
        @Override
        public void run() {
            if (cur == 2) updateSys();
        }
    };

    private String localIp() {
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en != null && en.hasMoreElements()) {
                NetworkInterface ni = en.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                Enumeration<InetAddress> ad = ni.getInetAddresses();
                while (ad.hasMoreElements()) {
                    InetAddress a = ad.nextElement();
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) return a.getHostAddress();
                }
            }
        } catch (Throwable ignored) {
        }
        return "—";
    }

    // ------------------------------------------------------------------ apps: lanzar, menú, favoritos

    private void launch(AppItem a) {
        sfx.play(Sfx.SELECT);
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(a.leanback ? Intent.CATEGORY_LEANBACK_LAUNCHER : Intent.CATEGORY_LAUNCHER);
            i.setComponent(a.cn);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(i);
        } catch (Throwable t) {
            toast(R.string.toast_fail);
        }
    }

    private void showAppMenu(final AppItem a, boolean fromDock) {
        sfx.play(Sfx.SELECT);
        final ArrayList<String> labels = new ArrayList<>();
        final ArrayList<Runnable> acts = new ArrayList<>();
        final List<String> favs = st.favs();
        final boolean isFav = favs.contains(a.pkg);

        labels.add(getString(R.string.menu_open));
        acts.add(new Runnable() {
            @Override
            public void run() {
                launch(a);
            }
        });
        if (fromDock) {
            final int idx = favs.indexOf(a.pkg);
            if (idx > 0) {
                labels.add(getString(R.string.menu_left));
                acts.add(new Runnable() {
                    @Override
                    public void run() {
                        moveFav(a.pkg, -1);
                    }
                });
            }
            if (idx >= 0 && idx < favs.size() - 1) {
                labels.add(getString(R.string.menu_right));
                acts.add(new Runnable() {
                    @Override
                    public void run() {
                        moveFav(a.pkg, 1);
                    }
                });
            }
        }
        labels.add(getString(isFav ? R.string.menu_remove : R.string.menu_add));
        acts.add(new Runnable() {
            @Override
            public void run() {
                ArrayList<String> f = new ArrayList<>(st.favs());
                if (isFav) f.remove(a.pkg);
                else f.add(a.pkg);
                st.setFavs(f);
                buildDock();
            }
        });
        labels.add(getString(R.string.menu_hide));
        acts.add(new Runnable() {
            @Override
            public void run() {
                HashSet<String> h = new HashSet<>(st.hidden());
                h.add(a.pkg);
                st.setHidden(h);
                appsDirty = true;
                buildDock();
                if (cur == 1) {
                    buildAppsGrid();
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            if (appsBox.getChildCount() > 0) {
                                View r = appsBox.getChildAt(0);
                                if (r instanceof ViewGroup && ((ViewGroup) r).getChildCount() > 0) {
                                    ((ViewGroup) r).getChildAt(0).requestFocus();
                                }
                            }
                        }
                    });
                } else {
                    focusFirstFav();
                }
            }
        });
        labels.add(getString(R.string.menu_info));
        acts.add(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.fromParts("package", a.pkg, null));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Throwable t) {
                    toast(R.string.toast_fail);
                }
            }
        });
        showMenu(a.label, labels, acts);
    }

    private void moveFav(String pkg, int delta) {
        ArrayList<String> f = new ArrayList<>(st.favs());
        int i = f.indexOf(pkg);
        int j = i + delta;
        if (i < 0 || j < 0 || j >= f.size()) return;
        Collections.swap(f, i, j);
        st.setFavs(f);
        buildDock();
        focusDock(pkg);
    }

    private void showMenu(String title, List<String> labels, final List<Runnable> acts) {
        dismissMenu(false);
        menuPrevFocus = root.findFocus();
        menuLayer = new FrameLayout(this);
        menuLayer.setBackgroundColor(0x9E000000);
        menuLayer.setClickable(true);

        GlassView panel = new GlassView(this, px(28), 0x7A141C2E);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(px(16), px(18), px(16), px(16));
        TextView t = text(title, 24, 0xFFFFFFFF, MEDIUM);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setPadding(px(10), 0, px(10), px(10));
        col.addView(t, new LinearLayout.LayoutParams(-1, -2));
        Row first = null;
        for (int i = 0; i < labels.size(); i++) {
            final int k = i;
            Row r = new Row(this, u, labels.get(i));
            r.value.setVisibility(View.GONE);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    sfx.play(Sfx.SELECT);
                    dismissMenu(true);
                    acts.get(k).run();
                }
            });
            col.addView(r, new LinearLayout.LayoutParams(-1, px(56)));
            if (first == null) first = r;
        }
        panel.addView(col, new FrameLayout.LayoutParams(-1, -2));
        menuLayer.addView(panel, new FrameLayout.LayoutParams(px(460), -2, Gravity.CENTER));
        root.addView(menuLayer, new FrameLayout.LayoutParams(-1, -1));
        content.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        if (first != null) first.requestFocus();
    }

    private void dismissMenu(boolean restoreFocus) {
        if (menuLayer == null) return;
        root.removeView(menuLayer);
        menuLayer = null;
        content.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        View p = menuPrevFocus;
        menuPrevFocus = null;
        if (restoreFocus && p != null && p.isAttachedToWindow()) p.requestFocus();
    }

    // ------------------------------------------------------------------ iconos y fondo

    private void loadTile(final AppItem a, final ImageView iv) {
        Bitmap b = tiles.get(a.pkg);
        if (b != null) {
            iv.setImageBitmap(b);
            return;
        }
        try {
            io.execute(new Runnable() {
                @Override
                public void run() {
                    Bitmap nb = tiles.get(a.pkg);
                    if (nb == null) {
                        nb = TileFactory.make(getPackageManager(), a, TW, TH);
                        tiles.put(a.pkg, nb);
                    }
                    final Bitmap fb = nb;
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            if (a.pkg.equals(iv.getTag())) iv.setImageBitmap(fb);
                        }
                    });
                }
            });
        } catch (Throwable ignored) {
        }
    }

    private void applyWallpaper() {
        final int style = st.wallpaper();
        bg.execute(new Runnable() {
            @Override
            public void run() {
                final Bitmap w = WallpaperFactory.make(style, 640, 360);
                final Bitmap f = Blur.frost(w, 160, 90, 4, 3);
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        wall.setBitmap(w);
                        GlassView.setBackdrop(f, sw, sh);
                        invalidateGlass(root);
                    }
                });
            }
        });
    }

    private void startDrift() {
        if (!st.anim() || drift != null) return;
        drift = ValueAnimator.ofFloat(0f, 1f);
        drift.setDuration(50000);
        drift.setRepeatCount(ValueAnimator.INFINITE);
        drift.setInterpolator(new LinearInterpolator());
        drift.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                float t = (Float) a.getAnimatedValue();
                double ang = t * 2 * Math.PI;
                wall.setTranslationX((float) Math.sin(ang) * px(16));
                wall.setTranslationY((float) Math.cos(ang) * px(8));
            }
        });
        drift.start();
    }

    private void stopDrift() {
        if (drift != null) {
            drift.cancel();
            drift = null;
        }
        wall.setTranslationX(0f);
        wall.setTranslationY(0f);
    }

    // ------------------------------------------------------------------ cargar apps

    private void reloadApps(final boolean first) {
        bg.execute(new Runnable() {
            @Override
            public void run() {
                final List<AppItem> l = AppRepo.load(MainActivity.this);
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        apps = l;
                        byPkg.clear();
                        for (AppItem a : l) byPkg.put(a.pkg, a);
                        if (!st.favsReady()) initFavs();
                        buildDock();
                        appsDirty = true;
                        if (cur == 1) buildAppsGrid();
                        if (first) {
                            tabs[0].requestFocus();
                            focusFirstFav();
                        }
                    }
                });
            }
        });
    }

    private void initFavs() {
        ArrayList<String> f = new ArrayList<>();
        for (String p : AppRepo.PREFERRED) {
            if (byPkg.containsKey(p) && f.size() < 7) f.add(p);
        }
        for (AppItem a : apps) {
            if (f.size() >= 5) break;
            if (!f.contains(a.pkg)) f.add(a.pkg);
        }
        st.setFavs(f);
    }

    private final Runnable reloadR = new Runnable() {
        @Override
        public void run() {
            reloadApps(false);
        }
    };

    // ------------------------------------------------------------------ reloj, red, ajustes del sistema

    private void updateClock() {
        Date d = new Date();
        Locale loc = Locale.getDefault();
        String t = new SimpleDateFormat(st.h24() ? "HH:mm" : "h:mm", loc).format(d);
        clockTv.setText(t);
        saverClock.setText(t);
        String pat = android.text.format.DateFormat.getBestDateTimePattern(loc, "EEEEdMMMM");
        dateTv.setText(cap(new SimpleDateFormat(pat, loc).format(d)));
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        int g = h < 6 ? R.string.greet_night : (h < 13 ? R.string.greet_morning
                : (h < 20 ? R.string.greet_afternoon : R.string.greet_night));
        String name = st.name();
        greetTv.setText(name.isEmpty() ? getString(g) : getString(g) + ", " + name);
        if (saverOn) {
            saverClock.setTranslationX(rnd.nextInt(px(160)) - px(80));
            saverClock.setTranslationY(rnd.nextInt(px(100)) - px(50));
        }
    }

    private void updateNet() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            String label;
            int level;
            if (ni == null || !ni.isConnected()) {
                label = getString(R.string.net_off);
                level = 0;
            } else if (ni.getType() == ConnectivityManager.TYPE_ETHERNET) {
                label = getString(R.string.net_ethernet);
                level = 4;
            } else {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                WifiInfo wi = wm.getConnectionInfo();
                level = WifiManager.calculateSignalLevel(wi.getRssi(), 5);
                String ssid = wi.getSSID();
                if (ssid != null) ssid = ssid.replace("\"", "");
                label = (ssid == null || ssid.isEmpty() || ssid.contains("unknown"))
                        ? getString(R.string.net_connected) : ssid;
            }
            wifiIcon.setLevel(level);
            netText.setText(label);
        } catch (Throwable t) {
            wifiIcon.setLevel(0);
            netText.setText(R.string.net_off);
        }
    }

    private boolean tryStart(Intent... list) {
        for (Intent i : list) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return true;
            } catch (Throwable ignored) {
            }
        }
        toast(R.string.toast_fail);
        return false;
    }

    private void openWifiSettings() {
        tryStart(new Intent(Settings.ACTION_WIFI_SETTINGS), new Intent(Settings.ACTION_SETTINGS));
    }

    private void openBluetoothSettings() {
        tryStart(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS), new Intent(Settings.ACTION_SETTINGS));
    }

    private void openSystemSettings() {
        tryStart(new Intent(Settings.ACTION_SETTINGS));
    }

    private final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (a == null) return;
            if (Intent.ACTION_TIME_TICK.equals(a) || Intent.ACTION_TIME_CHANGED.equals(a)
                    || Intent.ACTION_TIMEZONE_CHANGED.equals(a)) {
                updateClock();
            } else if (a.startsWith("android.intent.action.PACKAGE")) {
                ui.removeCallbacks(reloadR);
                ui.postDelayed(reloadR, 700);
            } else {
                updateNet();
            }
        }
    };

    // ------------------------------------------------------------------ reloj en reposo

    private void buildSaver() {
        saver = new FrameLayout(this);
        saver.setBackgroundColor(0xDD000000);
        saver.setClickable(true);
        saver.setVisibility(View.GONE);
        saverClock = text("", 150, 0xFFFFFFFF, LIGHT);
        saver.addView(saverClock, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        root.addView(saver, new FrameLayout.LayoutParams(-1, -1));
    }

    private final Runnable idleR = new Runnable() {
        @Override
        public void run() {
            showSaver();
        }
    };

    private void resetIdle() {
        ui.removeCallbacks(idleR);
        int m = st.idleMin();
        if (m > 0 && !saverOn) ui.postDelayed(idleR, m * 60000L);
    }

    private void showSaver() {
        if (saverOn || menuLayer != null) {
            resetIdle();
            return;
        }
        saverOn = true;
        updateClock();
        saver.setAlpha(0f);
        saver.setVisibility(View.VISIBLE);
        saver.animate().alpha(1f).setDuration(700).setInterpolator(new DecelerateInterpolator()).start();
    }

    private void hideSaver() {
        saverOn = false;
        saver.animate().cancel();
        saver.setVisibility(View.GONE);
        saverClock.setTranslationX(0f);
        saverClock.setTranslationY(0f);
        resetIdle();
    }
}
