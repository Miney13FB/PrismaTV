package dev.prisma.tv;

import android.content.Context;
import android.view.FocusFinder;
import android.view.View;
import android.widget.ScrollView;

/**
 * Scroll vertical del Inicio. La barra superior (Bluetooth, Wi-Fi, Ajustes) no está dentro de él, así que cuando ya no
 * queda ninguna tarjeta más arriba, el scroll de Android se «comía» la pulsación de arriba para subir el contenido y
 * hacía falta pulsar dos veces. Ahora esa pulsación se deja pasar y el foco sube a la barra a la primera.
 */
final class HomeScroll extends ScrollView {
    HomeScroll(Context c) {
        super(c);
        setFocusable(false);   // el foco es de las tarjetas, nunca del contenedor
    }

    @Override
    public boolean arrowScroll(int direction) {
        if (direction == View.FOCUS_UP) {
            View cur = findFocus();
            if (cur == this) cur = null;
            if (FocusFinder.getInstance().findNextFocus(this, cur, direction) == null) return false;
        }
        return super.arrowScroll(direction);
    }
}
