package dev.prisma.tv;

import android.content.ComponentName;
import android.content.pm.ResolveInfo;

final class AppItem {
    String pkg;
    String label;
    ComponentName cn;
    boolean leanback;
    ResolveInfo ri;
}
