package dev.prisma.tv;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Interruptor estilo iPhone: verde si está activado, gris si está desactivado. */
final class SwitchView extends View {
    private boolean on;
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knob = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();

    SwitchView(Context c) {
        super(c);
        knob.setColor(0xFFFFFFFF);
        knob.setShadowLayer(3f, 0f, 1.5f, 0x55000000);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
    }

    boolean isOn() {
        return on;
    }

    void setOn(boolean v) {
        on = v;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        track.setColor(on ? 0xFF34C759 : 0xFF6E6E76);
        r.set(0, 0, w, h);
        c.drawRoundRect(r, h / 2f, h / 2f, track);
        float pad = h * 0.09f;
        float rad = h / 2f - pad;
        float cx = on ? w - h / 2f : h / 2f;
        c.drawCircle(cx, h / 2f, rad, knob);
    }
}
