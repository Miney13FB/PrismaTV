package dev.prisma.tv;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

/**
 * Mantiene Lumen (Inicio y pantalla de bloqueo) siempre en pantalla: ni se apaga la pantalla ni entra el
 * salvapantallas de Fire OS (que es lo que dejaba la pantalla en negro).
 * 1) Siempre: pantalla encendida (FLAG_KEEP_SCREEN_ON en la ventana + bloqueo de encendido).
 * 2) Con los permisos de ADB (una sola vez): además se sube el tiempo del salvapantallas y de la suspensión
 *    de Fire OS mientras Lumen está en pantalla, y se devuelven a su valor al salir de Lumen.
 */
final class AwakeGuard {
    /** "Nunca" para el salvapantallas de Fire OS (el mismo valor que usa Amazon). */
    private static final int NEVER_OFF = 2147460000;
    /** 24 horas: la suspensión del dispositivo prácticamente no llega. */
    private static final int NEVER_SLEEP = 86400000;
    private static final int DEF_OFF = 300000;
    private static final int DEF_SLEEP = 1200000;
    private static final String SLEEP_KEY = "sleep_timeout";

    private static final int CAN_SYSTEM = 1;
    private static final int CAN_SECURE = 2;

    private final Context ctx;
    private final SharedPreferences sp;
    private PowerManager.WakeLock wl;

    AwakeGuard(Context c) {
        ctx = c.getApplicationContext();
        sp = ctx.getSharedPreferences("prisma_awake", Context.MODE_PRIVATE);
    }

    /** Lumen está a la vista: la pantalla se mantiene encendida (es obligatorio, no hay ajuste para quitarlo). */
    @SuppressWarnings("deprecation")
    void apply() {
        try {
            if (wl == null) {
                PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
                wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ON_AFTER_RELEASE,
                        "lumen:awake");
                wl.setReferenceCounted(false);
            }
            if (!wl.isHeld()) wl.acquire();
        } catch (Throwable ignored) {
        }
        // sin los permisos de ADB no hay nada que cambiar ni que guardar: se sale sin leer ajustes, sin excepciones y sin
        // tocar el disco (antes, cada vuelta a Inicio hacía dos escrituras con sincronización en el hilo principal)
        int g = grants();
        if (g == 0) return;
        if (!sp.getBoolean("active", false)) {
            // se guardan YA los valores de Fire OS para poder devolverlos aunque Lumen se cierre de golpe: esta escritura es
            // síncrona a propósito (tiene que estar en el disco antes de tocar nada) y solo ocurre si de verdad se va a cambiar
            int off = readSystem();
            int sleep = readSecure();
            sp.edit().putInt("off", off).putInt("sleep", sleep).putBoolean("active", true).commit();
        }
        boolean a = (g & CAN_SYSTEM) != 0 && FireSettings.putSystem(ctx, Settings.System.SCREEN_OFF_TIMEOUT, NEVER_OFF);
        boolean b = (g & CAN_SECURE) != 0 && FireSettings.putSecure(ctx, SLEEP_KEY, NEVER_SLEEP);
        if (!a && !b) sp.edit().putBoolean("active", false).apply();
    }

    /** Lumen sale de la pantalla (se abre otra app o se cierra): todo vuelve a como estaba. */
    void restore() {
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Throwable ignored) {
        }
        if (!sp.getBoolean("active", false)) return;
        // se devuelven EXACTAMENTE los valores que tenía el usuario (si no se pudieron leer, los de Fire OS por defecto)
        int off = sp.getInt("off", -1);
        int sleep = sp.getInt("sleep", -1);
        if (off < 0) off = DEF_OFF;
        if (sleep < 0) sleep = DEF_SLEEP;
        int g = grants();
        boolean a = (g & CAN_SYSTEM) != 0 && FireSettings.putSystem(ctx, Settings.System.SCREEN_OFF_TIMEOUT, off);
        boolean b = (g & CAN_SECURE) != 0 && FireSettings.putSecure(ctx, SLEEP_KEY, sleep);
        // si no se pudo escribir nada (permiso retirado) se conservan los valores guardados para intentarlo luego
        // (apply: el valor ya está en memoria y el sistema lo vuelca al disco al parar la pantalla, sin bloquear el hilo principal)
        if (a || b) sp.edit().putBoolean("active", false).apply();
    }

    /**
     * Qué ajustes puede cambiar Lumen ahora mismo. Se consulta cada vez porque el permiso de ADB puede darse con Lumen ya
     * abierto. Con WRITE_SECURE_SETTINGS también se pueden escribir los del sistema; si no, hace falta el permiso
     * "Modificar ajustes del sistema". Si la consulta fallara, se intenta todo como antes.
     */
    private int grants() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return CAN_SYSTEM | CAN_SECURE;
        try {
            if (ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED) {
                return CAN_SYSTEM | CAN_SECURE;
            }
            return Settings.System.canWrite(ctx) ? CAN_SYSTEM : 0;
        } catch (Throwable t) {
            return CAN_SYSTEM | CAN_SECURE;
        }
    }

    private int readSystem() {
        try {
            return Settings.System.getInt(ctx.getContentResolver(), Settings.System.SCREEN_OFF_TIMEOUT);
        } catch (Throwable t) {
            return -1;
        }
    }

    private int readSecure() {
        try {
            return Settings.Secure.getInt(ctx.getContentResolver(), SLEEP_KEY);
        } catch (Throwable t) {
            return -1;
        }
    }
}
