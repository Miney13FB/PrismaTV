package dev.prisma.tv;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.PowerManager;
import android.provider.Settings;

/**
 * Mantiene Lumen (Inicio y pantalla de bloqueo) siempre en pantalla: ni se apaga la pantalla ni entra el
 * salvapantallas de Fire OS (que es lo que dejaba la pantalla en negro).
 * 1) Siempre: pantalla encendida (FLAG_KEEP_SCREEN_ON en la ventana + bloqueo de encendido).
 * 2) Con los permisos de ADB (una sola vez): además se sube el tiempo del salvapantallas y de la suspensión
 *    de Fire OS mientras Lumen está en pantalla, y se devuelven a su valor al salir de Lumen.
 */
final class AwakeGuard {
    /** "Nunca" para el salvapantallas de Fire OS (el mismo valor que usa Amazon). */
    private static final int NEVER_OFF = 2147460000;
    /** 24 horas: la suspensión del dispositivo prácticamente no llega. */
    private static final int NEVER_SLEEP = 86400000;
    private static final int DEF_OFF = 300000;
    private static final int DEF_SLEEP = 1200000;
    private static final String SLEEP_KEY = "sleep_timeout";

    private final Context ctx;
    private final SharedPreferences sp;
    private PowerManager.WakeLock wl;

    AwakeGuard(Context c) {
        ctx = c.getApplicationContext();
        sp = ctx.getSharedPreferences("prisma_awake", Context.MODE_PRIVATE);
    }

    /** Lumen está a la vista: la pantalla se mantiene encendida (es obligatorio, no hay ajuste para quitarlo). */
    @SuppressWarnings("deprecation")
    void apply() {
        try {
            if (wl == null) {
                PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
                wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ON_AFTER_RELEASE,
                        "lumen:awake");
                wl.setReferenceCounted(false);
            }
            if (!wl.isHeld()) wl.acquire();
        } catch (Throwable ignored) {
        }
        if (!sp.getBoolean("active", false)) {
            // se guardan YA los valores de Fire OS para poder devolverlos aunque Lumen se cierre de golpe
            int off = readSystem();
            int sleep = readSecure();
            sp.edit().putInt("off", off).putInt("sleep", sleep).putBoolean("active", true).commit();
        }
        boolean a = FireSettings.putSystem(ctx, Settings.System.SCREEN_OFF_TIMEOUT, NEVER_OFF);
        boolean b = FireSettings.putSecure(ctx, SLEEP_KEY, NEVER_SLEEP);
        if (!a && !b) sp.edit().putBoolean("active", false).commit();
    }

    /** Lumen sale de la pantalla (se abre otra app o se cierra): todo vuelve a como estaba. */
    void restore() {
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Throwable ignored) {
        }
        if (!sp.getBoolean("active", false)) return;
        // se devuelven EXACTAMENTE los valores que tenía el usuario (si no se pudieron leer, los de Fire OS por defecto)
        int off = sp.getInt("off", -1);
        int sleep = sp.getInt("sleep", -1);
        if (off < 0) off = DEF_OFF;
        if (sleep < 0) sleep = DEF_SLEEP;
        boolean a = FireSettings.putSystem(ctx, Settings.System.SCREEN_OFF_TIMEOUT, off);
        boolean b = FireSettings.putSecure(ctx, SLEEP_KEY, sleep);
        // si no se pudo escribir nada (permiso retirado) se conservan los valores guardados para intentarlo luego
        if (a || b) sp.edit().putBoolean("active", false).commit();
    }

    private int readSystem() {
        try {
            return Settings.System.getInt(ctx.getContentResolver(), Settings.System.SCREEN_OFF_TIMEOUT);
        } catch (Throwable t) {
            return -1;
        }
    }

    private int readSecure() {
        try {
            return Settings.Secure.getInt(ctx.getContentResolver(), SLEEP_KEY);
        } catch (Throwable t) {
            return -1;
        }
    }
}
