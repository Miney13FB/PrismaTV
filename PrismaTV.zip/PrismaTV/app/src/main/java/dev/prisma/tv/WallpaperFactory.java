package dev.prisma.tv;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;

/** Fondos abstractos generados por código: no ocupan nada en el APK. */
final class WallpaperFactory {
    static final int COUNT = 6;

    static Bitmap make(int style, int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        switch (((style % COUNT) + COUNT) % COUNT) {
            case 0: // Aurora
                vgrad(c, w, h, 0xFF050B1E, 0xFF0B2740);
                blob(c, 0.25f * w, 0.78f * h, 0.62f * w, 0x2DE0B5, 150);
                blob(c, 0.72f * w, 0.28f * h, 0.56f * w, 0x7B5CFF, 150);
                blob(c, 0.50f * w, 0.05f * h, 0.50f * w, 0x2AA7FF, 90);
                blob(c, 0.92f * w, 0.92f * h, 0.40f * w, 0x3CFF9C, 80);
                break;
            case 1: // Crepúsculo
                vgrad(c, w, h, 0xFF14103A, 0xFF3A1A55);
                blob(c, 0.50f * w, 1.05f * h, 0.72f * w, 0xFF8A3D, 210);
                blob(c, 0.14f * w, 0.70f * h, 0.50f * w, 0xFF4F9A, 120);
                blob(c, 0.85f * w, 0.25f * h, 0.45f * w, 0x6A4DFF, 110);
                break;
            case 2: // Océano
                vgrad(c, w, h, 0xFF021B2E, 0xFF04546E);
                blob(c, 0.62f * w, 0.18f * h, 0.55f * w, 0x1FD0D8, 110);
                blob(c, 0.18f * w, 0.85f * h, 0.55f * w, 0x0A7AA8, 130);
                rays(c, w, h);
                break;
            case 3: // Brasa
                vgrad(c, w, h, 0xFF120808, 0xFF2A0E0A);
                blob(c, 0.30f * w, 1.00f * h, 0.70f * w, 0xFF5A1F, 175);
                blob(c, 0.76f * w, 0.95f * h, 0.45f * w, 0xFFB347, 95);
                blob(c, 0.82f * w, 0.20f * h, 0.50f * w, 0xB1123C, 85);
                break;
            case 4: // Grafito
                vgrad(c, w, h, 0xFF0C0D10, 0xFF1A1D24);
                blob(c, 0.50f * w, 0.30f * h, 0.80f * w, 0x4A5568, 70);
                break;
            default: // Prisma
                vgrad(c, w, h, 0xFF0A0B14, 0xFF10111F);
                blob(c, 0.14f * w, 0.32f * h, 0.38f * w, 0xFF4D6D, 100);
                blob(c, 0.36f * w, 0.78f * h, 0.38f * w, 0xFFA24D, 95);
                blob(c, 0.56f * w, 0.30f * h, 0.38f * w, 0x3DDC97, 90);
                blob(c, 0.80f * w, 0.72f * h, 0.38f * w, 0x4D8DFF, 100);
                blob(c, 0.92f * w, 0.18f * h, 0.38f * w, 0xB24DFF, 95);
                break;
        }
        // Velo oscuro abajo para que los textos y el dock se lean bien.
        Paint p = new Paint();
        p.setShader(new LinearGradient(0, h * 0.40f, 0, h, 0x00000000, 0x80000000, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        return b;
    }

    private static void vgrad(Canvas c, int w, int h, int top, int bottom) {
        Paint p = new Paint();
        p.setShader(new LinearGradient(0, 0, 0, h, top, bottom, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
    }

    private static void blob(Canvas c, float cx, float cy, float r, int rgb, int alpha) {
        int inner = (alpha << 24) | (rgb & 0xFFFFFF);
        int outer = rgb & 0xFFFFFF;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new RadialGradient(cx, cy, r, inner, outer, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, p);
    }

    private static void rays(Canvas c, int w, int h) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0x0DFFFFFF);
        for (int i = 0; i < 5; i++) {
            float x = w * (0.15f + i * 0.17f);
            Path path = new Path();
            path.moveTo(x, 0);
            path.lineTo(x + w * 0.07f, 0);
            path.lineTo(x + w * 0.30f, h);
            path.lineTo(x + w * 0.12f, h);
            path.close();
            c.drawPath(path, p);
        }
    }
}
