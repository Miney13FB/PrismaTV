package dev.prisma.tv;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Engranaje de ajustes dibujado por código. */
final class GearView extends View {
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tooth = new Paint(Paint.ANTI_ALIAS_FLAG);

    GearView(Context c) {
        super(c);
        ring.setStyle(Paint.Style.STROKE);
        ring.setColor(0xFFFFFFFF);
        tooth.setStyle(Paint.Style.STROKE);
        tooth.setStrokeCap(Paint.Cap.ROUND);
        tooth.setColor(0xFFFFFFFF);
    }

    @Override
    protected void onDraw(Canvas c) {
        float s = Math.min(getWidth(), getHeight());
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        ring.setStrokeWidth(s * 0.13f);
        tooth.setStrokeWidth(s * 0.15f);
        c.drawCircle(cx, cy, s * 0.26f, ring);
        c.save();
        c.translate(cx, cy);
        for (int i = 0; i < 8; i++) {
            c.drawLine(0, -s * 0.34f, 0, -s * 0.43f, tooth);
            c.rotate(45f);
        }
        c.restore();
    }
}
