package dev.prisma.tv;

import android.animation.ObjectAnimator;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Bienvenida de la primera vez: la lente de Lumen se enciende, saludo, nombre, tiempo y «todo listo». Se maneja solo
 * con el mando (flechas + OK, Atrás para volver). Lo que se elige se guarda en el momento; MainActivity apunta que la
 * configuración inicial está hecha cuando se pulsa el último botón, y a partir de ahí no vuelve a salir.
 */
final class Welcome extends FrameLayout {
    private static final int STEPS = 4;
    private static final String[] HELLO = {"Bienvenido", "Welcome", "Benvingut", "Bienvenue", "Willkommen",
            "Benvenuto", "Bem-vindo"};

    private final MainActivity a;
    private final Runnable done;
    private final FrameLayout stage;
    private final Dots dots;
    private final Aurora aurora;
    private ObjectAnimator breath;
    private final String[] hello;
    private int step = -1;
    private int helloIdx;
    private View cur;
    private View focusTarget;
    private boolean busy;
    private boolean finished;
    private boolean entering;
    private boolean lit;               // la lente ya se encendió una vez (no se repite al volver al primer paso)
    private LumenMark doneMark;
    private Pill lastBack;

    // piezas del paso que está en pantalla (se ponen a null al cambiar de paso)
    private TextView helloTv;
    private Pill nameField, nameNext, cityPill, cityNext, homeBtn;

    Welcome(MainActivity act, Runnable onDone) {
        super(act);
        a = act;
        done = onDone;
        hello = helloList();
        setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xB8080B14, 0x990A0E18, 0xDE070A12}));
        setClickable(true);
        setFocusable(false);   // (en Android 8+ una vista pulsable es enfocable: la bienvenida no debe quedarse el foco)
        setClipChildren(false);

        aurora = new Aurora(act);
        aurora.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        addView(aurora, new FrameLayout.LayoutParams(-1, -1));
        if (a.st.anim()) addView(new Motes(act, a.u), new FrameLayout.LayoutParams(-1, -1));

        stage = new FrameLayout(act);
        stage.setClipChildren(false);
        addView(stage, new FrameLayout.LayoutParams(-1, -1));

        dots = new Dots(act, STEPS, a.px(9), a.px(14), a.px(28));
        FrameLayout.LayoutParams dp = new FrameLayout.LayoutParams(a.px(220), a.px(12),
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        dp.bottomMargin = a.px(54);
        addView(dots, dp);
    }

    /** El saludo en tu idioma primero y después en otros, que van cambiando como en el «Hola» de Apple. */
    private String[] helloList() {
        ArrayList<String> l = new ArrayList<>();
        String mine = a.getString(R.string.wl_hello);
        l.add(mine);
        for (String s : HELLO) {
            if (!s.equalsIgnoreCase(mine)) l.add(s);
        }
        return l.toArray(new String[0]);
    }

    void start() {
        if (a.st.anim()) {
            breath = ObjectAnimator.ofFloat(aurora, View.ALPHA, 1f, 0.72f);
            breath.setDuration(7000);
            breath.setRepeatCount(ObjectAnimator.INFINITE);
            breath.setRepeatMode(ObjectAnimator.REVERSE);
            breath.setInterpolator(new AccelerateDecelerateInterpolator());
            breath.start();
        }
        go(0);
        // en el primer arranque esto ocurre dentro de onCreate, cuando la ventana todavía no existe: se pide el foco otra
        // vez en cuanto se pone en pantalla
        post(new Runnable() {
            @Override
            public void run() {
                if (!finished) focusNow(focusTarget);
            }
        });
    }

    private void focusNow(View v) {
        if (v == null) return;
        v.requestFocus();
        // sin ventana todavía el escuchador global de foco no avisa: se pinta el botón enfocado a mano
        if (!isAttachedToWindow() && v instanceof FocusFx && v.isFocused()) ((FocusFx) v).fx(true, 0, false);
    }

    /** Botón Atrás del mando: vuelve un paso (en el primero no hace nada). Siempre se da por atendido. */
    boolean back() {
        if (busy || finished) return true;
        if (step > 0) {
            a.sfx.play(Sfx.BACK);
            go(step - 1);
        }
        return true;
    }

    @Override
    protected void onDetachedFromWindow() {
        a.ui.removeCallbacks(helloR);
        a.ui.removeCallbacks(finishR);
        if (breath != null) {
            breath.cancel();
            breath = null;
        }
        super.onDetachedFromWindow();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        // con otra app delante no se gasta nada en animar la luz de fondo
        if (breath != null) {
            if (visibility == View.VISIBLE) breath.resume();
            else breath.pause();
        }
    }

    // ------------------------------------------------------------------ pasos y transiciones

    private final Runnable unbusy = new Runnable() {
        @Override
        public void run() {
            busy = false;
        }
    };

    /**
     * Red de seguridad: si algo fallara dentro de la bienvenida, se da por terminada y se entra al Inicio
     * (nunca se deja al usuario atrapado en ella).
     */
    private void finish() {
        if (finished) return;
        finished = true;
        a.ui.removeCallbacks(helloR);
        a.ui.removeCallbacks(unbusy);
        a.ui.removeCallbacks(finishR);
        done.run();
    }

    private void go(int to) {
        if (busy || finished || entering || to < 0 || to >= STEPS || to == step) return;
        try {
            goStep(to);
        } catch (Throwable t) {
            finish();
        }
    }

    private void goStep(int to) {
        final boolean fwd = to > step;
        final View old = cur;
        a.ui.removeCallbacks(helloR);
        helloTv = null;
        nameField = null;
        nameNext = null;
        cityPill = null;
        cityNext = null;
        homeBtn = null;
        doneMark = null;
        focusTarget = null;
        step = to;

        final LinearLayout nv = build(to);
        stage.addView(nv, new FrameLayout.LayoutParams(-1, -1));
        cur = nv;
        dots.setIndex(to);
        // el paso que sale sigue 0,3 s en pantalla: que las flechas ya no puedan llevar el foco a sus botones
        if (old instanceof ViewGroup) ((ViewGroup) old).setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        focusNow(focusTarget);

        if (!a.st.anim()) {
            if (old != null) stage.removeView(old);
            return;
        }
        final boolean first = old == null;
        busy = true;
        a.ui.removeCallbacks(unbusy);
        a.ui.postDelayed(unbusy, first ? 450 : 560);
        int dx = a.px(70) * (fwd ? 1 : -1);
        nv.setAlpha(0f);
        nv.setTranslationX(first ? 0f : dx);
        nv.setTranslationY(first ? a.px(26) : 0f);
        nv.animate().alpha(1f).translationX(0f).translationY(0f)
                .setStartDelay(first ? 200 : 140).setDuration(first ? 800 : 440)
                .setInterpolator(new DecelerateInterpolator(1.6f)).start();
        if (old != null) {
            old.animate().cancel();
            old.animate().alpha(0f).translationX(-dx / 2f).setDuration(220)
                    .setInterpolator(new AccelerateInterpolator()).start();
            a.ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    boolean lost = old.hasFocus();
                    stage.removeView(old);
                    if (lost && !finished) focusNow(focusTarget);
                }
            }, 320);
        }
    }

    private LinearLayout build(int i) {
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        col.setClipChildren(false);   // el botón enfocado crece un 6 %: que no se recorte en los bordes
        col.setPadding(a.px(80), a.px(40), a.px(80), a.px(90));
        switch (i) {
            case 0:
                buildHello(col);
                break;
            case 1:
                buildName(col);
                break;
            case 2:
                buildWeather(col);
                break;
            default:
                buildDone(col);
                break;
        }
        return col;
    }

    // ------------------------------------------------------------------ piezas comunes

    private TextView title(String s, float size) {
        TextView t = a.text(s, size, 0xFFFFFFFF, MainActivity.LIGHT);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private TextView sub(String s) {
        TextView t = a.text(s, 24, 0xB8FFFFFF, MainActivity.REG);
        t.setGravity(Gravity.CENTER);
        t.setMaxWidth(a.px(780));
        t.setLineSpacing(0f, 1.15f);
        return t;
    }

    private void add(LinearLayout col, View v, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = a.px(top);
        col.addView(v, lp);
    }

    /** La lente de Lumen: con vida (brillo que se mueve) si las animaciones están activadas. */
    private LumenMark addMark(LinearLayout col, int size, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(a.px(size), a.px(size));
        lp.topMargin = a.px(top);
        LumenMark m = new LumenMark(a);
        m.setIdle(a.st.anim());
        col.addView(m, lp);
        return m;
    }

    /** El nombre en mayúsculas muy espaciadas, como en un título de película. */
    private TextView wordmark() {
        TextView t = a.text(a.getString(R.string.app_name).toUpperCase(), 22, 0xE6FFFFFF, MainActivity.MEDIUM);
        t.setLetterSpacing(0.52f);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private Pill pill(String text, boolean primary, int minW) {
        Pill p = new Pill(a, text, primary, false);
        p.setMinimumWidth(a.px(minW));
        return p;
    }

    private LinearLayout.LayoutParams plp(int left) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, a.px(64));
        lp.leftMargin = a.px(left);
        return lp;
    }

    private LinearLayout row(LinearLayout col, int top) {
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        r.setClipChildren(false);
        add(col, r, top);
        return r;
    }

    private void onOk(View v, final Runnable r) {
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                try {
                    a.sfx.play(Sfx.SELECT);
                    r.run();
                } catch (Throwable t) {
                    finish();
                }
            }
        });
    }

    /** Fila de abajo: «Atrás» (si procede, queda en lastBack) y el botón principal, que es el que devuelve. */
    private Pill buttons(LinearLayout col, int top, boolean back, String label, int minW, Runnable next) {
        LinearLayout r = row(col, top);
        lastBack = null;
        if (back) {
            Pill b = pill(a.getString(R.string.wl_back), false, 150);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    back();
                }
            });
            r.addView(b, plp(0));
            lastBack = b;
        }
        Pill n = pill(label, true, minW);
        onOk(n, next);
        r.addView(n, plp(back ? 18 : 0));
        return n;
    }

    /** Hace que «abajo» desde {@code from} caiga siempre en {@code to} (así desde cualquier fila se llega al botón principal). */
    private static void down(View from, View to) {
        if (to.getId() == View.NO_ID) to.setId(View.generateViewId());
        from.setNextFocusDownId(to.getId());
    }

    /** Igual que {@link #down} pero hacia arriba. */
    private static void up(View from, View to) {
        if (to.getId() == View.NO_ID) to.setId(View.generateViewId());
        from.setNextFocusUpId(to.getId());
    }

    private final Runnable toNext = new Runnable() {
        @Override
        public void run() {
            go(step + 1);
        }
    };

    // ------------------------------------------------------------------ 1 · saludo

    private final Runnable helloR = new Runnable() {
        @Override
        public void run() {
            final TextView t = helloTv;
            if (t == null || step != 0) return;
            helloIdx = (helloIdx + 1) % hello.length;
            if (!a.st.anim()) {
                t.setText(hello[helloIdx]);
            } else {
                t.animate().alpha(0f).setDuration(300).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        if (step != 0 || helloTv != t) return;
                        t.setText(hello[helloIdx]);
                        t.animate().alpha(1f).setDuration(420).start();
                    }
                }).start();
            }
            a.ui.postDelayed(this, 2800);
        }
    };

    private void buildHello(LinearLayout col) {
        LumenMark m = addMark(col, 280, 0);
        if (!lit && a.st.anim()) {
            lit = true;
            m.ignite(380);       // la lente se enciende a la vez que aparece el paso
        }
        add(col, wordmark(), -22);
        helloIdx = 0;
        helloTv = title(hello[0], 80);
        add(col, helloTv, 26);
        add(col, sub(a.getString(R.string.wl_sub_0)), 14);
        focusTarget = buttons(col, 50, false, a.getString(R.string.wl_start), 250, toNext);
        a.ui.postDelayed(helloR, 2800);
    }

    // ------------------------------------------------------------------ 2 · nombre

    private void buildName(LinearLayout col) {
        addMark(col, 120, -10);
        add(col, title(a.getString(R.string.wl_name_title), 58), -6);
        add(col, sub(a.getString(R.string.wl_name_sub)), 14);
        nameField = pill("", false, 560);
        nameField.setMaxLabelWidth(a.px(480));
        onOk(nameField, new Runnable() {
            @Override
            public void run() {
                askName();
            }
        });
        LinearLayout.LayoutParams lp = plp(0);
        lp.topMargin = a.px(46);
        col.addView(nameField, lp);
        nameNext = buttons(col, 40, true, a.getString(R.string.wl_next), 220, toNext);
        down(nameField, nameNext);
        up(nameNext, nameField);
        if (lastBack != null) up(lastBack, nameField);
        refreshName();
        focusTarget = nameField;
    }

    private void refreshName() {
        if (nameField == null) return;
        String n = a.st.name();
        if (n.isEmpty()) nameField.setText(a.getString(R.string.wl_name_field), true);
        else nameField.setText(n, false);
        if (nameNext != null) nameNext.setText(a.getString(n.isEmpty() ? R.string.wl_skip : R.string.wl_next), false);
    }

    private void askName() {
        final EditText et = new EditText(a);
        et.setSingleLine(true);
        et.setText(a.st.name());
        et.setSelection(et.getText().length());
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(R.string.set_name)
                .setView(et)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        a.st.setName(et.getText().toString());
                        a.updateClock();
                        refreshName();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    // ------------------------------------------------------------------ 3 · tiempo

    private void buildWeather(LinearLayout col) {
        addMark(col, 120, -10);
        add(col, title(a.getString(R.string.wl_wx_title), 58), -6);
        add(col, sub(a.getString(R.string.wl_wx_sub)), 14);
        cityPill = pill("", false, 560);
        cityPill.setMaxLabelWidth(a.px(480));
        onOk(cityPill, new Runnable() {
            @Override
            public void run() {
                askCity();
            }
        });
        LinearLayout.LayoutParams lp = plp(0);
        lp.topMargin = a.px(46);
        col.addView(cityPill, lp);

        LinearLayout r = row(col, 18);
        homeBtn = pill("", false, 300);
        onOk(homeBtn, new Runnable() {
            @Override
            public void run() {
                a.st.setWxHome(!a.st.wxHome());
                a.updateWeatherViews();
                refreshHome();
            }
        });
        r.addView(homeBtn, plp(0));

        cityNext = buttons(col, 36, true, a.getString(R.string.wl_next), 220, toNext);
        down(homeBtn, cityNext);
        refreshCity();
        refreshHome();
        focusTarget = cityPill;
    }

    private String cityLabel() {
        List<String[]> pl = a.st.places();
        if (pl.isEmpty()) return null;
        String[] p = pl.get(0);
        return p[1] == null || p[1].isEmpty() ? p[0] : p[0] + ", " + p[1];
    }

    private void refreshCity() {
        if (cityPill == null) return;
        String c = cityLabel();
        if (c == null) cityPill.setText(a.getString(R.string.wl_wx_city), true);
        else cityPill.setText(c, false);
        if (cityNext != null) cityNext.setText(a.getString(c == null ? R.string.wl_skip : R.string.wl_next), false);
    }

    private void refreshHome() {
        if (homeBtn == null) return;
        boolean on = a.st.wxHome();
        homeBtn.setText(a.getString(on ? R.string.wl_home_on : R.string.wl_home_off), false);
        homeBtn.setSelectedState(on);
    }

    private void askCity() {
        final EditText et = new EditText(a);
        et.setSingleLine(true);
        et.setHint(R.string.wx_hint);
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(R.string.wx_add)
                .setView(et)
                .setPositiveButton(R.string.wx_search, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String q = et.getText().toString().trim();
                        if (!q.isEmpty()) searchCity(q);
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void searchCity(String q) {
        a.toast(R.string.wx_searching);
        a.wx.search(q, new Weather.Found() {
            @Override
            public void found(final List<Weather.Hit> hits, boolean error) {
                if (error) {
                    a.toast(R.string.wx_error);
                    return;
                }
                if (hits.isEmpty()) {
                    a.toast(R.string.wx_none);
                    return;
                }
                CharSequence[] labels = new CharSequence[hits.size()];
                for (int i = 0; i < labels.length; i++) labels[i] = hits.get(i).label();
                new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                        .setTitle(R.string.wx_pick)
                        .setItems(labels, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dlg, int which) {
                                setCity(hits.get(which));
                            }
                        })
                        .setNegativeButton(android.R.string.cancel, null)
                        .show();
            }
        });
    }

    /** La ciudad elegida pasa a ser la primera de la lista (las que ya hubiera siguen detrás). */
    private void setCity(Weather.Hit h) {
        ArrayList<String[]> l = new ArrayList<>(a.st.places());
        String[] p = {h.name, h.country, String.valueOf(h.lat), String.valueOf(h.lon)};
        for (int i = l.size() - 1; i >= 0; i--) {
            if (Weather.key(l.get(i)).equals(Weather.key(p))) l.remove(i);
        }
        l.add(0, p);
        while (l.size() > 5) l.remove(l.size() - 1);
        a.st.setPlaces(l);
        a.st.setWxLock(true);
        a.refreshWeather(true);
        a.updateWeatherViews();
        refreshCity();
    }

    // ------------------------------------------------------------------ 4 · todo listo

    private final Runnable finishR = new Runnable() {
        @Override
        public void run() {
            finish();
        }
    };

    private void buildDone(LinearLayout col) {
        doneMark = addMark(col, 230, 0);
        String nm = a.st.name();
        add(col, title(nm.isEmpty() ? a.getString(R.string.wl_done_title)
                : a.getString(R.string.wl_done_name, nm), 62), 0);
        add(col, sub(a.getString(R.string.wl_done_sub)), 14);
        focusTarget = buttons(col, 46, true, a.getString(R.string.wl_enter), 300, new Runnable() {
            @Override
            public void run() {
                enter();
            }
        });
    }

    /** «Entrar»: la lente estalla en una onda de luz, el texto se apaga y, un instante después, se abre el Inicio. */
    private void enter() {
        if (entering || finished) return;
        entering = true;
        if (!a.st.anim() || doneMark == null || cur == null) {
            finish();
            return;
        }
        busy = true;
        doneMark.bloom();
        if (cur instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) cur;
            g.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
            for (int i = 0; i < g.getChildCount(); i++) {
                View v = g.getChildAt(i);
                if (v != doneMark) v.animate().alpha(0f).setDuration(260).start();
            }
        }
        a.ui.postDelayed(finishR, 420);
    }

    // ------------------------------------------------------------------ dibujo

    /** Puntos de progreso: el del paso actual se estira. */
    static final class Dots extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int n;
        private final float dot, gap, wide;
        private int idx;

        Dots(Context c, int n, float dot, float gap, float wide) {
            super(c);
            this.n = n;
            this.dot = dot;
            this.gap = gap;
            this.wide = wide;
        }

        void setIndex(int i) {
            idx = i;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float h = getHeight();
            float total = (n - 1) * (dot + gap) + wide;
            float x = (getWidth() - total) / 2f;
            for (int i = 0; i < n; i++) {
                boolean on = i == idx;
                float w = on ? wide : dot;
                p.setColor(on ? 0xFFFFFFFF : 0x59FFFFFF);
                c.drawRoundRect(x, (h - dot) / 2f, x + w, (h + dot) / 2f, dot / 2f, dot / 2f, p);
                x += w + gap;
            }
        }
    }

    /** Resplandores fríos de fondo, con un foco de luz tras la lente (se dibuja una vez y se guarda como capa). */
    static final class Aurora extends View {
        private static final int[] COL = {0xFF5E5CE6, 0xFF0A84FF, 0xFF30B0C7, 0xFF3B4CCA, 0xFFBFDFFF};
        private static final int[] ALPHA = {0x40, 0x46, 0x34, 0x30, 0x42};
        private static final float[][] POS = {{0.06f, 0.08f, 0.70f}, {0.98f, 0.16f, 0.62f},
                {0.82f, 1.05f, 0.78f}, {0.00f, 1.02f, 0.62f}, {0.50f, 0.30f, 0.60f}};
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float[] cx = new float[COL.length], cy = new float[COL.length], r = new float[COL.length];
        private RadialGradient[] g;

        Aurora(Context c) {
            super(c);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            if (w <= 0 || h <= 0) {   // un degradado radial con radio 0 haría fallar la app: sin tamaño no se dibuja nada
                g = null;
                return;
            }
            g = new RadialGradient[COL.length];
            for (int i = 0; i < COL.length; i++) {
                cx[i] = POS[i][0] * w;
                cy[i] = POS[i][1] * h;
                r[i] = POS[i][2] * h;
                int rgb = COL[i] & 0x00FFFFFF;
                g[i] = new RadialGradient(cx[i], cy[i], r[i], rgb | (ALPHA[i] << 24), rgb, Shader.TileMode.CLAMP);
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            if (g == null) return;
            for (int i = 0; i < g.length; i++) {
                p.setShader(g[i]);
                c.drawCircle(cx[i], cy[i], r[i], p);
            }
        }
    }

    /** Motas de luz que suben muy despacio por detrás del texto (como polvo en un haz de luz). */
    static final class Motes extends View {
        private static final int N = 18;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float[] x = new float[N], y = new float[N], rad = new float[N], vel = new float[N],
                ph = new float[N], al = new float[N];
        private final Random rnd = new Random(7);
        private final float unit;
        private long last;

        Motes(Context c, float unit) {
            super(c);
            this.unit = unit;
            for (int i = 0; i < N; i++) {
                x[i] = rnd.nextFloat();
                y[i] = rnd.nextFloat();
                rad[i] = 1.3f + rnd.nextFloat() * 2.8f;
                vel[i] = 0.010f + rnd.nextFloat() * 0.026f;
                ph[i] = rnd.nextFloat() * 6.2831853f;
                al[i] = 0.14f + rnd.nextFloat() * 0.30f;
            }
        }

        private static float edge(float v) {
            float k = Math.min(1f, Math.min(v, 1f - v) / 0.14f);
            return k < 0f ? 0f : k;
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            last = 0;
            postInvalidateOnAnimation();
        }

        @Override
        protected void onWindowVisibilityChanged(int visibility) {
            super.onWindowVisibilityChanged(visibility);
            if (visibility == View.VISIBLE) {
                last = 0;
                postInvalidateOnAnimation();
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            long now = SystemClock.uptimeMillis();
            float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1000f);
            last = now;
            int w = getWidth(), h = getHeight();
            for (int i = 0; i < N; i++) {
                y[i] -= vel[i] * dt;
                ph[i] += dt * 0.55f;
                if (y[i] < -0.04f) {
                    y[i] = 1.04f;
                    x[i] = rnd.nextFloat();
                }
                float tw = 0.62f + 0.38f * (float) Math.sin(ph[i] * 1.7f + i);
                float a = al[i] * tw * edge(y[i]);
                if (a <= 0.01f) continue;
                float px = (x[i] + 0.012f * (float) Math.sin(ph[i])) * w;
                float py = y[i] * h;
                float r = rad[i] * unit;
                p.setColor((Math.round(a * 70f) << 24) | 0xDCEBFF);
                c.drawCircle(px, py, r * 2.6f, p);
                p.setColor((Math.round(a * 255f) << 24) | 0xE8F2FF);
                c.drawCircle(px, py, r, p);
            }
            if (isAttachedToWindow() && getWindowVisibility() == View.VISIBLE) postInvalidateOnAnimation();
        }
    }
}
