package dev.prisma.tv;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Fondos oficiales de GTA VI: los fondos de pantalla que Rockstar Games ofrece para descargar en su web
 * (rockstargames.com/VI → Descargas → «Artwork &amp; Wallpapers»). Lumen no lleva ninguna imagen dentro: las baja de
 * Rockstar cuando hacen falta, igual que las fotos de las demás categorías.
 *
 * Los nombres de archivo de esa web llevan un código que cambia si Rockstar vuelve a publicar la página, así que la
 * lista se relee de la página oficial de vez en cuando; la de abajo es solo la copia de seguridad. Esta clase no usa
 * Android: se puede probar sola.
 */
final class GtaWalls {
    private GtaWalls() {
    }

    static final String PAGE = "https://www.rockstargames.com/VI/downloads/artwork-wallpapers";
    static final String BASE = "https://www.rockstargames.com/VI/_next/static/media/";
    /** Anchos que se piden a su servidor de imágenes, por orden; 0 = el archivo tal cual. */
    static final int[] WIDTHS = {1280, 1920, 3840, 0};

    /** Copia de seguridad: los fondos horizontales de la página oficial (sin las versiones con el logotipo encima). */
    private static final String[] BUILTIN = {
            "Jason_Lucia_Lock_And_Load_landscape.0l9s5w7ih9p~3.jpg",
            "The_Album_Cover_Art_landscape.000ifb9a.j-gp.jpg",
            "Jason_and_Lucia_Robbery_landscape.09c8a~do21h4p.jpg",
            "Official_Cover_Art_landscape.12.uu2irr.2_a.jpg",
            "Jason_and_Lucia_Beach_landscape.0419q._86ukpt.jpg",
            "Jason_and_Lucia_02_landscape.0cosv-uzbpt91.jpg",
            "Jason_and_Lucia_01_landscape.12x2gvspcm_3m.jpg",
            "Jason_and_Lucia_Motel_landscape.08edvuwtm-20v.jpg",
            "Cal_Hampton_landscape.17k7bnt3myg.2.jpg",
            "Boobie_Ike_landscape.0ldnbn87k-8mq.jpg",
            "DreQuan_Priest_landscape.0_b7hszyze6cy.jpg",
            "Real_Dimez_landscape.0637akp_a5a_q.jpg",
            "Raul_Bautista_landscape.11_3hd0fr69~j.jpg",
            "Brian_Heder_landscape.0a-egj5b8yo1q.jpg",
            "Vice_City_Postcard_landscape.0v2njmlk2n-qm.jpg",
            "Leonida_Keys_Postcard_landscape.05oezf2h--~ed.jpg",
            "Port_Gellhorn_Postcard_landscape.176c2o75nmcr8.jpg",
            "Ambrosia_Postcard_landscape.0gd~9a41ia-rt.jpg",
            "Grassrivers_Postcard_landscape.15-10i39nhex2.jpg",
            "Mount_Kalaga_National_Park_Postcard_landscape.0c1cb4ocq16n3.jpg",
    };

    /** Un fondo horizontal de la web de Rockstar: «Nombre_landscape.código.jpg» dentro de /VI/_next/static/media/. */
    private static final String NAME = "[A-Za-z0-9_%\\-]+_landscape\\.[A-Za-z0-9_\\-.~]+?\\.(?:jpe?g|png|webp)";
    private static final Pattern IN_PAGE = Pattern.compile("/VI/_next/static/media/(" + NAME + ")");
    private static final Pattern VALID = Pattern.compile(NAME);

    /** La copia de seguridad. */
    static List<String> builtin() {
        return new ArrayList<>(Arrays.asList(BUILTIN));
    }

    /** ¿Es un nombre de archivo de fondo con la forma esperada? (para no fiarse de lo que haya guardado ni de la web) */
    static boolean valid(String file) {
        return file != null && file.length() < 160 && VALID.matcher(file).matches();
    }

    static boolean isRockstar(String url) {
        return url != null && url.startsWith("https://www.rockstargames.com/");
    }

    /** Dirección completa de un fondo (con el ancho pedido, o la del archivo tal cual si es 0). */
    static String withWidth(String url, int width) {
        return width > 0 ? url + "?akim=1&imdensity=1&imwidth=" + width : url;
    }

    /**
     * Lee el código de la página oficial y devuelve los nombres de los fondos horizontales, sin repetir y sin las
     * versiones «With Logo» (las mismas imágenes con el logotipo encima, que molestan como fondo).
     */
    static List<String> parse(String html) {
        ArrayList<String> out = new ArrayList<>();
        if (html == null || html.isEmpty()) return out;
        String t = html.replace("\\/", "/").replace("\\u0026", "&").replace("&amp;", "&");
        LinkedHashSet<String> all = new LinkedHashSet<>();
        Matcher m = IN_PAGE.matcher(t);
        while (m.find()) all.add(m.group(1));
        ArrayList<String> plain = new ArrayList<>();
        for (String f : all) {
            if (!f.contains("_With_Logo")) plain.add(f);
        }
        out.addAll(plain.size() >= 3 ? plain : all);
        return out;
    }

    /** «Jason_and_Lucia_01_landscape.xxxx.jpg» → «Jason and Lucia 01». */
    static String title(String file) {
        String n = file == null ? "" : file;
        int i = n.indexOf("_landscape");
        if (i > 0) n = n.substring(0, i);
        n = n.replace('_', ' ').trim();
        if (n.startsWith("The ")) n = n.substring(4);
        return n;
    }

    /** Lo que se muestra como crédito en la pantalla de bloqueo. */
    static String credit(String file) {
        return "Rockstar Games · " + title(file);
    }
}
