package dev.prisma.tv;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Fondos oficiales de GTA VI: las imágenes que Rockstar Games publica en su web, en la página de capturas
 * (rockstargames.com/VI/media/screenshots), y solo las de formato 16:9. Lumen no lleva ninguna imagen dentro: las baja de
 * Rockstar cuando hacen falta, igual que las fotos de las demás categorías.
 *
 * Esa página mezcla formatos, y los nombres de archivo llevan un código que cambia si Rockstar vuelve a publicarla. Por eso
 * la lista se relee de la página oficial de vez en cuando y cada imagen se comprueba al bajarla (si no es de 16:9 no se
 * usa nunca); la de abajo es solo la copia de seguridad. Esta clase no usa Android: se puede probar sola.
 */
final class GtaWalls {
    private GtaWalls() {
    }

    static final String PAGE = "https://www.rockstargames.com/VI/media/screenshots";
    static final String BASE = "https://www.rockstargames.com/VI/_next/static/media/";
    /** Anchos que se piden a su servidor de imágenes, por orden; 0 = el archivo tal cual. */
    static final int[] WIDTHS = {1280, 1920, 3840, 0};

    /** Copia de seguridad: imágenes de esa página oficial (las que se conocen; la lista completa se lee de la web). */
    private static final String[] BUILTIN = {
            "Jason_and_Lucia_14.10e7v.06pcm_t.jpg",
            "Lucia_Caminos_12.0saq9ns-~xj03.jpg",
            "Vice_City_27.0d2e~w_r93hmh.jpg",
            "ULTIMATE_EDITION_02.0q-6.nrtf~jj0.jpg",
            "ULTIMATE_EDITION_GROTTI_CHEETAH_01.0a.wy3s_ogjey.jpg",
            "ULTIMATE_EDITION_HAWK_AND_LITTLE_MORGAN_REVOLVERS_01.0~3pdc~~sing4.jpg",
            "VINTAGE_VICE_CITY_PACK_01.05zaof7o1uz.3.jpg",
            "VINTAGE_VICE_CITY_PACK_VAPID_STANIER_01.004m_8d1~qngy.jpg",
            "VINTAGE_VICE_CITY_PACK_EXCLUSIVE_LOOKS_03.0au1tphsftqm5.jpg",
    };

    /** Una imagen de esa página: «Nombre_NN.código.jpg» dentro de /_next/static/media/ (NN es el número de la imagen). */
    private static final String NAME = "[A-Za-z0-9_%\\-]+_[0-9]{1,3}\\.[A-Za-z0-9_\\-.~]+?\\.(?:jpe?g|png|webp)";
    private static final Pattern IN_PAGE = Pattern.compile("/_next/static/media/(" + NAME + ")");
    private static final Pattern VALID = Pattern.compile(NAME);

    /** La copia de seguridad. */
    static List<String> builtin() {
        return new ArrayList<>(Arrays.asList(BUILTIN));
    }

    /** ¿Es un nombre de archivo de imagen con la forma esperada? (para no fiarse de lo que haya guardado ni de la web) */
    static boolean valid(String file) {
        return file != null && file.length() < 160 && VALID.matcher(file).matches();
    }

    static boolean isRockstar(String url) {
        return url != null && url.startsWith("https://www.rockstargames.com/");
    }

    /** Dirección completa de un fondo (con el ancho pedido, o la del archivo tal cual si es 0). */
    static String withWidth(String url, int width) {
        return width > 0 ? url + "?akim=1&imdensity=1&imwidth=" + width : url;
    }

    /** ¿Una imagen de ese tamaño en píxeles es de 16:9? (con un margen pequeño por el redondeo de los píxeles) */
    static boolean isWide(int w, int h) {
        if (w <= 0 || h <= 0) return false;
        float r = (float) w / (float) h;
        return r >= 1.74f && r <= 1.82f;
    }

    /**
     * Lee el código de la página oficial y devuelve los nombres de sus imágenes, sin repetir y en el orden de la página.
     * El formato de cada una (si es de 16:9) no consta en el código: se comprueba al bajarla.
     */
    static List<String> parse(String html) {
        ArrayList<String> out = new ArrayList<>();
        if (html == null || html.isEmpty()) return out;
        // las barras pueden venir escritas de otras formas dentro del código de la página (JSON, direcciones codificadas)
        String t = html.replace("\\/", "/").replace("\\u002F", "/").replace("\\u002f", "/").replace("%2F", "/")
                .replace("%2f", "/");
        LinkedHashSet<String> all = new LinkedHashSet<>();
        Matcher m = IN_PAGE.matcher(t);
        while (m.find() && all.size() < 500) all.add(m.group(1));
        out.addAll(all);
        return out;
    }

    /** «Jason_and_Lucia_14.xxxx.jpg» → «Jason and Lucia 14»; «ULTIMATE_EDITION_02.xxxx.jpg» → «Ultimate Edition 02». */
    static String title(String file) {
        String n = file == null ? "" : file;
        int i = n.indexOf('.');
        if (i > 0) n = n.substring(0, i);
        n = n.replace('_', ' ').trim();
        if (!n.isEmpty() && n.equals(n.toUpperCase(Locale.ROOT))) {
            // un nombre escrito todo en mayúsculas se muestra con la inicial de cada palabra
            StringBuilder sb = new StringBuilder(n.length());
            boolean up = true;
            for (int k = 0; k < n.length(); k++) {
                char ch = n.charAt(k);
                sb.append(up ? Character.toUpperCase(ch) : Character.toLowerCase(ch));
                up = ch == ' ';
            }
            n = sb.toString();
        }
        return n;
    }

    /** Lo que se muestra como crédito en la pantalla de bloqueo. */
    static String credit(String file) {
        return "Rockstar Games · " + title(file);
    }
}
