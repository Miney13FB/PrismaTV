package dev.prisma.tv;

import android.view.Gravity;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.TextView;

/**
 * Botón (o campo de texto) de cristal de la bienvenida. En reposo es un cristal oscuro como los de Inicio, así el texto
 * se lee sobre cualquier foto; al enfocarlo con el mando se vuelve blanco con letra oscura y crece un poco, como los
 * botones de tvOS. La opción elegida se queda en azul de acento.
 */
final class Pill extends GlassView implements FocusFx {
    private static final int BASE = 0xB3101828;
    private static final int BASE_MAIN = 0xC6243866;
    private static final int SEL = 0xD90A84FF;
    private static final int FOCUS = 0xF7FFFFFF;
    private static final int FOCUS_SEL = 0xF7BFDFFF;

    private final TextView label;
    private final int base;
    private boolean selected;
    private boolean dim;

    Pill(MainActivity a, String text, boolean primary, boolean left) {
        super(a, a.px(32), primary ? BASE_MAIN : BASE);
        base = primary ? BASE_MAIN : BASE;
        setFocusable(true);
        setClickable(true);
        label = a.text(text, 22, 0xFFFFFFFF, MainActivity.MEDIUM);
        label.setSingleLine(true);
        label.setEllipsize(android.text.TextUtils.TruncateAt.END);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2,
                left ? Gravity.CENTER_VERTICAL | Gravity.START : Gravity.CENTER);
        lp.leftMargin = a.px(32);
        lp.rightMargin = a.px(32);
        addView(label, lp);
    }

    /** Ancho máximo del texto (en píxeles); lo que sobra se corta con «…». */
    void setMaxLabelWidth(int px) {
        label.setMaxWidth(px);
    }

    /** Cambia el texto; {@code placeholder} lo muestra atenuado (campo todavía vacío). */
    void setText(String t, boolean placeholder) {
        label.setText(t);
        dim = placeholder;
        paint(isFocused());
    }

    /** Marca la opción elegida (queda en azul aunque el foco pase por otras). */
    void setSelectedState(boolean on) {
        selected = on;
        paint(isFocused());
    }

    private void paint(boolean focused) {
        int t;
        if (focused) t = selected ? FOCUS_SEL : FOCUS;
        else t = selected ? SEL : base;
        setTint(t);
        label.setTextColor(focused ? 0xFF0B0F18 : (dim ? 0xA6FFFFFF : 0xFFFFFFFF));
    }

    @Override
    protected void onFocusChanged(boolean gainFocus, int direction, android.graphics.Rect previouslyFocusedRect) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect);
        // si pierde el foco porque se oculta o se quita (el escuchador global no avisa), vuelve a su aspecto normal
        if (!gainFocus && !isShown()) fx(false, 0, false);
    }

    @Override
    public void fx(boolean focused, int dir, boolean animate) {
        paint(focused);
        float s = focused ? 1.06f : 1f;
        if (!animate) {
            setScaleX(s);
            setScaleY(s);
            return;
        }
        animate().cancel();
        animate().scaleX(s).scaleY(s)
                .setDuration(focused ? 240 : 160)
                .setInterpolator(focused ? new OvershootInterpolator(1.6f) : new DecelerateInterpolator())
                .start();
    }
}
