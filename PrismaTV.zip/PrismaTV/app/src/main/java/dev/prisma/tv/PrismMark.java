package dev.prisma.tv;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.SweepGradient;
import android.view.View;

/**
 * Logo de Prisma, dibujado por código: un cristal triangular de esquinas suaves, con los colores del espectro
 * girando desde el centro, tres facetas de luz y un contorno blanco fino.
 */
final class PrismMark extends View {
    private static final int[] SPEC = {0xFFFF375F, 0xFFFF9F0A, 0xFFFFD60A, 0xFF34C759, 0xFF0A84FF, 0xFFBF5AF2,
            0xFFFF375F};

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path body = new Path();
    private final Path fTop = new Path();
    private final Path fLeft = new Path();
    private final Path fBottom = new Path();
    private final Matrix m = new Matrix();
    private final float[] vx = new float[3];
    private final float[] vy = new float[3];
    private float cx, cy, r;
    private SweepGradient sweep;

    PrismMark(Context c) {
        super(c);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        float s = Math.min(w, h);
        r = s * 0.44f;
        cx = w / 2f;
        cy = h / 2f + r * 0.25f;          // centra el triángulo (la base pesa menos que la punta)
        vx[0] = cx;
        vy[0] = cy - r;                   // arriba
        vx[1] = cx + r * 0.866f;
        vy[1] = cy + r * 0.5f;            // abajo derecha
        vx[2] = cx - r * 0.866f;
        vy[2] = cy + r * 0.5f;            // abajo izquierda
        rounded(body, 0.20f);
        facet(fTop, 0, 1);
        facet(fLeft, 2, 0);
        facet(fBottom, 1, 2);
        sweep = new SweepGradient(cx, cy, SPEC, null);
        m.setRotate(-90f, cx, cy);        // el rosa empieza arriba
        sweep.setLocalMatrix(m);
    }

    /** Triángulo con las tres esquinas redondeadas (una curva en cada vértice). */
    private void rounded(Path path, float t) {
        path.reset();
        for (int i = 0; i < 3; i++) {
            int pi = (i + 2) % 3;
            int ni = (i + 1) % 3;
            float sx = vx[i] + (vx[pi] - vx[i]) * t;
            float sy = vy[i] + (vy[pi] - vy[i]) * t;
            float ex = vx[i] + (vx[ni] - vx[i]) * t;
            float ey = vy[i] + (vy[ni] - vy[i]) * t;
            if (i == 0) path.moveTo(sx, sy);
            else path.lineTo(sx, sy);
            path.quadTo(vx[i], vy[i], ex, ey);
        }
        path.close();
    }

    /** Faceta: triángulo entre el centro y dos vértices. */
    private void facet(Path path, int a, int b) {
        path.reset();
        path.moveTo(cx, cy);
        path.lineTo(vx[a], vy[a]);
        path.lineTo(vx[b], vy[b]);
        path.close();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (sweep == null) return;
        p.setStyle(Paint.Style.FILL);
        p.setShader(sweep);
        c.drawPath(body, p);
        p.setShader(null);

        c.save();
        c.clipPath(body);
        p.setColor(0x28FFFFFF);
        c.drawPath(fTop, p);
        p.setColor(0x5FFFFFFF);
        c.drawPath(fLeft, p);
        p.setColor(0x2D000000);
        c.drawPath(fBottom, p);
        c.restore();

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(r * 0.02f);
        p.setColor(0x6EFFFFFF);
        for (int i = 0; i < 3; i++) {
            c.drawLine(cx, cy, cx + (vx[i] - cx) * 0.80f, cy + (vy[i] - cy) * 0.80f, p);
        }
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(r * 0.035f);
        p.setColor(0xEBFFFFFF);
        c.drawPath(body, p);
    }
}
