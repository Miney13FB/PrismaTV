package dev.prisma.tv;

import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

/** El toque al pulsar OK: la pieza se hunde un poco y vuelve con un pequeño rebote al soltar (ligero: solo escala). */
final class Press {
    private static final DecelerateInterpolator DECEL = new DecelerateInterpolator();   // sin estado: se reutilizan
    private static final OvershootInterpolator OVER = new OvershootInterpolator(2.4f);
    private Press() {
    }

    /**
     * Solo toca la escala: no corta las demás animaciones de la pieza (el giro y la elevación del foco, por ejemplo),
     * que terminan solas.
     */
    static void tap(View v, boolean down, float rest, float pressed) {
        if (down) {
            v.animate().scaleX(pressed).scaleY(pressed).setDuration(70)
                    .setInterpolator(DECEL).start();
        } else {
            v.animate().scaleX(rest).scaleY(rest).setDuration(230)
                    .setInterpolator(OVER).start();
        }
    }
}
