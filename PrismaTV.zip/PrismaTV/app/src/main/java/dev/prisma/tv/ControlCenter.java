package dev.prisma.tv;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.PowerManager;
import android.widget.ImageView;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.text.InputType;
import android.text.format.Formatter;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static dev.prisma.tv.MainActivity.firstFocusable;
import static dev.prisma.tv.MainActivity.inside;

/**
 * Ajustes de Lumen (estilo iPhone): panel lateral de cristal con grupos de filas,
 * interruptores verdes/grises y todo lo del dispositivo (Wi-Fi, Bluetooth, bloqueo, tiempo,
 * dispositivo) sin salir del launcher.
 */
final class ControlCenter {
    interface Get { String get(); }
    interface Stp { void step(int dir); }
    interface SwCb { void on(boolean v); }

    private static final int BLUE = 0xFF0A84FF, ORANGE = 0xFFFF9F0A, PURPLE = 0xFFBF5AF2,
            RED = 0xFFFF453A, TEAL = 0xFF30B0C7, PINK = 0xFFFF375F, INDIGO = 0xFF5E5CE6,
            GREEN = 0xFF34C759, GRAY = 0xFF8E8E93;
    static final int[] IDLE_OPTS = {3, 5, 10, 20};
    private static final int PAGES = 12;

    private final MainActivity a;
    boolean open;
    private FrameLayout layer;
    private GlassView panel;
    private final ScrollView[] svs = new ScrollView[PAGES];
    private final LinearLayout[] cols = new LinearLayout[PAGES];
    private int page = -1;
    private View prevFocus;
    private boolean askedLoc;
    private boolean rxOn;

    // principal
    private TextView timeTv, dateTv;
    private IRow rWifi, rBt, rLock, rWx, rWall, rName, rHidden, rDev;

    // Wi-Fi
    private IRow swWifi;
    private LinearLayout wifiBody;
    private boolean scanning;

    // Bluetooth
    private IRow rBtState, rSearch;
    private LinearLayout btBody;
    private IGroup btOther;
    private boolean discovering;
    private final ArrayList<BluetoothDevice> found = new ArrayList<>();
    private final HashMap<String, String> foundName = new HashMap<>();
    private final Set<String> foundShown = new HashSet<>();

    ControlCenter(MainActivity act) {
        a = act;
    }

    // ------------------------------------------------------------------ utilidades

    private int px(float v) {
        return a.px(v);
    }

    private String s(int res) {
        return a.getString(res);
    }

    private WifiManager wm() {
        return (WifiManager) a.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
    }

    private static View findTag(View v, String key) {
        if (key.equals(v.getTag())) return v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = findTag(g.getChildAt(i), key);
                if (r != null) return r;
            }
        }
        return null;
    }

    /** Reúne, por orden, los elementos que pueden recibir el foco dentro de un contenedor. */
    private static void collectFocusable(View v, ArrayList<View> out) {
        if (v instanceof FocusFx && v.isFocusable() && v.getVisibility() == View.VISIBLE) {
            out.add(v);
            return;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) collectFocusable(g.getChildAt(i), out);
        }
    }

    /** Dónde estaba el foco dentro de una lista que se va a reconstruir: su etiqueta y su puesto entre los enfocables. */
    private static final class Keep {
        String tag;
        int idx;
    }

    private Keep keepFocus(View container) {
        View f = a.root.findFocus();
        if (f == null || !inside(f, container)) return null;
        Keep k = new Keep();
        if (f.getTag() instanceof String) k.tag = (String) f.getTag();
        ArrayList<View> all = new ArrayList<>();
        collectFocusable(container, all);
        k.idx = Math.max(0, all.indexOf(f));
        return k;
    }

    /**
     * Devuelve el foco a lo que lo tenía antes de reconstruir una lista: el mismo elemento si sigue ahí y, si ya no existe
     * (una red que desapareció, un dispositivo que se fue), el que ocupa ahora su sitio. Nunca se queda sin foco.
     */
    private void restoreFocus(View container, Keep k) {
        if (k == null) return;
        View v = k.tag == null ? null : findTag(container, k.tag);
        if (v == null || !v.isFocusable() || v.getVisibility() != View.VISIBLE) {
            ArrayList<View> all = new ArrayList<>();
            collectFocusable(container, all);
            v = all.isEmpty() ? null : all.get(Math.min(k.idx, all.size() - 1));
        }
        if (v == null && page >= 0) v = firstFocusable(cols[page]);
        if (v != null) v.requestFocus();
    }

    private IGroup group(LinearLayout col) {
        IGroup g = new IGroup(a, a.u);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = px(10);
        col.addView(g, lp);
        return g;
    }

    private IRow nav(IGroup g, int glyph, int color, String title, final Runnable click) {
        IRow r = new IRow(a, a.u, glyph, color, title);
        g.add(r);
        r.setChevron();
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (click != null) click.run();
            }
        });
        return r;
    }

    private IRow sw(IGroup g, int glyph, int color, String title, boolean init, final SwCb cb) {
        final IRow r = new IRow(a, a.u, glyph, color, title);
        g.add(r);
        r.setSwitch(init);
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean nv = !r.isOn();
                r.setSwitch(nv);
                cb.on(nv);
            }
        });
        return r;
    }

    private IRow arrow(IGroup g, int glyph, int color, String title, final Get get, final Stp stp) {
        final IRow r = new IRow(a, a.u, glyph, color, title);
        g.add(r);
        r.setValue("‹  " + get.get() + "  ›");
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stp.step(1);
                r.setValue("‹  " + get.get() + "  ›");
            }
        });
        r.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int code, KeyEvent e) {
                if (e.getAction() != KeyEvent.ACTION_DOWN) return false;
                if (code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT) {
                    stp.step(code == KeyEvent.KEYCODE_DPAD_LEFT ? -1 : 1);
                    r.setValue("‹  " + get.get() + "  ›");
                    return true;
                }
                return false;
            }
        });
        return r;
    }

    private TextView label(LinearLayout col, String t) {
        TextView v = a.text(t, 14, 0x99FFFFFF, MainActivity.MEDIUM);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = px(18);
        lp.topMargin = px(14);
        lp.bottomMargin = px(8);
        col.addView(v, lp);
        return v;
    }

    private void header(LinearLayout col, String title) {
        IGroup g = group(col);
        IRow b = new IRow(a, a.u, -1, 0, "‹  " + s(R.string.cc_settings));
        g.add(b);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back();
            }
        });
        TextView t = a.text(title, 36, 0xFFFFFFFF, MainActivity.MEDIUM);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = px(18);
        lp.topMargin = px(6);
        lp.bottomMargin = px(10);
        col.addView(t, lp);
    }

    // ------------------------------------------------------------------ abrir / cerrar

    /** Último elemento del panel que tuvo el foco (para devolvérselo si alguna vez se perdiera). */
    private View lastGood;

    void open(int startPage) {
        if (open) return;
        if (layer == null) build();
        finishClose();   // por si el panel aún se estaba cerrando
        open = true;
        askedLoc = false;
        prevFocus = a.root.findFocus();
        a.blockContent(true);
        layer.setDescendantFocusability(ViewGroup.FOCUS_BEFORE_DESCENDANTS);
        a.root.addView(layer, new FrameLayout.LayoutParams(-1, -1));
        page = -1;
        lastGood = null;
        show(startPage, -1);
        layer.animate().cancel();
        panel.animate().cancel();
        if (a.st.anim()) {
            layer.setAlpha(0f);
            layer.animate().alpha(1f).setDuration(220).setInterpolator(new DecelerateInterpolator()).start();
            panel.setTranslationX(px(660));
            panel.animate().translationX(0f).setDuration(300)
                    .setInterpolator(new DecelerateInterpolator(1.7f)).start();
        } else {
            layer.setAlpha(1f);
            panel.setTranslationX(0f);
        }
    }

    void close() {
        close(true);
    }

    /** Cierra el panel. Sin animación (al salir de Lumen o pulsar Inicio) se retira al instante. */
    void close(boolean animate) {
        if (!open) return;
        unregister();
        stopDiscovery();
        flushHidden();
        iconGen++;
        open = false;
        a.ui.removeCallbacks(focusFix);
        a.ui.removeCallbacks(settleR);
        // el foco vuelve al Inicio ANTES de retirar el panel: nunca se queda sin dueño ni cae en una capa
        a.blockContent(false);
        layer.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        if (prevFocus != null && prevFocus.isAttachedToWindow() && prevFocus.isShown()) prevFocus.requestFocus();
        else a.focusFirstFav();
        prevFocus = null;
        lastGood = null;
        layer.animate().cancel();
        panel.animate().cancel();
        if (animate && a.st.anim() && layer.isAttachedToWindow()) {
            panel.animate().translationX(px(660)).setDuration(210)
                    .setInterpolator(new AccelerateInterpolator(1.4f)).start();
            layer.animate().alpha(0f).setDuration(210).withEndAction(new Runnable() {
                @Override
                public void run() {
                    finishClose();
                }
            }).start();
        } else {
            finishClose();
        }
    }

    /** Retira la capa del panel (al acabar su animación de salida o si se vuelve a abrir enseguida). */
    private void finishClose() {
        if (layer == null) return;
        layer.animate().cancel();
        panel.animate().cancel();
        if (layer.getParent() != null) a.root.removeView(layer);
    }

    void back() {
        if (!open) return;
        if (page > 0) {
            flushHidden();
            show(0, page);
        } else {
            close();
        }
    }

    void tick() {
        if (timeTv != null && open && page == 0) {
            timeTv.setText(a.fmtTime());
            dateTv.setText(a.fmtDate());
        }
    }

    void netChanged() {
        if (!open) return;
        if (page == 0) refreshMain();
        else if (page == 1) fillWifi();
    }

    void btChanged() {
        if (open && page == 0) refreshMain();
    }

    void permResult() {
        if (!open) return;
        if (page == 1) {
            startScan();
            fillWifi();
        } else if (page == 2) {
            fillBt();
        }
    }

    /** Elemento de la página principal al que se vuelve al salir de una subpágina (el que la abrió). */
    private View backTarget(int from) {
        IRow[] b = {null, rWifi, rBt, rLock, rWx, rDev, rHidden, rApps, null, null, null, rWall};
        View r = from > 0 && from < b.length ? b[from] : null;
        if (r != null && r.isFocusable() && inside(r, cols[0])) return r;
        return firstFocusable(cols[0]);
    }

    private void show(int p, int from) {
        unregister();
        if (page == 2 && p != 2) stopDiscovery();
        final int old = page;
        page = p;
        lastGood = null;
        a.ui.removeCallbacks(settleR);
        // 1) se prepara la página nueva mientras sigue oculta
        View f;
        if (p == 0) {
            refreshMain();
            f = backTarget(from);
        } else {
            if (p == 1) {
                buildWifi();
                register(1);
                if ((!a.hasLocation()) && !askedLoc) {
                    askedLoc = true;
                    a.ensureLocation();
                } else {
                    startScan();
                }
            } else if (p == 2) {
                buildBt();
                register(2);
                if ((!a.hasLocation()) && !askedLoc) {
                    askedLoc = true;
                    a.ensureLocation();
                }
            } else if (p == 3) {
                buildLock();
            } else if (p == 4) {
                buildWeather();
            } else if (p == 5) {
                buildFire();
            } else if (p == 6) {
                buildHidden();
            } else if (p == 7) {
                buildApps();
            } else {
                buildScreens();
            }
            f = firstFocusable(cols[p]);
        }
        // 2) se enseña la nueva y se le da el foco ANTES de ocultar la vieja: así el foco nunca se queda sin dueño
        //    (el sistema lo mandaría a la primera vista que encontrase, a menudo una capa a pantalla completa)
        svs[p].setVisibility(View.VISIBLE);
        if (f != null) f.requestFocus();
        for (int i = 0; i < PAGES; i++) {
            if (i != p && svs[i].getVisibility() != View.GONE) {
                settle(cols[i]);
                svs[i].setVisibility(View.GONE);
            }
        }
        clearFx(cols[p]);
        enter(p, old);
        // 3) comprobación final: si por lo que fuera el foco no llegó, se repone
        a.ui.removeCallbacks(focusFix);
        a.ui.postDelayed(focusFix, 120);
    }

    private final Runnable focusFix = new Runnable() {
        @Override
        public void run() {
            ensureFocus();
        }
    };

    /** Un elemento válido para tener el foco: una fila del panel, visible y de la página actual. */
    private boolean usable(View f) {
        return f != null && f instanceof FocusFx && f.isShown() && f.isFocusable() && page >= 0
                && inside(f, svs[page]);
    }

    /**
     * Comprueba que el foco está en una fila visible de la página actual y, si no (se perdió o cayó en un contenedor),
     * se lo devuelve a la última fila que lo tuvo o a la primera. Devuelve true si hubo que repararlo.
     */
    boolean ensureFocus() {
        if (!open || page < 0) return false;
        if (usable(a.root.findFocus())) return false;
        View t = usable(lastGood) ? lastGood : firstFocusable(cols[page]);
        if (t == null) return false;
        t.requestFocus();
        return true;
    }

    /** MainActivity avisa de cada cambio de foco para recordar la última fila del panel que lo tuvo. */
    void noteFocus(View f) {
        if (open && usable(f)) lastGood = f;
    }

    /** Quita el aspecto de "enfocado" de todas las filas de una página (por si quedó alguna marcada). */
    private void clearFx(View v) {
        if (v instanceof FocusFx && !v.isFocused()) ((FocusFx) v).fx(false, 0, false);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) clearFx(g.getChildAt(i));
        }
    }

    /** Deja los bloques de una página quietos y opacos, cortando cualquier animación a medias. */
    private void settle(LinearLayout col) {
        if (col == null) return;
        for (int i = 0; i < col.getChildCount(); i++) {
            View v = col.getChildAt(i);
            v.animate().cancel();
            v.setAlpha(1f);
            v.setTranslationX(0f);
        }
    }

    private final Runnable settleR = new Runnable() {
        @Override
        public void run() {
            if (page >= 0) settle(cols[page]);
        }
    };

    /**
     * Entrada de una página: sus bloques aparecen en cascada, desde el lado por el que se llegó (la derecha al avanzar
     * a una subpágina, la izquierda al volver al menú). Rápida y ligera: solo opacidad y desplazamiento.
     * Pase lo que pase, a los 0,6 s todo queda opaco y en su sitio.
     */
    private void enter(int p, int old) {
        final LinearLayout col = cols[p];
        settle(col);
        if (!a.st.anim()) return;
        float dx = px(p == 0 && old > 0 ? -30 : 30);
        int n = Math.min(col.getChildCount(), 9);
        for (int i = 0; i < n; i++) {
            View v = col.getChildAt(i);
            v.setAlpha(0f);
            v.setTranslationX(dx);
            v.animate().alpha(1f).translationX(0f).setStartDelay(24L * i).setDuration(280)
                    .setInterpolator(new DecelerateInterpolator(1.5f)).start();
        }
        a.ui.postDelayed(settleR, 24L * n + 420);
    }

    // ------------------------------------------------------------------ construcción

    private void build() {
        layer = new FrameLayout(a);
        layer.setBackgroundColor(0x55000000);
        layer.setClickable(true);
        // (en Android 8+ una vista pulsable es también enfocable: si la capa tuviera el foco, el mando dejaría de mover nada)
        layer.setFocusable(false);
        layer.setFocusableInTouchMode(false);
        layer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                close();
            }
        });
        panel = new GlassView(a, px(34), 0x8A121A2C);
        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(px(620), -1, Gravity.END);
        pl.topMargin = px(24);
        pl.bottomMargin = px(24);
        pl.rightMargin = px(24);
        layer.addView(panel, pl);
        for (int i = 0; i < PAGES; i++) {
            ScrollView sv = new ScrollView(a);
            sv.setVerticalScrollBarEnabled(false);
            sv.setSmoothScrollingEnabled(true);
            sv.setFocusable(false);   // el foco es de las filas, nunca del contenedor
            sv.setClipToPadding(false);
            sv.setPadding(px(20), px(20), px(20), px(30));
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(LinearLayout.VERTICAL);
            sv.addView(col, new FrameLayout.LayoutParams(-1, -2));
            panel.addView(sv, new FrameLayout.LayoutParams(-1, -1));
            svs[i] = sv;
            cols[i] = col;
        }
        buildMain();
    }

    private void buildMain() {
        LinearLayout col = cols[0];
        col.removeAllViews();

        timeTv = a.text("", 52, 0xFFFFFFFF, MainActivity.LIGHT);
        dateTv = a.text("", 17, 0xB8FFFFFF, MainActivity.REG);
        LinearLayout.LayoutParams t1 = new LinearLayout.LayoutParams(-2, -2);
        t1.leftMargin = px(18);
        col.addView(timeTv, t1);
        LinearLayout.LayoutParams t2 = new LinearLayout.LayoutParams(-2, -2);
        t2.leftMargin = px(20);
        t2.bottomMargin = px(14);
        col.addView(dateTv, t2);

        IGroup g1 = group(col);
        rWifi = nav(g1, Glyph.WIFI, BLUE, s(R.string.set_wifi), new Runnable() {
            @Override
            public void run() {
                show(1, 0);
            }
        });
        rBt = nav(g1, Glyph.BT, BLUE, s(R.string.set_bt), new Runnable() {
            @Override
            public void run() {
                show(2, 0);
            }
        });

        IGroup g2 = group(col);
        rLock = nav(g2, Glyph.LOCK, INDIGO, s(R.string.set_lock), new Runnable() {
            @Override
            public void run() {
                show(3, 0);
            }
        });
        rWx = nav(g2, Glyph.WEATHER, ORANGE, s(R.string.set_weather), new Runnable() {
            @Override
            public void run() {
                show(4, 0);
            }
        });
        rWall = nav(g2, Glyph.WALL, TEAL, s(R.string.set_wallpaper), new Runnable() {
            @Override
            public void run() {
                show(11, 0);
            }
        });

        IGroup g4 = group(col);
        rHidden = nav(g4, Glyph.HIDDEN, GREEN, s(R.string.set_hidden), new Runnable() {
            @Override
            public void run() {
                show(6, 0);
            }
        });
        rApps = nav(g4, Glyph.SHELF, BLUE, s(R.string.set_apps), new Runnable() {
            @Override
            public void run() {
                show(7, 0);
            }
        });

        IGroup g5 = group(col);
        rDev = nav(g5, Glyph.DEVICE, GRAY, s(R.string.set_fire), new Runnable() {
            @Override
            public void run() {
                show(5, 0);
            }
        });

        String ver = "";
        try {
            ver = a.getPackageManager().getPackageInfo(a.getPackageName(), 0).versionName;
        } catch (Throwable ignored) {
        }
        label(col, "Lumen " + ver);
    }

    private void refreshMain() {
        if (timeTv == null) return;
        timeTv.setText(a.fmtTime());
        dateTv.setText(a.fmtDate());
        wifiStatus(rWifi);
        btStatus(rBt);
        rLock.setValue(a.st.lockOn() ? a.getString(R.string.lock_state, a.st.idleMin()) : s(R.string.lock_off));
        int n = a.st.places().size();
        rWx.setValue(n == 0 ? s(R.string.wx_off) : a.getString(R.string.wx_count, n));
        rWall.setValue(s(MainActivity.WP_NAMES[a.st.wallpaper()]));
        int hid = a.st.hidden().size();
        rHidden.setValue(hid == 0 ? s(R.string.hidden_none) : a.getString(R.string.hidden_show, hid));
        rApps.setValue(storageText());
    }

    private void wifiStatus(IRow r) {
        try {
            WifiManager w = wm();
            if (!w.isWifiEnabled()) {
                r.setStatus(false, s(R.string.wifi_status_off));
                return;
            }
            WifiInfo wi = w.getConnectionInfo();
            String ssid = wi == null ? null : wi.getSSID();
            boolean c = ssid != null && !ssid.contains("unknown") && wi.getNetworkId() != -1;
            r.setStatus(c, c ? ssid.replace("\"", "") : s(R.string.wifi_status_disc));
        } catch (Throwable t) {
            r.setStatus(false, "");
        }
    }

    private void btStatus(IRow r) {
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            if (ad == null) {
                r.setStatus(false, s(R.string.bt_na));
                return;
            }
            if (!ad.isEnabled()) {
                r.setStatus(false, s(R.string.bt_off));
                return;
            }
            int n = 0;
            for (BluetoothDevice d : ad.getBondedDevices()) {
                if (BtUtil.isConn(d)) n++;
            }
            r.setStatus(true, n > 0 ? a.getString(R.string.bt_n_conn, n) : s(R.string.bt_on));
        } catch (Throwable t) {
            r.setStatus(false, "");
        }
    }

    private String wifiIp() {
        try {
            int ip = wm().getConnectionInfo().getIpAddress();
            if (ip == 0) return "—";
            return (ip & 0xff) + "." + ((ip >> 8) & 0xff) + "." + ((ip >> 16) & 0xff) + "." + ((ip >> 24) & 0xff);
        } catch (Throwable t) {
            return "—";
        }
    }

    // ------------------------------------------------------------------ RAM y nombre

    private void freeRam() {
        try {
            final ActivityManager am = (ActivityManager) a.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            final long before = mi.availMem;
            final ArrayList<String> pks = new ArrayList<>();
            for (AppItem x : a.apps) pks.add(x.pkg);
            // los avisos al sistema (uno por app) se hacen en segundo plano: así la pantalla no se queda parada mientras tanto
            Bg.thread("lumen-ram", new Runnable() {
                @Override
                public void run() {
                    for (String p : pks) {
                        try {
                            am.killBackgroundProcesses(p);
                        } catch (Throwable ignored) {
                        }
                    }
                    a.ui.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            ActivityManager.MemoryInfo m2 = new ActivityManager.MemoryInfo();
                            am.getMemoryInfo(m2);
                            long freed = m2.availMem - before;
                            if (freed > 4L * 1024 * 1024) {
                                a.toast(a.getString(R.string.ram_done, Formatter.formatFileSize(a, freed)));
                            } else {
                                a.toast(R.string.ram_ok);
                            }
                            refreshRam();
                        }
                    }, 900);
                }
            }).start();
        } catch (Throwable ignored) {
        }
    }

    /** Pone en la fila "Liberar RAM" (dentro de Mi Fire TV) la memoria libre que hay ahora. */
    private void refreshRam() {
        if (rRam == null || !open || page != 5) return;
        try {
            ActivityManager am = (ActivityManager) a.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            rRam.setValue(a.getString(R.string.ram_sub, Formatter.formatFileSize(a, mi.availMem)));
        } catch (Throwable ignored) {
        }
    }

    private String nameLabel() {
        String nm = a.st.name();
        return nm.isEmpty() ? s(R.string.name_none) : nm;
    }

    private void askName() {
        final EditText et = new EditText(a);
        et.setSingleLine(true);
        et.setText(a.st.name());
        et.setSelection(et.getText().length());
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(R.string.set_name)
                .setView(et)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        a.st.setName(et.getText().toString());
                        a.updateClock();
                        if (rName != null) rName.setValue(nameLabel());
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    // ------------------------------------------------------------------ receptor Wi-Fi / Bluetooth

    private final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String act = i.getAction();
            if (act == null || !open) return;
            if (page == 1) {
                scanning = false;
                if (swWifi != null) swWifi.setSwitch(wm().isWifiEnabled());
                fillWifi();
            } else if (page == 2) {
                if (BluetoothDevice.ACTION_FOUND.equals(act)) {
                    BluetoothDevice d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    String nm = i.getStringExtra(BluetoothDevice.EXTRA_NAME);
                    if (d != null) onFound(d, nm);
                    return;
                } else if (BluetoothAdapter.ACTION_DISCOVERY_STARTED.equals(act)) {
                    discovering = true;
                    updateSearchRow();
                    return;
                } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(act)) {
                    discovering = false;
                    updateSearchRow();
                    return;
                } else if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(act)) {
                    BluetoothDevice d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    int st = i.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, -1);
                    if (d != null && st == BluetoothDevice.BOND_BONDED) {
                        BtUtil.setConnected(a, d, true);
                    }
                }
                updateBtState();
                fillBt();
            }
        }
    };

    private void register(int p) {
        IntentFilter f = new IntentFilter();
        if (p == 1) {
            f.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
            f.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
            f.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        } else {
            f.addAction(BluetoothDevice.ACTION_FOUND);
            f.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
            f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
            f.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
            f.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
            f.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
            f.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        }
        try {
            a.registerReceiver(rx, f);
            rxOn = true;
        } catch (Throwable ignored) {
        }
    }

    private void unregister() {
        if (!rxOn) return;
        try {
            a.unregisterReceiver(rx);
        } catch (Throwable ignored) {
        }
        rxOn = false;
    }

    // ------------------------------------------------------------------ ubicación (necesaria para buscar)

    private boolean locationOn() {
        try {
            return Settings.Secure.getInt(a.getContentResolver(), Settings.Secure.LOCATION_MODE) != 0;
        } catch (Throwable t) {
            return true;
        }
    }

    private void enableLocation() {
        try {
            Settings.Secure.putInt(a.getContentResolver(), Settings.Secure.LOCATION_MODE, 3);
        } catch (Throwable t) {
            a.toast(R.string.loc_adb);
            a.tryStart(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
        }
        if (page == 1) fillWifi();
        else if (page == 2) fillBt();
    }

    /** Filas de ayuda si falta el permiso de ubicación o está apagada la ubicación. */
    private void diagRows(LinearLayout body) {
        boolean perm = a.hasLocation();
        boolean loc = locationOn();
        if (perm && loc) return;
        label(body, s(R.string.diag_title));
        IGroup g = group(body);
        if (!perm) {
            IRow r = nav(g, Glyph.LOCK, ORANGE, s(R.string.diag_perm), new Runnable() {
                @Override
                public void run() {
                    a.ensureLocation();
                }
            });
            r.setStatus(false, s(R.string.diag_perm_v));
            r.setTag("diag:perm");
        }
        if (!loc) {
            IRow r = nav(g, Glyph.WEATHER, ORANGE, s(R.string.diag_loc), new Runnable() {
                @Override
                public void run() {
                    enableLocation();
                }
            });
            r.setStatus(false, s(R.string.diag_loc_v));
            r.setTag("diag:loc");
        }
    }

    // ------------------------------------------------------------------ Wi-Fi

    private void startScan() {
        if (!a.hasLocation()) return;
        try {
            scanning = wm().startScan();
        } catch (Throwable ignored) {
        }
    }

    private void buildWifi() {
        LinearLayout col = cols[1];
        col.removeAllViews();
        header(col, s(R.string.set_wifi));
        IGroup g = group(col);
        swWifi = sw(g, -1, 0, s(R.string.set_wifi), wm().isWifiEnabled(), new SwCb() {
            @Override
            public void on(boolean v) {
                try {
                    if (!wm().setWifiEnabled(v)) a.openWifiSettings();
                } catch (Throwable t) {
                    a.openWifiSettings();
                }
                a.ui.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (open && page == 1) {
                            swWifi.setSwitch(wm().isWifiEnabled());
                            startScan();
                            fillWifi();
                        }
                    }
                }, 1500);
            }
        });
        wifiBody = new LinearLayout(a);
        wifiBody.setOrientation(LinearLayout.VERTICAL);
        col.addView(wifiBody, new LinearLayout.LayoutParams(-1, -2));
        wifiSig = null;   // cuerpo nuevo y vacío: se construye seguro
        fillWifi();
    }

    private String wifiSig;   // lo que enseña ahora la lista de redes: si no cambia, no se vuelve a construir

    private void fillWifi() {
        if (wifiBody == null || page != 1) return;
        final WifiManager w = wm();
        final boolean enabled = w.isWifiEnabled();

        String connected = null;
        int connLevel = 0;
        HashMap<String, ScanResult> best = new HashMap<>();
        ArrayList<ScanResult> list = new ArrayList<>();
        if (enabled) {
            try {
                WifiInfo wi = w.getConnectionInfo();
                if (wi != null && wi.getSSID() != null && !wi.getSSID().contains("unknown") && wi.getNetworkId() != -1) {
                    connected = wi.getSSID().replace("\"", "");
                    connLevel = WifiManager.calculateSignalLevel(wi.getRssi(), 5);
                }
            } catch (Throwable ignored) {
            }
            try {
                List<ScanResult> res = w.getScanResults();
                if (res != null) {
                    for (ScanResult r : res) {
                        if (r.SSID == null || r.SSID.isEmpty()) continue;
                        ScanResult o = best.get(r.SSID);
                        if (o == null || r.level > o.level) best.put(r.SSID, r);
                    }
                }
            } catch (Throwable ignored) {
            }
            list.addAll(best.values());
            Collections.sort(list, new Comparator<ScanResult>() {
                @Override
                public int compare(ScanResult x, ScanResult y) {
                    return y.level - x.level;
                }
            });
            if (connected != null) list.remove(best.get(connected));
        }

        // Android avisa de cada pequeño cambio de señal cada pocos segundos: la lista solo se reconstruye cuando lo que se
        // ve ha cambiado de verdad (antes se rehacía entera cada vez y la fila enfocada volvía a empezar su animación)
        StringBuilder sg = new StringBuilder();
        if (!enabled) {
            sg.append("off");
        } else {
            sg.append(a.hasLocation()).append(locationOn());
            if (connected != null) {
                sg.append('|').append(connected).append('#').append(connLevel).append('#').append(wifiIp());
            }
            for (ScanResult r : list) {
                sg.append('|').append(r.SSID).append('#').append(WifiManager.calculateSignalLevel(r.level, 5))
                        .append(isSecure(r) ? 's' : 'o');
            }
            if (connected == null && list.isEmpty()) sg.append("|vacia").append(scanning);
        }
        String sig = sg.toString();
        if (sig.equals(wifiSig)) return;
        wifiSig = sig;

        Keep key = keepFocus(wifiBody);
        wifiBody.removeAllViews();
        if (!enabled) return;
        diagRows(wifiBody);

        label(wifiBody, s(R.string.wifi_networks));
        IGroup g = group(wifiBody);
        if (connected != null) {
            IRow r = new IRow(a, a.u, -1, 0, connected);
            g.add(r);
            WifiView wv = new WifiView(a);
            wv.setLevel(connLevel);
            r.setLead(wv, 26);
            r.setStatus(true, a.getString(R.string.wifi_connected, wifiIp()));
            r.setTag("net:" + connected);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    a.toast(R.string.wifi_already);
                }
            });
        }
        for (final ScanResult r : list) {
            final boolean sec = isSecure(r);
            IRow row = new IRow(a, a.u, -1, 0, r.SSID);
            g.add(row);
            WifiView wv = new WifiView(a);
            wv.setLevel(WifiManager.calculateSignalLevel(r.level, 5));
            row.setLead(wv, 26);
            row.setStatus(false, s(sec ? R.string.wifi_secure : R.string.wifi_open));
            row.setTag("net:" + r.SSID);
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    connectTo(r.SSID, sec);
                }
            });
        }
        if (connected == null && list.isEmpty()) {
            IRow r = new IRow(a, a.u, -1, 0, s(scanning ? R.string.wifi_searching : R.string.wifi_none));
            r.setFocusable(false);
            r.setClickable(false);
            g.add(r);
        }
        IGroup g2 = group(wifiBody);
        IRow rs = nav(g2, -1, 0, s(R.string.wifi_rescan), new Runnable() {
            @Override
            public void run() {
                if (!a.hasLocation()) {
                    a.ensureLocation();
                    return;
                }
                startScan();
                a.toast(R.string.wifi_searching);
            }
        });
        rs.setTag("rescan");
        restoreFocus(wifiBody, key);
    }

    private static boolean isSecure(ScanResult r) {
        String c = r.capabilities == null ? "" : r.capabilities;
        return c.contains("WPA") || c.contains("WEP") || c.contains("PSK") || c.contains("EAP") || c.contains("SAE");
    }

    private void connectTo(final String ssid, boolean secure) {
        try {
            List<WifiConfiguration> saved = wm().getConfiguredNetworks();
            if (saved != null) {
                for (WifiConfiguration c : saved) {
                    if (c.SSID != null && c.SSID.equals("\"" + ssid + "\"")) {
                        join(c.networkId);
                        return;
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        if (!secure) {
            addAndJoin(ssid, null);
            return;
        }
        final EditText et = new EditText(a);
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(a.getString(R.string.wifi_pw_title, ssid))
                .setView(et)
                .setPositiveButton(R.string.wifi_connect, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        addAndJoin(ssid, et.getText().toString());
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void addAndJoin(String ssid, String pwd) {
        try {
            WifiConfiguration c = new WifiConfiguration();
            c.SSID = "\"" + ssid + "\"";
            if (pwd == null) {
                c.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
            } else {
                c.preSharedKey = "\"" + pwd + "\"";
            }
            int id = wm().addNetwork(c);
            if (id < 0) {
                a.toast(R.string.wifi_fail);
                a.openWifiSettings();
                return;
            }
            join(id);
        } catch (Throwable t) {
            a.toast(R.string.wifi_fail);
            a.openWifiSettings();
        }
    }

    private void join(int id) {
        try {
            WifiManager w = wm();
            w.disconnect();
            boolean ok = w.enableNetwork(id, true);
            w.reconnect();
            a.toast(ok ? R.string.wifi_connecting : R.string.wifi_fail);
        } catch (Throwable t) {
            a.toast(R.string.wifi_fail);
        }
    }

    // ------------------------------------------------------------------ Bluetooth

    private boolean btOn() {
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            return ad != null && ad.isEnabled();
        } catch (Throwable t) {
            return false;
        }
    }

    /** La fila de arriba del Bluetooth: punto verde y «Siempre activado» (o «Activando…» un momento si se hubiera apagado). */
    private void updateBtState() {
        if (rBtState == null) return;
        boolean on = btOn();
        rBtState.setStatus(on, s(on ? R.string.bt_always_on : R.string.bt_starting));
    }

    private void stopDiscovery() {
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            if (ad != null && ad.isDiscovering()) ad.cancelDiscovery();
        } catch (Throwable ignored) {
        }
        discovering = false;
    }

    private void buildBt() {
        LinearLayout col = cols[2];
        col.removeAllViews();
        found.clear();
        foundName.clear();
        foundShown.clear();
        discovering = false;
        header(col, s(R.string.set_bt));
        IGroup g = group(col);
        // El Bluetooth no se puede apagar desde aquí: el mando del Fire TV funciona por Bluetooth y, sin él, no se podría
        // manejar nada. Esta fila solo informa (y si algo lo apagara, Lumen lo vuelve a encender enseguida).
        a.keepBluetoothOn();
        rBtState = new IRow(a, a.u, -1, 0, s(R.string.set_bt));
        rBtState.setFocusable(false);
        rBtState.setClickable(false);
        g.add(rBtState);
        updateBtState();
        btBody = new LinearLayout(a);
        btBody.setOrientation(LinearLayout.VERTICAL);
        col.addView(btBody, new LinearLayout.LayoutParams(-1, -2));
        fillBt();
    }

    private void fillBt() {
        if (btBody == null || page != 2) return;
        Keep key = keepFocus(btBody);
        btBody.removeAllViews();
        rSearch = null;
        btOther = null;
        foundShown.clear();
        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null || !ad.isEnabled()) {
            label(btBody, s(ad == null ? R.string.bt_na : R.string.bt_starting));
            return;
        }
        diagRows(btBody);

        label(btBody, s(R.string.bt_my));
        IGroup my = group(btBody);
        ArrayList<BluetoothDevice> bonded = new ArrayList<>();
        try {
            bonded.addAll(ad.getBondedDevices());
        } catch (Throwable ignored) {
        }
        Collections.sort(bonded, new Comparator<BluetoothDevice>() {
            @Override
            public int compare(BluetoothDevice x, BluetoothDevice y) {
                return (BtUtil.isConn(y) ? 1 : 0) - (BtUtil.isConn(x) ? 1 : 0);
            }
        });
        if (bonded.isEmpty()) {
            IRow r = new IRow(a, a.u, -1, 0, s(R.string.bt_none));
            r.setFocusable(false);
            r.setClickable(false);
            my.add(r);
        }
        for (final BluetoothDevice d : bonded) {
            boolean conn = BtUtil.isConn(d);
            IRow r = new IRow(a, a.u, Glyph.BT, BLUE, BtUtil.nameOf(d));
            my.add(r);
            r.setStatus(conn, s(conn ? R.string.bt_connected : R.string.bt_disconnected));
            r.setTag("bt:" + d.getAddress());
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    deviceMenu(d);
                }
            });
        }

        label(btBody, s(R.string.bt_other));
        btOther = group(btBody);
        rSearch = new IRow(a, a.u, -1, 0, "");
        btOther.add(rSearch);
        rSearch.setTag("search");
        rSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startSearch();
            }
        });
        updateSearchRow();
        for (BluetoothDevice d : found) addFoundRow(d);
        restoreFocus(btBody, key);
    }

    private void updateSearchRow() {
        if (rSearch == null) return;
        rSearch.title.setText(s(discovering ? R.string.bt_searching : (found.isEmpty() ? R.string.bt_search
                : R.string.bt_search_again)));
        rSearch.setStatus(discovering, discovering ? "…" : "");
    }

    private void onFound(BluetoothDevice d, String nm) {
        String addr = d.getAddress();
        if (nm != null && !nm.isEmpty()) foundName.put(addr, nm);
        boolean named = foundName.containsKey(addr) || BtUtil.hasName(d);
        if (!named) return;
        if (!found.contains(d)) found.add(d);
        if (btOther == null) return;
        try {
            if (d.getBondState() == BluetoothDevice.BOND_BONDED) return;
        } catch (Throwable ignored) {
        }
        addFoundRow(d);
    }

    private void addFoundRow(final BluetoothDevice d) {
        if (btOther == null) return;
        String addr = d.getAddress();
        if (foundShown.contains(addr)) return;
        try {
            if (d.getBondState() == BluetoothDevice.BOND_BONDED) return;
        } catch (Throwable ignored) {
        }
        foundShown.add(addr);
        String nm = foundName.containsKey(addr) ? foundName.get(addr) : BtUtil.nameOf(d);
        IRow r = new IRow(a, a.u, Glyph.BT, GRAY, nm);
        btOther.add(r);
        r.setValue(s(R.string.bt_tap_pair));
        r.setTag("found:" + addr);
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    stopDiscovery();
                    updateSearchRow();
                    boolean ok = d.createBond();
                    a.toast(ok ? R.string.bt_pairing : R.string.bt_pair_fail);
                } catch (Throwable t) {
                    a.openBluetoothSettings();
                }
            }
        });
    }

    private void startSearch() {
        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null || !ad.isEnabled()) return;
        if (!a.hasLocation()) {
            a.ensureLocation();
            return;
        }
        if (!locationOn()) enableLocation();
        try {
            if (ad.isDiscovering()) ad.cancelDiscovery();
            found.clear();
            foundName.clear();
            discovering = true;
            fillBt();
            boolean ok = ad.startDiscovery();
            if (!ok) {
                discovering = false;
                updateSearchRow();
                a.toast(R.string.bt_search_fail);
            }
        } catch (Throwable t) {
            discovering = false;
            updateSearchRow();
            a.toast(R.string.bt_search_fail);
        }
    }

    private void deviceMenu(final BluetoothDevice d) {
        final boolean conn = BtUtil.isConn(d);
        CharSequence[] items = {s(conn ? R.string.bt_disconnect : R.string.bt_connect), s(R.string.bt_forget_yes)};
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(BtUtil.nameOf(d))
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dlg, int which) {
                        if (which == 0) {
                            BtUtil.setConnected(a, d, !conn);
                            a.toast(conn ? R.string.bt_disconnecting : R.string.bt_conn_try);
                            refreshBtLater(1800);
                            refreshBtLater(5000);
                        } else {
                            askForget(d);
                        }
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void refreshBtLater(long ms) {
        a.ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (open && page == 2) fillBt();
                a.updateBt();
            }
        }, ms);
    }

    private void askForget(final BluetoothDevice d) {
        String n = BtUtil.nameOf(d);
        String low = n.toLowerCase();
        if (low.contains("remote") || low.contains("mando")) {
            a.toast(R.string.bt_protected);
            return;
        }
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(a.getString(R.string.bt_forget, n))
                .setPositiveButton(R.string.bt_forget_yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface x, int w) {
                        try {
                            d.getClass().getMethod("removeBond").invoke(d);
                        } catch (Throwable t) {
                            a.openBluetoothSettings();
                        }
                        refreshBtLater(900);
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    // ------------------------------------------------------------------ pantalla de bloqueo

    private void buildLock() {
        LinearLayout col = cols[3];
        col.removeAllViews();
        header(col, s(R.string.set_lock));
        IGroup g = group(col);
        sw(g, Glyph.LOCK, INDIGO, s(R.string.lock_enable), a.st.lockOn(), new SwCb() {
            @Override
            public void on(boolean v) {
                a.st.setLockOn(v);
                a.resetIdle();
            }
        });
        arrow(g, Glyph.CLOCK, TEAL, s(R.string.lock_wait), new Get() {
            @Override
            public String get() {
                return a.getString(R.string.idle_min, a.st.idleMin());
            }
        }, new Stp() {
            @Override
            public void step(int d) {
                int idx = 0;
                for (int i = 0; i < IDLE_OPTS.length; i++) {
                    if (IDLE_OPTS[i] == a.st.idleMin()) idx = i;
                }
                idx = (idx + d + IDLE_OPTS.length) % IDLE_OPTS.length;
                a.st.setIdleMin(IDLE_OPTS[idx]);
                a.resetIdle();
            }
        });
        sw(g, Glyph.WEATHER, ORANGE, s(R.string.lock_wx), a.st.wxLock(), new SwCb() {
            @Override
            public void on(boolean v) {
                a.st.setWxLock(v);
                a.updateWeatherViews();
            }
        });
        IGroup g2 = group(col);
        nav(g2, Glyph.WALL, TEAL, s(R.string.lock_preview), new Runnable() {
            @Override
            public void run() {
                a.previewLock();
            }
        });
        TextView note = a.text(s(R.string.lock_note), 15, 0x99FFFFFF, MainActivity.REG);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = px(18);
        lp.topMargin = px(6);
        col.addView(note, lp);
    }

    // ------------------------------------------------------------------ tiempo

    private void buildWeather() {
        LinearLayout col = cols[4];
        col.removeAllViews();
        header(col, s(R.string.set_weather));
        IGroup g = group(col);
        sw(g, Glyph.WEATHER, ORANGE, s(R.string.wx_home), a.st.wxHome(), new SwCb() {
            @Override
            public void on(boolean v) {
                a.st.setWxHome(v);
                a.updateWeatherViews();
                if (v) a.refreshWeather(false);
            }
        });
        sw(g, Glyph.LOCK, INDIGO, s(R.string.lock_wx), a.st.wxLock(), new SwCb() {
            @Override
            public void on(boolean v) {
                a.st.setWxLock(v);
                a.updateWeatherViews();
            }
        });
        label(col, s(R.string.wx_places));
        IGroup pg = group(col);
        final List<String[]> places = a.st.places();
        for (final String[] p : places) {
            IRow r = new IRow(a, a.u, Glyph.WEATHER, ORANGE, p[0]);
            pg.add(r);
            r.setValue(p[1]);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    askRemovePlace(p);
                }
            });
        }
        IRow add = nav(pg, -1, 0, "+  " + s(R.string.wx_add), new Runnable() {
            @Override
            public void run() {
                if (a.st.places().size() >= 6) {
                    a.toast(R.string.wx_max);
                    return;
                }
                askPlace();
            }
        });
        add.setTag("addplace");
    }

    private void askRemovePlace(final String[] p) {
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(a.getString(R.string.wx_remove, p[0]))
                .setPositiveButton(R.string.wx_remove_yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        ArrayList<String[]> l = new ArrayList<>(a.st.places());
                        for (int i = 0; i < l.size(); i++) {
                            if (Weather.key(l.get(i)).equals(Weather.key(p))) {
                                l.remove(i);
                                break;
                            }
                        }
                        a.st.setPlaces(l);
                        a.updateWeatherViews();
                        rebuildWeather();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void askPlace() {
        final EditText et = new EditText(a);
        et.setSingleLine(true);
        et.setHint(R.string.wx_hint);
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(R.string.wx_add)
                .setView(et)
                .setPositiveButton(R.string.wx_search, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String q = et.getText().toString().trim();
                        if (!q.isEmpty()) searchPlace(q);
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void searchPlace(String q) {
        a.toast(R.string.wx_searching);
        a.wx.search(q, new Weather.Found() {
            @Override
            public void found(final List<Weather.Hit> hits, boolean error) {
                // si la pantalla se cerró mientras se buscaba, un diálogo sobre una ventana que ya no existe tumbaría la app
                if (a.isFinishing() || a.isDestroyed()) return;
                if (error) {
                    a.toast(R.string.wx_error);
                    return;
                }
                if (hits.isEmpty()) {
                    a.toast(R.string.wx_none);
                    return;
                }
                CharSequence[] labels = new CharSequence[hits.size()];
                for (int i = 0; i < labels.length; i++) labels[i] = hits.get(i).label();
                new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                        .setTitle(R.string.wx_pick)
                        .setItems(labels, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dlg, int which) {
                                addPlace(hits.get(which));
                            }
                        })
                        .setNegativeButton(android.R.string.cancel, null)
                        .show();
            }
        });
    }

    private void addPlace(Weather.Hit h) {
        ArrayList<String[]> l = new ArrayList<>(a.st.places());
        String[] p = {h.name, h.country, String.valueOf(h.lat), String.valueOf(h.lon)};
        for (String[] x : l) {
            if (Weather.key(x).equals(Weather.key(p))) return;
        }
        l.add(p);
        a.st.setPlaces(l);
        a.refreshWeather(true);
        a.updateWeatherViews();
        a.toast(R.string.wx_added);
        rebuildWeather();
    }

    /** Vuelve a construir la página del tiempo dejando el foco en el mismo sitio (o en el que ocupe su lugar). */
    private void rebuildWeather() {
        if (!open || page != 4) return;
        Keep k = keepFocus(cols[4]);
        buildWeather();
        restoreFocus(cols[4], k);
    }

    // ------------------------------------------------------------------ dispositivo

    private IRow info(IGroup g, String title, String value) {
        IRow r = new IRow(a, a.u, -1, 0, title);
        r.setFocusable(false);
        r.setClickable(false);
        r.setValue(value);
        g.add(r);
        return r;
    }

    // ================================================================== v2.3: apps, pantalla, sonido, Mi Fire TV

    private boolean hiddenDirty;
    private int iconGen;
    private IRow rApps, rRam;
    private TextView wallStatus;

    private void flushHidden() {
        if (hiddenDirty) {
            hiddenDirty = false;
            a.refreshHome();
        }
    }

    private void loadIcons(final List<String> pkgs, final List<ImageView> views) {
        final int gen = ++iconGen;
        Bg.thread("lumen-icons", new Runnable() {
            @Override
            public void run() {
                PackageManager pm = a.getPackageManager();
                for (int i = 0; i < pkgs.size(); i++) {
                    if (gen != iconGen) return;
                    try {
                        final Drawable d = pm.getApplicationIcon(pkgs.get(i));
                        final ImageView v = views.get(i);
                        a.ui.post(new Runnable() {
                            @Override
                            public void run() {
                                v.setImageDrawable(d);
                            }
                        });
                    } catch (Throwable ignored) {
                    }
                }
            }
        }).start();
    }

    private ImageView iconSlot() {
        ImageView iv = new ImageView(a);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        return iv;
    }

    private String storageText() {
        try {
            StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
            return a.getString(R.string.sys_free_of, Formatter.formatFileSize(a, sf.getAvailableBytes()),
                    Formatter.formatFileSize(a, sf.getTotalBytes()));
        } catch (Throwable t) {
            return s(R.string.fire_na);
        }
    }

    private void storageBar(LinearLayout col) {
        try {
            StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
            float total = sf.getTotalBytes();
            float used = total - sf.getAvailableBytes();
            LinearLayout bar = new LinearLayout(a);
            bar.setOrientation(LinearLayout.HORIZONTAL);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0x33FFFFFF);
            bg.setCornerRadius(px(5));
            bar.setBackground(bg);
            View fill = new View(a);
            GradientDrawable fg = new GradientDrawable();
            fg.setColor(BLUE);
            fg.setCornerRadius(px(5));
            fill.setBackground(fg);
            float frac = total <= 0 ? 0f : Math.max(0.02f, Math.min(1f, used / total));
            bar.addView(fill, new LinearLayout.LayoutParams(0, -1, frac));
            bar.addView(new View(a), new LinearLayout.LayoutParams(0, -1, 1f - frac));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, px(10));
            lp.leftMargin = px(18);
            lp.rightMargin = px(18);
            lp.bottomMargin = px(12);
            col.addView(bar, lp);
        } catch (Throwable ignored) {
        }
    }

    // ---- Apps ocultas (lista de todas las apps; interruptor activado = oculta en Inicio)

    private void buildHidden() {
        LinearLayout col = cols[6];
        col.removeAllViews();
        header(col, s(R.string.set_hidden));
        label(col, s(R.string.hid_hint));
        IGroup g = group(col);
        Set<String> hid = a.st.hidden();
        ArrayList<String> pk = new ArrayList<>();
        ArrayList<ImageView> iv = new ArrayList<>();
        for (final AppItem it : a.apps) {
            final IRow r = new IRow(a, a.u, -1, 0, it.label);
            g.add(r);
            r.setTag("h:" + it.pkg);
            ImageView im = iconSlot();
            r.setLead(im, 38);
            r.setSwitch(hid.contains(it.pkg));
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean nv = !r.isOn();
                    r.setSwitch(nv);
                    HashSet<String> h = new HashSet<>(a.st.hidden());
                    if (nv) h.add(it.pkg);
                    else h.remove(it.pkg);
                    a.st.setHidden(h);
                    hiddenDirty = true;
                }
            });
            pk.add(it.pkg);
            iv.add(im);
        }
        loadIcons(pk, iv);
    }

    // ---- Apps instaladas

    private void buildApps() {
        final LinearLayout col = cols[7];
        col.removeAllViews();
        header(col, s(R.string.set_apps));
        IGroup gs = group(col);
        info(gs, s(R.string.apps_storage), storageText());
        storageBar(col);
        final TextView loading = label(col, s(R.string.apps_loading));
        final int gen = ++appsGen;   // si se sale y se vuelve a entrar antes de que acabe, solo vale la última lista (antes salían dos seguidas)
        Bg.thread("lumen-applist", new Runnable() {
            @Override
            public void run() {
                PackageManager pm = a.getPackageManager();
                final ArrayList<String[]> list = new ArrayList<>();
                try {
                    for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
                        boolean sys = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                        if (sys && pm.getLaunchIntentForPackage(ai.packageName) == null
                                && pm.getLeanbackLaunchIntentForPackage(ai.packageName) == null) continue;
                        CharSequence l = pm.getApplicationLabel(ai);
                        list.add(new String[]{ai.packageName, l == null ? ai.packageName : l.toString(),
                                sys ? "1" : "0"});
                    }
                } catch (Throwable ignored) {
                }
                Collections.sort(list, new Comparator<String[]>() {
                    @Override
                    public int compare(String[] x, String[] y) {
                        return x[1].compareToIgnoreCase(y[1]);
                    }
                });
                a.ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (!open || page != 7 || gen != appsGen) return;
                        col.removeView(loading);
                        IGroup g = group(col);
                        ArrayList<String> pk = new ArrayList<>();
                        ArrayList<ImageView> iv = new ArrayList<>();
                        for (final String[] it : list) {
                            IRow r = new IRow(a, a.u, -1, 0, it[1]);
                            g.add(r);
                            r.setTag("a:" + it[0]);
                            ImageView im = iconSlot();
                            r.setLead(im, 38);
                            if ("1".equals(it[2])) r.setValue(s(R.string.app_system));
                            r.setChevron();
                            r.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    lastAppKey = "a:" + it[0];
                                    a.openPlan(FireSettings.appPlan(a, it[0]),
                                            a.getString(R.string.path_app, it[1]));
                                }
                            });
                            pk.add(it[0]);
                            iv.add(im);
                        }
                        loadIcons(pk, iv);
                        String key = lastAppKey;
                        if (key != null) {
                            View v = findTag(col, key);
                            if (v != null) v.requestFocus();
                        }
                    }
                });
            }
        }).start();
    }

    private String lastAppKey;
    private int appsGen;

    private void showReport() {
        String text;
        try {
            text = FireSettings.report(a);
        } catch (Throwable t) {
            text = String.valueOf(t);
        }
        TextView tv = new TextView(a);
        tv.setText(text);
        tv.setTextSize(15f);
        tv.setPadding(px(24), px(12), px(24), px(12));
        tv.setFocusable(true);
        tv.setFocusableInTouchMode(true);
        ScrollView sv = new ScrollView(a);
        sv.addView(tv);
        new AlertDialog.Builder(a).setTitle(R.string.report_title).setView(sv)
                .setPositiveButton(android.R.string.ok, null).show();
    }

    /** Fila que abre una pantalla de ajustes del Fire TV original (con la ruta alternativa de siempre). */
    private IRow sysRoute(IGroup g, int glyph, int color, String title, final Intent std) {
        return nav(g, glyph, color, title, new Runnable() {
            @Override
            public void run() {
                a.openRoutes(FireSettings.routes(a, std));
            }
        });
    }

    // ---- Fondo (fotos reales por categoría, para el Inicio y la pantalla de bloqueo)

    /** Resumen de lo que hay: fotos encontradas por categoría y, si hay un problema, cuál es. */
    private String wallStatusText() {
        try {
            WallSource ws = a.wallSrc();
            StringBuilder sb = new StringBuilder();
            if (a.st.wallpaper() == WallSource.GTA) {
                // categoría de GTA VI: no usa el índice de fotos de Wikimedia
                sb.append(a.getString(R.string.wall_gta_found, ws.gtaCount()));
                sb.append("  ·  ").append(a.getString(R.string.wall_saved, ws.stored(),
                        Formatter.formatShortFileSize(a, ws.storedBytes())));
                if (ws.gtaLoading()) sb.append("  ·  ").append(s(R.string.wall_gta_loading));
                String ge = ws.gtaError();
                if (!ge.isEmpty()) sb.append('\n').append(a.getString(R.string.wall_gta_error, ge));
                return sb.toString();
            }
            int[] n = ws.counts();
            String err = ws.error();
            if (n[0] == 0) {
                sb.append(s(ws.indexing() || err.isEmpty() ? R.string.wall_searching_now : R.string.wall_none));
            } else {
                sb.append(a.getString(R.string.wall_found, n[1], n[2], n[3], n[4]));
                sb.append("  ·  ").append(a.getString(R.string.wall_saved, ws.stored(),
                        Formatter.formatShortFileSize(a, ws.storedBytes())));
                if (ws.indexing()) sb.append("  ·  ").append(s(R.string.wall_searching_now));
            }
            if (!err.isEmpty()) sb.append('\n').append(err);
            return sb.toString();
        } catch (Throwable t) {
            return "";
        }
    }

    /** Lo llama MainActivity cuando se encuentran fotos nuevas: se actualiza el resumen sin tocar el foco. */
    void photosChanged() {
        if (open && page == 11 && wallStatus != null) wallStatus.setText(wallStatusText());
    }

    /** Mientras se ve la página Fondo, el resumen se refresca cada 2 s (buscando… → fotos encontradas / error). */
    private final Runnable wallTick = new Runnable() {
        @Override
        public void run() {
            if (!open || page != 11 || wallStatus == null) return;
            wallStatus.setText(wallStatusText());
            a.ui.postDelayed(this, 2000);
        }
    };

    private IRow[] wallRows;

    /** Marca (punto verde y «Activo») la categoría de fondo elegida. */
    private void markWallRows() {
        if (wallRows == null) return;
        int cur = a.st.wallpaper();
        for (int i = 0; i < wallRows.length; i++) {
            wallRows[i].setStatus(cur == i, cur == i ? s(R.string.snd_active) : "");
        }
    }

    private void buildScreens() {
        LinearLayout col = cols[11];
        col.removeAllViews();
        header(col, s(R.string.set_wallpaper));
        label(col, s(R.string.wall_hint));
        IGroup g = group(col);
        int[] colors = {INDIGO, ORANGE, TEAL, PINK, BLUE, PURPLE};
        wallRows = new IRow[MainActivity.WP_NAMES.length];
        for (int i = 0; i < wallRows.length; i++) {
            final int w = i;
            IRow r = new IRow(a, a.u, Glyph.WALL, colors[i % colors.length], s(MainActivity.WP_NAMES[i]));
            g.add(r);
            r.setTag("wall" + i);
            wallRows[i] = r;
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    a.st.setWallpaper(w);
                    a.applyWallpaper();
                    markWallRows();   // solo cambia la marca de la fila elegida: sin reconstruir la página ni mover el foco
                    if (wallStatus != null) wallStatus.setText(wallStatusText());
                }
            });
        }
        markWallRows();
        wallStatus = a.text(wallStatusText(), 15, 0x99FFFFFF, MainActivity.REG);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = px(18);
        lp.topMargin = px(6);
        col.addView(wallStatus, lp);
        a.ui.removeCallbacks(wallTick);
        a.ui.postDelayed(wallTick, 2000);
        TextView note = a.text(s(R.string.wall_note), 14, 0x80FFFFFF, MainActivity.REG);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(-2, -2);
        lp2.leftMargin = px(18);
        lp2.topMargin = px(10);
        col.addView(note, lp2);
        TextView gtaNote = a.text(s(R.string.wall_gta_note), 14, 0x80FFFFFF, MainActivity.REG);
        LinearLayout.LayoutParams lp3 = new LinearLayout.LayoutParams(-2, -2);
        lp3.leftMargin = px(18);
        lp3.topMargin = px(10);
        col.addView(gtaNote, lp3);
    }

    // ---- Mi Fire TV (simple: solo lo básico + Liberar RAM)

    private String deviceType() {
        String m = Build.MODEL == null ? "" : Build.MODEL;
        if (m.equals("AFTMM")) return "Fire TV Stick 4K";
        if (m.equals("AFTKA")) return "Fire TV Stick 4K Max";
        if (m.equals("AFTGAZL")) return "Fire TV Stick 4K Max (2.ª gen)";
        if (m.equals("AFTSSS")) return "Fire TV Stick (3.ª gen)";
        if (m.equals("AFTSS")) return "Fire TV Stick Lite";
        if (m.equals("AFTT")) return "Fire TV Stick (2.ª gen)";
        if (m.equals("AFTN")) return "Fire TV (3.ª gen)";
        return m.isEmpty() ? s(R.string.fire_na) : m;
    }

    private void buildFire() {
        LinearLayout col = cols[5];
        col.removeAllViews();
        header(col, s(R.string.set_fire));
        // cómo te llama Lumen (Inicio y pantalla de bloqueo)
        IGroup gn = group(col);
        rName = nav(gn, Glyph.USER, GRAY, s(R.string.set_name), new Runnable() {
            @Override
            public void run() {
                askName();
            }
        });
        rName.setValue(nameLabel());

        IGroup g = group(col);
        info(g, s(R.string.fire_type), deviceType());
        info(g, s(R.string.fire_sw), (Build.DISPLAY == null ? "" : Build.DISPLAY) + " · Android " + Build.VERSION.RELEASE);
        info(g, s(R.string.fire_storage), storageText());

        IGroup g2 = group(col);
        rRam = nav(g2, Glyph.RAM, PINK, s(R.string.ram_tile), new Runnable() {
            @Override
            public void run() {
                freeRam();
            }
        });
        refreshRam();
        // «Todos los ajustes»: los Ajustes completos de Fire TV (mismo destino de siempre).
        // Mantener pulsado OK enseña un informe de qué pantallas de Amazon deja abrir este Fire TV.
        IRow all = sysRoute(g2, Glyph.GEAR, BLUE, s(R.string.fire_all), new Intent("android.settings.SYSTEM_UPDATE_SETTINGS"));
        all.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showReport();
                return true;
            }
        });
        nav(g2, Glyph.RAM, RED, s(R.string.fire_reboot), new Runnable() {
            @Override
            public void run() {
                restart();
            }
        });
    }

    // ---- Reiniciar

    /**
     * Reinicia el Fire TV. Fire OS solo deja hacerlo directamente a las apps con el permiso de reinicio (las de Amazon);
     * en una app normal lo que sí se puede es abrir el botón «Reiniciar» de sus ajustes originales, y eso es lo que se hace.
     * Si algún equipo concede el permiso, se pregunta y se reinicia al momento.
     */
    private void restart() {
        if (!canReboot()) {
            openRestartScreen();
            return;
        }
        new AlertDialog.Builder(a)
                .setTitle(R.string.fire_reboot_q)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        try {
                            ((PowerManager) a.getSystemService(Context.POWER_SERVICE)).reboot(null);
                        } catch (Throwable t) {
                            openRestartScreen();
                        }
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void openRestartScreen() {
        a.toastLong(s(R.string.fire_reboot_manual));
        // el aviso «Fire TV: Mi Fire TV → Reiniciar» sale cuando ya está abierta la pantalla de Amazon
        a.openPlan(FireSettings.restartPlan(a), s(R.string.path_restart));
    }

    private boolean canReboot() {
        try {
            return a.getPackageManager().checkPermission("android.permission.REBOOT", a.getPackageName())
                    == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }
}
