package dev.prisma.tv;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.text.InputType;
import android.text.format.Formatter;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Centro de control: panel lateral de cristal desde el que se ve y se cambia el dispositivo
 * (Wi-Fi, Bluetooth, volumen, RAM, atajos) sin salir del launcher.
 */
final class ControlCenter {
    interface Get { String get(); }
    interface Stp { void step(int dir); }

    private final MainActivity a;
    boolean open;
    private FrameLayout layer;
    private GlassView panel;
    private final ScrollView[] svs = new ScrollView[3];
    private final LinearLayout[] cols = new LinearLayout[3];
    private int page = -1;
    private View prevFocus;

    // página principal
    private TextView timeTv, dateTv, sysRam, sysStore, sysIp;
    private LinearLayout barRam, barStore;
    private Row rVol, rWall, rIdle, rName;
    private QTile tWifi, tBt, tAnim, tShelf, tSound, tClock, tHidden, tRam;

    // Wi-Fi
    private LinearLayout netList;
    private Row rWifiTog;
    private boolean scanning;

    // Bluetooth
    private LinearLayout btList;
    private Row rBtTog;
    private boolean discovering;
    private final ArrayList<BluetoothDevice> found = new ArrayList<>();

    private boolean rxOn;

    ControlCenter(MainActivity act) {
        a = act;
    }

    // ------------------------------------------------------------------ utilidades

    private int px(float v) {
        return a.px(v);
    }

    private String s(int res) {
        return a.getString(res);
    }

    private WifiManager wm() {
        return (WifiManager) a.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
    }

    private static boolean inside(View f, View container) {
        if (f == null) return false;
        View v = f;
        while (v != null) {
            if (v == container) return true;
            ViewParent p = v.getParent();
            v = p instanceof View ? (View) p : null;
        }
        return false;
    }

    private static View firstFocusable(View v) {
        if (v.isFocusable() && v.getVisibility() == View.VISIBLE && !(v instanceof ScrollView)) return v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = firstFocusable(g.getChildAt(i));
                if (r != null) return r;
            }
        }
        return null;
    }

    private Row row(LinearLayout col, String title, String value, final Runnable click) {
        final Row r = new Row(a, a.u, title);
        r.value.setText(value);
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.sfx.play(Sfx.SELECT);
                if (click != null) click.run();
            }
        });
        col.addView(r, new LinearLayout.LayoutParams(-1, px(58)));
        return r;
    }

    private Row arrowRow(LinearLayout col, String title, final Get get, final Stp stp) {
        final Row r = row(col, title, "", new Runnable() {
            @Override
            public void run() {
                stp.step(1);
            }
        });
        r.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int code, KeyEvent e) {
                if (e.getAction() != KeyEvent.ACTION_DOWN) return false;
                if (code == KeyEvent.KEYCODE_DPAD_LEFT) {
                    stp.step(-1);
                    r.value.setText("‹  " + get.get() + "  ›");
                    return true;
                }
                if (code == KeyEvent.KEYCODE_DPAD_RIGHT) {
                    stp.step(1);
                    r.value.setText("‹  " + get.get() + "  ›");
                    return true;
                }
                return false;
            }
        });
        r.value.setText("‹  " + get.get() + "  ›");
        return r;
    }

    private void arrowRefresh(Row r, Get g) {
        r.value.setText("‹  " + g.get() + "  ›");
    }

    private TextView label(LinearLayout col, String t) {
        TextView v = a.text(t, 14, 0x99FFFFFF, MainActivity.MEDIUM);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = px(22);
        lp.topMargin = px(18);
        lp.bottomMargin = px(8);
        col.addView(v, lp);
        return v;
    }

    private GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(r);
        return g;
    }

    // ------------------------------------------------------------------ abrir / cerrar

    void open(int startPage) {
        if (open) return;
        if (layer == null) build();
        open = true;
        prevFocus = a.root.findFocus();
        a.blockContent(true);
        a.setTint(0);
        a.root.addView(layer, new FrameLayout.LayoutParams(-1, -1));
        panel.setTranslationX(px(640));
        panel.animate().translationX(0f).setDuration(a.st.anim() ? 260 : 0)
                .setInterpolator(new DecelerateInterpolator()).start();
        page = -1;
        show(startPage, -1);
    }

    void close() {
        if (!open) return;
        unregister();
        stopDiscovery();
        open = false;
        a.root.removeView(layer);
        a.blockContent(false);
        if (prevFocus != null && prevFocus.isAttachedToWindow()) prevFocus.requestFocus();
        else a.focusFirstFav();
    }

    void back() {
        if (page == 1 || page == 2) {
            int from = page;
            show(0, from);
        } else {
            close();
        }
    }

    void tick() {
        if (timeTv != null && open) {
            timeTv.setText(a.fmtTime());
            dateTv.setText(a.fmtDate());
        }
    }

    void netChanged() {
        if (!open) return;
        if (page == 0) refreshMain();
        else if (page == 1) fillWifi(false);
    }

    void permResult() {
        if (!open) return;
        if (page == 1) {
            startScan();
            fillWifi(true);
        } else if (page == 2) {
            fillBt(true);
        }
    }

    private void show(int p, int from) {
        unregister();
        if (page == 2 && p != 2) stopDiscovery();
        page = p;
        for (int i = 0; i < 3; i++) svs[i].setVisibility(i == p ? View.VISIBLE : View.GONE);
        View f = null;
        if (p == 0) {
            refreshMain();
            f = from == 1 ? tWifi : (from == 2 ? tBt : firstFocusable(cols[0]));
        } else if (p == 1) {
            buildWifi();
            register(1);
            startScan();
            f = firstFocusable(cols[1]);
        } else {
            buildBt();
            register(2);
            f = firstFocusable(cols[2]);
        }
        if (f != null) f.requestFocus();
    }

    // ------------------------------------------------------------------ construcción

    private void build() {
        layer = new FrameLayout(a);
        layer.setBackgroundColor(0x55000000);
        layer.setClickable(true);
        layer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                close();
            }
        });
        panel = new GlassView(a, px(34), 0x78121A2C);
        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(px(600), -1, Gravity.END);
        pl.topMargin = px(24);
        pl.bottomMargin = px(24);
        pl.rightMargin = px(24);
        layer.addView(panel, pl);
        for (int i = 0; i < 3; i++) {
            ScrollView sv = new ScrollView(a);
            sv.setVerticalScrollBarEnabled(false);
            sv.setSmoothScrollingEnabled(true);
            sv.setClipToPadding(false);
            sv.setPadding(px(18), px(18), px(18), px(26));
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(LinearLayout.VERTICAL);
            sv.addView(col, new FrameLayout.LayoutParams(-1, -2));
            panel.addView(sv, new FrameLayout.LayoutParams(-1, -1));
            svs[i] = sv;
            cols[i] = col;
        }
        buildMain();
    }

    private QTile tile(int type, int color, int titleRes, final Runnable click) {
        QTile t = new QTile(a, a.u, type, color, s(titleRes));
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.sfx.play(Sfx.SELECT);
                click.run();
                refreshMain();
            }
        });
        return t;
    }

    private void pair(LinearLayout col, View l, View r) {
        LinearLayout h = new LinearLayout(a);
        h.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, px(100), 1f);
        lp.setMargins(px(5), px(5), px(5), px(5));
        h.addView(l, lp);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, px(100), 1f);
        rp.setMargins(px(5), px(5), px(5), px(5));
        h.addView(r, rp);
        col.addView(h, new LinearLayout.LayoutParams(-1, -2));
    }

    private void buildMain() {
        LinearLayout col = cols[0];
        col.removeAllViews();

        timeTv = a.text("", 54, 0xFFFFFFFF, MainActivity.LIGHT);
        dateTv = a.text("", 17, 0xB8FFFFFF, MainActivity.REG);
        LinearLayout.LayoutParams t1 = new LinearLayout.LayoutParams(-2, -2);
        t1.leftMargin = px(22);
        t1.topMargin = px(6);
        col.addView(timeTv, t1);
        LinearLayout.LayoutParams t2 = new LinearLayout.LayoutParams(-2, -2);
        t2.leftMargin = px(24);
        t2.bottomMargin = px(12);
        col.addView(dateTv, t2);

        tWifi = tile(Glyph.WIFI, 0xFF2F7CF6, R.string.set_wifi, new Runnable() {
            @Override
            public void run() {
                show(1, 0);
            }
        });
        tBt = tile(Glyph.BT, 0xFF2F7CF6, R.string.set_bt, new Runnable() {
            @Override
            public void run() {
                show(2, 0);
            }
        });
        pair(col, tWifi, tBt);

        rVol = arrowRow(col, s(R.string.set_volume), new Get() {
            @Override
            public String get() {
                return volText();
            }
        }, new Stp() {
            @Override
            public void step(int d) {
                volStep(d);
            }
        });
        rWall = arrowRow(col, s(R.string.set_wallpaper), new Get() {
            @Override
            public String get() {
                return s(MainActivity.WP_NAMES[a.st.wallpaper()]);
            }
        }, new Stp() {
            @Override
            public void step(int d) {
                int n = WallpaperFactory.COUNT;
                a.st.setWallpaper((a.st.wallpaper() + d + n) % n);
                a.applyWallpaper();
            }
        });

        tAnim = tile(Glyph.ANIM, 0xFFF59E0B, R.string.set_anim, new Runnable() {
            @Override
            public void run() {
                a.st.setAnim(!a.st.anim());
                a.stopDrift();
                a.startDrift();
            }
        });
        tShelf = tile(Glyph.SHELF, 0xFFA855F7, R.string.set_shelf, new Runnable() {
            @Override
            public void run() {
                a.st.setShelf(!a.st.shelf());
                if (!a.st.shelf()) a.setTint(0);
            }
        });
        pair(col, tAnim, tShelf);

        tSound = tile(Glyph.SOUND, 0xFFEF4444, R.string.set_sound, new Runnable() {
            @Override
            public void run() {
                a.st.setSound(!a.st.sound());
                a.sfx.enabled = a.st.sound();
            }
        });
        tClock = tile(Glyph.CLOCK, 0xFF14B8A6, R.string.set_clock, new Runnable() {
            @Override
            public void run() {
                a.st.setH24(!a.st.h24());
                a.updateClock();
            }
        });
        pair(col, tSound, tClock);

        tHidden = tile(Glyph.HIDDEN, 0xFF22C55E, R.string.set_hidden, new Runnable() {
            @Override
            public void run() {
                if (!a.st.hidden().isEmpty()) {
                    a.st.setHidden(new HashSet<String>());
                    a.refreshHome();
                    a.toast(R.string.toast_restored);
                }
            }
        });
        tRam = tile(Glyph.RAM, 0xFFEC4899, R.string.ram_tile, new Runnable() {
            @Override
            public void run() {
                freeRam();
            }
        });
        pair(col, tHidden, tRam);

        // Sistema
        label(col, s(R.string.sys_title).toUpperCase());
        LinearLayout sys = new LinearLayout(a);
        sys.setOrientation(LinearLayout.VERTICAL);
        sys.setPadding(px(22), px(6), px(22), px(10));
        sysIp = a.text("", 17, 0xFFFFFFFF, MainActivity.REG);
        sys.addView(sysIp);
        sysRam = a.text("", 16, 0xDDFFFFFF, MainActivity.REG);
        LinearLayout.LayoutParams s1 = new LinearLayout.LayoutParams(-2, -2);
        s1.topMargin = px(14);
        sys.addView(sysRam, s1);
        barRam = bar();
        LinearLayout.LayoutParams b1 = new LinearLayout.LayoutParams(-1, px(8));
        b1.topMargin = px(6);
        sys.addView(barRam, b1);
        sysStore = a.text("", 16, 0xDDFFFFFF, MainActivity.REG);
        LinearLayout.LayoutParams s2 = new LinearLayout.LayoutParams(-2, -2);
        s2.topMargin = px(14);
        sys.addView(sysStore, s2);
        barStore = bar();
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(-1, px(8));
        b2.topMargin = px(6);
        sys.addView(barStore, b2);
        col.addView(sys, new LinearLayout.LayoutParams(-1, -2));

        // Personalizar
        label(col, s(R.string.cc_personal));
        rIdle = arrowRow(col, s(R.string.set_idle), new Get() {
            @Override
            public String get() {
                int m = a.st.idleMin();
                return m == 0 ? s(R.string.idle_off) : a.getString(R.string.idle_min, m);
            }
        }, new Stp() {
            @Override
            public void step(int d) {
                int idx = 0;
                for (int i = 0; i < MainActivity.IDLE_OPTS.length; i++) {
                    if (MainActivity.IDLE_OPTS[i] == a.st.idleMin()) idx = i;
                }
                int n = MainActivity.IDLE_OPTS.length;
                idx = (idx + d + n) % n;
                a.st.setIdleMin(MainActivity.IDLE_OPTS[idx]);
                a.resetIdle();
            }
        });
        rName = row(col, s(R.string.set_name), "", new Runnable() {
            @Override
            public void run() {
                askName();
            }
        });

        // Atajos del sistema (solo los que este dispositivo permite abrir)
        String[] acts = {Settings.ACTION_DISPLAY_SETTINGS, Settings.ACTION_SOUND_SETTINGS,
                Settings.ACTION_ACCESSIBILITY_SETTINGS, Settings.ACTION_DATE_SETTINGS,
                Settings.ACTION_DEVICE_INFO_SETTINGS, Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS};
        int[] names = {R.string.sc_display, R.string.sc_sound, R.string.sc_access, R.string.sc_date,
                R.string.sc_device, R.string.sc_apps};
        boolean titled = false;
        for (int i = 0; i < acts.length; i++) {
            final String act = acts[i];
            if (a.getPackageManager().resolveActivity(new Intent(act), 0) == null) continue;
            if (!titled) {
                label(col, s(R.string.sc_title));
                titled = true;
            }
            row(col, s(names[i]), "›", new Runnable() {
                @Override
                public void run() {
                    a.tryStart(new Intent(act), new Intent(Settings.ACTION_SETTINGS));
                }
            });
        }
        if (!titled) label(col, s(R.string.sc_title));
        row(col, s(R.string.sc_all), "›", new Runnable() {
            @Override
            public void run() {
                a.openSystemSettings();
            }
        });
    }

    private LinearLayout bar() {
        LinearLayout b = new LinearLayout(a);
        b.setBackground(round(0x33FFFFFF, px(4)));
        View f = new View(a);
        f.setBackground(round(0xFFFFFFFF, px(4)));
        b.addView(f, new LinearLayout.LayoutParams(0, -1, 0.5f));
        b.addView(new View(a), new LinearLayout.LayoutParams(0, -1, 0.5f));
        return b;
    }

    private void setBar(LinearLayout b, float frac) {
        frac = Math.max(0.02f, Math.min(1f, frac));
        ((LinearLayout.LayoutParams) b.getChildAt(0).getLayoutParams()).weight = frac;
        ((LinearLayout.LayoutParams) b.getChildAt(1).getLayoutParams()).weight = 1f - frac;
        b.requestLayout();
    }

    private void refreshMain() {
        if (timeTv == null) return;
        timeTv.setText(a.fmtTime());
        dateTv.setText(a.fmtDate());

        tWifi.setSub(wifiSummary());
        tBt.setSub(btSummary());
        tAnim.setSub(s(a.st.anim() ? R.string.anim_full : R.string.anim_reduced));
        tShelf.setSub(s(a.st.shelf() ? R.string.shelf_on : R.string.shelf_off));
        tSound.setSub(s(a.st.sound() ? R.string.yes : R.string.no));
        tClock.setSub(s(a.st.h24() ? R.string.h24 : R.string.h12));
        int hid = a.st.hidden().size();
        tHidden.setSub(hid == 0 ? s(R.string.hidden_none) : a.getString(R.string.hidden_show, hid));

        arrowRefresh(rVol, new Get() {
            @Override
            public String get() {
                return volText();
            }
        });
        arrowRefresh(rWall, new Get() {
            @Override
            public String get() {
                return s(MainActivity.WP_NAMES[a.st.wallpaper()]);
            }
        });
        arrowRefresh(rIdle, new Get() {
            @Override
            public String get() {
                int m = a.st.idleMin();
                return m == 0 ? s(R.string.idle_off) : a.getString(R.string.idle_min, m);
            }
        });
        String n = a.st.name();
        rName.value.setText(n.isEmpty() ? s(R.string.name_none) : n);

        try {
            ActivityManager am = (ActivityManager) a.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            tRam.setSub(a.getString(R.string.ram_sub, Formatter.formatFileSize(a, mi.availMem)));
            sysRam.setText(s(R.string.sys_ram) + "   " + a.getString(R.string.sys_free_of,
                    Formatter.formatFileSize(a, mi.availMem), Formatter.formatFileSize(a, mi.totalMem)));
            setBar(barRam, mi.totalMem == 0 ? 0f : mi.availMem / (float) mi.totalMem);
            StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
            long free = sf.getAvailableBytes();
            long total = sf.getTotalBytes();
            sysStore.setText(s(R.string.sys_store) + "   " + a.getString(R.string.sys_free_of,
                    Formatter.formatFileSize(a, free), Formatter.formatFileSize(a, total)));
            setBar(barStore, total == 0 ? 0f : free / (float) total);
        } catch (Throwable ignored) {
        }
        sysIp.setText(s(R.string.sys_ip) + "   " + wifiIp());
    }

    private String wifiIp() {
        try {
            int ip = wm().getConnectionInfo().getIpAddress();
            if (ip == 0) return "—";
            return (ip & 0xff) + "." + ((ip >> 8) & 0xff) + "." + ((ip >> 16) & 0xff) + "." + ((ip >> 24) & 0xff);
        } catch (Throwable t) {
            return "—";
        }
    }

    private String wifiSummary() {
        try {
            WifiManager w = wm();
            if (!w.isWifiEnabled()) return s(R.string.bt_off);
            String ssid = w.getConnectionInfo().getSSID();
            if (ssid == null || ssid.contains("unknown") || ssid.equals("<unknown ssid>")) return s(R.string.net_off);
            return ssid.replace("\"", "");
        } catch (Throwable t) {
            return "";
        }
    }

    private String btSummary() {
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            if (ad == null) return s(R.string.bt_na);
            if (!ad.isEnabled()) return s(R.string.bt_off);
            int n = 0;
            for (BluetoothDevice d : ad.getBondedDevices()) {
                if (isConn(d)) n++;
            }
            return n > 0 ? a.getString(R.string.bt_n_conn, n) : s(R.string.bt_on);
        } catch (Throwable t) {
            return "";
        }
    }

    // ------------------------------------------------------------------ volumen y RAM

    private String volText() {
        try {
            AudioManager am = (AudioManager) a.getSystemService(Context.AUDIO_SERVICE);
            return am.getStreamVolume(AudioManager.STREAM_MUSIC) + " / " + am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        } catch (Throwable t) {
            return "—";
        }
    }

    private void volStep(int d) {
        try {
            AudioManager am = (AudioManager) a.getSystemService(Context.AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            int v = am.getStreamVolume(AudioManager.STREAM_MUSIC) + d;
            if (v > max) v = 0;
            if (v < 0) v = max;
            am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0);
        } catch (Throwable ignored) {
        }
    }

    private void freeRam() {
        try {
            final ActivityManager am = (ActivityManager) a.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            final long before = mi.availMem;
            for (AppItem x : a.apps) {
                try {
                    am.killBackgroundProcesses(x.pkg);
                } catch (Throwable ignored) {
                }
            }
            a.ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    ActivityManager.MemoryInfo m2 = new ActivityManager.MemoryInfo();
                    am.getMemoryInfo(m2);
                    long freed = m2.availMem - before;
                    if (freed > 4L * 1024 * 1024) {
                        a.toast(a.getString(R.string.ram_done, Formatter.formatFileSize(a, freed)));
                    } else {
                        a.toast(R.string.ram_ok);
                    }
                    if (open && page == 0) refreshMain();
                }
            }, 900);
        } catch (Throwable ignored) {
        }
    }

    private void askName() {
        final EditText et = new EditText(a);
        et.setSingleLine(true);
        et.setText(a.st.name());
        et.setSelection(et.getText().length());
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(R.string.set_name)
                .setView(et)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        a.st.setName(et.getText().toString());
                        a.updateClock();
                        refreshMain();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    // ------------------------------------------------------------------ receptor de eventos Wi-Fi / Bluetooth

    private final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String act = i.getAction();
            if (act == null || !open) return;
            if (page == 1) {
                if (rWifiTog != null) rWifiTog.value.setText(s(wm().isWifiEnabled() ? R.string.yes : R.string.no));
                scanning = false;
                fillWifi(false);
            } else if (page == 2) {
                if (BluetoothDevice.ACTION_FOUND.equals(act)) {
                    BluetoothDevice d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    if (d != null && !found.contains(d)) found.add(d);
                } else if (BluetoothAdapter.ACTION_DISCOVERY_STARTED.equals(act)) {
                    discovering = true;
                } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(act)) {
                    discovering = false;
                }
                if (rBtTog != null) rBtTog.value.setText(s(btOn() ? R.string.yes : R.string.no));
                fillBt(false);
            }
        }
    };

    private void register(int p) {
        IntentFilter f = new IntentFilter();
        if (p == 1) {
            f.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
            f.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
            f.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        } else {
            f.addAction(BluetoothDevice.ACTION_FOUND);
            f.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
            f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
            f.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
            f.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
            f.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
            f.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        }
        try {
            a.registerReceiver(rx, f);
            rxOn = true;
        } catch (Throwable ignored) {
        }
    }

    private void unregister() {
        if (!rxOn) return;
        try {
            a.unregisterReceiver(rx);
        } catch (Throwable ignored) {
        }
        rxOn = false;
    }

    // ------------------------------------------------------------------ Wi-Fi

    private void startScan() {
        if (!a.ensureLocation()) return;
        try {
            scanning = wm().startScan();
        } catch (Throwable ignored) {
        }
    }

    private void buildWifi() {
        LinearLayout col = cols[1];
        col.removeAllViews();
        row(col, "‹  " + s(R.string.set_wifi), "", new Runnable() {
            @Override
            public void run() {
                show(0, 1);
            }
        });
        rWifiTog = row(col, s(R.string.set_wifi), s(wm().isWifiEnabled() ? R.string.yes : R.string.no),
                new Runnable() {
                    @Override
                    public void run() {
                        try {
                            boolean on = wm().isWifiEnabled();
                            if (!wm().setWifiEnabled(!on)) a.openWifiSettings();
                        } catch (Throwable t) {
                            a.openWifiSettings();
                        }
                        a.ui.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (open && page == 1) {
                                    rWifiTog.value.setText(s(wm().isWifiEnabled() ? R.string.yes : R.string.no));
                                    startScan();
                                    fillWifi(true);
                                }
                            }
                        }, 1500);
                    }
                });
        label(col, s(R.string.wifi_networks));
        netList = new LinearLayout(a);
        netList.setOrientation(LinearLayout.VERTICAL);
        col.addView(netList, new LinearLayout.LayoutParams(-1, -2));
        fillWifi(true);
    }

    private void fillWifi(boolean force) {
        if (netList == null || page != 1) return;
        View cur = a.root.findFocus();
        boolean had = inside(cur, netList);
        if (!force && had) return;
        netList.removeAllViews();
        final WifiManager w = wm();
        if (!w.isWifiEnabled()) {
            row(netList, s(R.string.bt_off), "", null);
            return;
        }
        String connected = null;
        String ip = wifiIp();
        try {
            WifiInfo wi = w.getConnectionInfo();
            if (wi != null && wi.getSSID() != null && !wi.getSSID().contains("unknown")) {
                connected = wi.getSSID().replace("\"", "");
            }
        } catch (Throwable ignored) {
        }

        HashMap<String, ScanResult> best = new HashMap<>();
        try {
            List<ScanResult> res = w.getScanResults();
            if (res != null) {
                for (ScanResult r : res) {
                    if (r.SSID == null || r.SSID.isEmpty()) continue;
                    ScanResult o = best.get(r.SSID);
                    if (o == null || r.level > o.level) best.put(r.SSID, r);
                }
            }
        } catch (Throwable ignored) {
        }
        ArrayList<ScanResult> list = new ArrayList<>(best.values());
        Collections.sort(list, new Comparator<ScanResult>() {
            @Override
            public int compare(ScanResult x, ScanResult y) {
                return y.level - x.level;
            }
        });

        // la conectada primero
        final String conn = connected;
        if (conn != null) {
            ScanResult mine = best.get(conn);
            boolean sec = mine != null && isSecure(mine);
            Row r = row(netList, conn, a.getString(R.string.wifi_connected, ip) + (sec ? "  ·  " + s(R.string.wifi_secure) : ""),
                    new Runnable() {
                        @Override
                        public void run() {
                            a.toast(R.string.wifi_already);
                        }
                    });
            list.remove(mine);
        }
        for (final ScanResult r : list) {
            final boolean sec = isSecure(r);
            row(netList, r.SSID, s(sec ? R.string.wifi_secure : R.string.wifi_open), new Runnable() {
                @Override
                public void run() {
                    connectTo(r.SSID, sec);
                }
            });
        }
        if (conn == null && list.isEmpty()) {
            row(netList, s(scanning ? R.string.wifi_searching : R.string.wifi_none), "", null);
        }
        row(netList, s(R.string.wifi_rescan), "", new Runnable() {
            @Override
            public void run() {
                startScan();
                a.toast(R.string.wifi_searching);
            }
        });
        row(netList, s(R.string.sc_wifi_sys), "›", new Runnable() {
            @Override
            public void run() {
                a.openWifiSettings();
            }
        });
        if (had) {
            View f = firstFocusable(netList);
            if (f != null) f.requestFocus();
        }
    }

    private static boolean isSecure(ScanResult r) {
        String c = r.capabilities == null ? "" : r.capabilities;
        return c.contains("WPA") || c.contains("WEP") || c.contains("PSK") || c.contains("EAP") || c.contains("SAE");
    }

    private void connectTo(final String ssid, boolean secure) {
        // ¿ya está guardada?
        try {
            List<WifiConfiguration> saved = wm().getConfiguredNetworks();
            if (saved != null) {
                for (WifiConfiguration c : saved) {
                    if (c.SSID != null && c.SSID.equals("\"" + ssid + "\"")) {
                        join(c.networkId);
                        return;
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        if (!secure) {
            addAndJoin(ssid, null);
            return;
        }
        final EditText et = new EditText(a);
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(a.getString(R.string.wifi_pw_title, ssid))
                .setView(et)
                .setPositiveButton(R.string.wifi_connect, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        addAndJoin(ssid, et.getText().toString());
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void addAndJoin(String ssid, String pwd) {
        try {
            WifiConfiguration c = new WifiConfiguration();
            c.SSID = "\"" + ssid + "\"";
            if (pwd == null) {
                c.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
            } else {
                c.preSharedKey = "\"" + pwd + "\"";
            }
            int id = wm().addNetwork(c);
            if (id < 0) {
                a.toast(R.string.wifi_fail);
                a.openWifiSettings();
                return;
            }
            join(id);
        } catch (Throwable t) {
            a.toast(R.string.wifi_fail);
            a.openWifiSettings();
        }
    }

    private void join(int id) {
        try {
            WifiManager w = wm();
            w.disconnect();
            boolean ok = w.enableNetwork(id, true);
            w.reconnect();
            a.toast(ok ? R.string.wifi_connecting : R.string.wifi_fail);
        } catch (Throwable t) {
            a.toast(R.string.wifi_fail);
        }
    }

    // ------------------------------------------------------------------ Bluetooth

    private boolean btOn() {
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            return ad != null && ad.isEnabled();
        } catch (Throwable t) {
            return false;
        }
    }

    private boolean isConn(BluetoothDevice d) {
        try {
            Method m = d.getClass().getMethod("isConnected");
            return (Boolean) m.invoke(d);
        } catch (Throwable t) {
            return false;
        }
    }

    private void stopDiscovery() {
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            if (ad != null && ad.isDiscovering()) ad.cancelDiscovery();
        } catch (Throwable ignored) {
        }
        discovering = false;
    }

    private void buildBt() {
        LinearLayout col = cols[2];
        col.removeAllViews();
        found.clear();
        row(col, "‹  " + s(R.string.set_bt), "", new Runnable() {
            @Override
            public void run() {
                show(0, 2);
            }
        });
        rBtTog = row(col, s(R.string.set_bt), s(btOn() ? R.string.yes : R.string.no), new Runnable() {
            @Override
            public void run() {
                try {
                    BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
                    if (ad == null) {
                        a.openBluetoothSettings();
                    } else if (ad.isEnabled()) {
                        stopDiscovery();
                        ad.disable();
                    } else {
                        ad.enable();
                    }
                } catch (Throwable t) {
                    a.openBluetoothSettings();
                }
                a.ui.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (open && page == 2) {
                            rBtTog.value.setText(s(btOn() ? R.string.yes : R.string.no));
                            fillBt(true);
                        }
                    }
                }, 1500);
            }
        });
        btList = new LinearLayout(a);
        btList.setOrientation(LinearLayout.VERTICAL);
        col.addView(btList, new LinearLayout.LayoutParams(-1, -2));
        fillBt(true);
    }

    private String kind(BluetoothDevice d) {
        try {
            BluetoothClass bc = d.getBluetoothClass();
            if (bc != null) {
                int m = bc.getMajorDeviceClass();
                if (m == BluetoothClass.Device.Major.AUDIO_VIDEO) return s(R.string.bt_audio);
                if (m == BluetoothClass.Device.Major.PERIPHERAL) return s(R.string.bt_periph);
            }
        } catch (Throwable ignored) {
        }
        return "";
    }

    private String nameOf(BluetoothDevice d) {
        String n = null;
        try {
            n = d.getName();
        } catch (Throwable ignored) {
        }
        return n == null || n.isEmpty() ? d.getAddress() : n;
    }

    private void fillBt(boolean force) {
        if (btList == null || page != 2) return;
        View cur = a.root.findFocus();
        boolean had = inside(cur, btList);
        if (!force && had) return;
        btList.removeAllViews();
        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null) {
            row(btList, s(R.string.bt_na), "", null);
            return;
        }
        if (!ad.isEnabled()) {
            row(btList, s(R.string.bt_off), "", null);
            return;
        }
        if (!a.ensureLocation()) {
            row(btList, s(R.string.need_perm), "", null);
        }
        label(btList, s(R.string.bt_my));
        Set<BluetoothDevice> bonded = new HashSet<>();
        try {
            bonded = ad.getBondedDevices();
        } catch (Throwable ignored) {
        }
        if (bonded.isEmpty()) row(btList, s(R.string.bt_none), "", null);
        for (final BluetoothDevice d : bonded) {
            String st = isConn(d) ? s(R.string.bt_connected) : s(R.string.bt_paired);
            String k = kind(d);
            row(btList, nameOf(d), k.isEmpty() ? st : st + "  ·  " + k, new Runnable() {
                @Override
                public void run() {
                    askForget(d);
                }
            });
        }
        label(btList, s(R.string.bt_other));
        row(btList, s(discovering ? R.string.bt_searching : R.string.bt_search), "", new Runnable() {
            @Override
            public void run() {
                try {
                    BluetoothAdapter x = BluetoothAdapter.getDefaultAdapter();
                    if (x == null) return;
                    if (!a.ensureLocation()) return;
                    if (x.isDiscovering()) x.cancelDiscovery();
                    found.clear();
                    x.startDiscovery();
                    discovering = true;
                    fillBt(true);
                } catch (Throwable t) {
                    a.openBluetoothSettings();
                }
            }
        });
        for (final BluetoothDevice d : found) {
            if (bonded.contains(d)) continue;
            String k = kind(d);
            row(btList, nameOf(d), k, new Runnable() {
                @Override
                public void run() {
                    try {
                        stopDiscovery();
                        d.createBond();
                        a.toast(R.string.bt_pairing);
                    } catch (Throwable t) {
                        a.openBluetoothSettings();
                    }
                }
            });
        }
        row(btList, s(R.string.sc_bt_sys), "›", new Runnable() {
            @Override
            public void run() {
                a.openBluetoothSettings();
            }
        });
        if (had) {
            View f = firstFocusable(btList);
            if (f != null) f.requestFocus();
        }
    }

    private void askForget(final BluetoothDevice d) {
        String n = nameOf(d);
        if (n.toLowerCase().contains("remote") || n.toLowerCase().contains("mando")) {
            a.toast(R.string.bt_protected);
            return;
        }
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(a.getString(R.string.bt_forget, n))
                .setPositiveButton(R.string.bt_forget_yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface x, int w) {
                        try {
                            Method m = d.getClass().getMethod("removeBond");
                            m.invoke(d);
                        } catch (Throwable t) {
                            a.openBluetoothSettings();
                        }
                        a.ui.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (open && page == 2) fillBt(true);
                            }
                        }, 800);
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }
}
