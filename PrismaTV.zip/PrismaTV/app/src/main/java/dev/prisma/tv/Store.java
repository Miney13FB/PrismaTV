package dev.prisma.tv;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Preferencias del launcher (todo local, sin cuentas ni analítica). */
final class Store {
    private final SharedPreferences sp;

    Store(Context c) {
        // el nombre del archivo de ajustes no cambia con el nombre de la app: así se conserva todo al actualizar
        sp = c.getSharedPreferences("prisma", Context.MODE_PRIVATE);
    }

    String name() { return sp.getString("name", ""); }
    void setName(String v) { sp.edit().putString("name", v == null ? "" : v.trim()).apply(); }

    int wallpaper() { int v = sp.getInt("wall", 0); return v < 0 || v > 4 ? 0 : v; }
    void setWallpaper(int v) { sp.edit().putInt("wall", v).apply(); }

    boolean anim() { return sp.getBoolean("anim", true); }

    boolean lockOn() { return sp.getBoolean("lockOn", true); }
    void setLockOn(boolean v) { sp.edit().putBoolean("lockOn", v).apply(); }

    boolean wxHome() { return sp.getBoolean("wxHome", false); }
    void setWxHome(boolean v) { sp.edit().putBoolean("wxHome", v).apply(); }

    boolean wxLock() { return sp.getBoolean("wxLock", true); }
    void setWxLock(boolean v) { sp.edit().putBoolean("wxLock", v).apply(); }

    /** Lugares del tiempo: {ciudad, país, latitud, longitud}. */
    List<String[]> places() {
        ArrayList<String[]> out = new ArrayList<>();
        String raw = sp.getString("places", "");
        if (raw == null || raw.isEmpty()) return out;
        for (String line : raw.split("\n")) {
            String[] p = line.split("\t");
            if (p.length == 4) out.add(p);
        }
        return out;
    }

    void setPlaces(List<String[]> l) {
        StringBuilder sb = new StringBuilder();
        for (String[] p : l) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(p[0]).append('\t').append(p[1]).append('\t').append(p[2]).append('\t').append(p[3]);
        }
        sp.edit().putString("places", sb.toString()).apply();
    }

    boolean sound() { return sp.getBoolean("sound", true); }
    void setSound(boolean v) { sp.edit().putBoolean("sound", v).apply(); }

    /**
     * Cuándo y con qué versión sonó por última vez el acorde de arranque: así no se repite cada vez que el sistema reinicia
     * el launcher por falta de memoria.
     */
    long chimeAt() { return sp.getLong("chimeAt", 0L); }
    int chimeVer() { return sp.getInt("chimeVer", 0); }
    void setChime(long at, int ver) { sp.edit().putLong("chimeAt", at).putInt("chimeVer", ver).apply(); }

    int idleMin() { return sp.getInt("idle", 5); }
    void setIdleMin(int v) { sp.edit().putInt("idle", v).apply(); }

    /**
     * La bienvenida y la configuración inicial solo salen la primera vez: aquí queda guardado que ya se hicieron.
     * La clave es nueva en la 3.0 (la bienvenida de Lumen es otra): al actualizar sale una vez con lo que ya tenías puesto.
     */
    boolean setupDone() { return sp.getBoolean("setupLumen", false); }
    void setSetupDone(boolean v) { sp.edit().putBoolean("setupLumen", v).apply(); }

    boolean favsReady() { return sp.getBoolean("favsReady", false); }

    List<String> favs() { return readList("favs"); }
    void setFavs(List<String> l) {
        sp.edit().putString("favs", join(l)).putBoolean("favsReady", true).apply();
    }

    Set<String> hidden() { return new HashSet<>(readList("hidden")); }
    void setHidden(Set<String> s) { sp.edit().putString("hidden", join(new ArrayList<>(s))).apply(); }

    private List<String> readList(String k) {
        ArrayList<String> out = new ArrayList<>();
        String raw = sp.getString(k, "");
        if (raw == null || raw.isEmpty()) return out;
        for (String s : raw.split("\n")) {
            if (!s.isEmpty()) out.add(s);
        }
        return out;
    }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String s : l) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(s);
        }
        return sb.toString();
    }
}
