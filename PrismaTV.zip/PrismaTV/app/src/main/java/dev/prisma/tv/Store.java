package dev.prisma.tv;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Preferencias del launcher (todo local, sin cuentas ni analítica). */
final class Store {
    private final SharedPreferences sp;

    Store(Context c) {
        sp = c.getSharedPreferences("prisma", Context.MODE_PRIVATE);
    }

    String name() { return sp.getString("name", ""); }
    void setName(String v) { sp.edit().putString("name", v == null ? "" : v.trim()).apply(); }

    int wallpaper() { return sp.getInt("wall", 0); }
    void setWallpaper(int v) { sp.edit().putInt("wall", v).apply(); }

    boolean anim() { return sp.getBoolean("anim", true); }
    void setAnim(boolean v) { sp.edit().putBoolean("anim", v).apply(); }

    boolean sound() { return sp.getBoolean("sound", true); }
    void setSound(boolean v) { sp.edit().putBoolean("sound", v).apply(); }

    boolean h24() { return sp.getBoolean("h24", true); }
    void setH24(boolean v) { sp.edit().putBoolean("h24", v).apply(); }

    int idleMin() { return sp.getInt("idle", 5); }
    void setIdleMin(int v) { sp.edit().putInt("idle", v).apply(); }

    boolean favsReady() { return sp.getBoolean("favsReady", false); }

    List<String> favs() { return readList("favs"); }
    void setFavs(List<String> l) {
        sp.edit().putString("favs", join(l)).putBoolean("favsReady", true).apply();
    }

    Set<String> hidden() { return new HashSet<>(readList("hidden")); }
    void setHidden(Set<String> s) { sp.edit().putString("hidden", join(new ArrayList<>(s))).apply(); }

    private List<String> readList(String k) {
        ArrayList<String> out = new ArrayList<>();
        String raw = sp.getString(k, "");
        if (raw == null || raw.isEmpty()) return out;
        for (String s : raw.split("\n")) {
            if (!s.isEmpty()) out.add(s);
        }
        return out;
    }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String s : l) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(s);
        }
        return sb.toString();
    }
}
