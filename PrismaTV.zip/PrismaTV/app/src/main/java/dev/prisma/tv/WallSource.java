package dev.prisma.tv;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Fondos con fotos reales de animales, paisajes, lugares del mundo y ciudades.
 * Las fotos salen de Wikimedia Commons (imágenes destacadas, licencias libres) y se guardan en el
 * dispositivo la primera vez. Sin internet se usan los fondos abstractos generados por código.
 */
final class WallSource {
    static final int MIX = 0, ANIMALS = 1, LAND = 2, WORLD = 3, CITIES = 4, ABSTRACT = 5;
    private static final String UA = "PrismaTV/2.4 (launcher personal para Fire TV)";
    private static final String[][] KW = {
            {},
            {"lion", "tiger", "eagle", "wolf", "elephant", "fox", "owl", "bear", "whale", "parrot", "horse", "butterfly"},
            {"mountain", "lake", "waterfall", "forest", "sunset", "desert", "glacier", "valley"},
            {"temple", "castle", "pyramid", "bridge", "cathedral", "island", "palace", "ruins"},
            {"skyline", "cityscape night", "harbour city", "downtown"}};

    private final SharedPreferences sp;
    private final File dir;
    private final Random rnd = new Random();
    private volatile boolean indexing;
    private String last = "";
    private int lastAbs = -1;

    WallSource(Context c) {
        sp = c.getSharedPreferences("prisma_walls", Context.MODE_PRIVATE);
        dir = new File(c.getFilesDir(), "walls");
        dir.mkdirs();
    }

    /** Se llama en un hilo en segundo plano. Devuelve siempre un bitmap de 16:9 listo para usar. */
    Bitmap next(int mode) {
        if (mode != ABSTRACT) {
            ensureIndexAsync();
            List<String[]> l = entries(mode);
            for (int tries = 0; tries < 3 && !l.isEmpty(); tries++) {
                String[] e = pick(l);
                File f = file(e[1]);
                if (!f.exists() && !download(e[1], f)) continue;
                Bitmap b = decode(f);
                if (b != null) {
                    last = e[1];
                    return veil(b);
                }
            }
        }
        int st;
        do {
            st = rnd.nextInt(9);
        } while (st == lastAbs);
        lastAbs = st;
        return WallpaperFactory.make(st, 640, 360);
    }

    private String[] pick(List<String[]> l) {
        ArrayList<String[]> cached = new ArrayList<>();
        for (String[] e : l) {
            if (file(e[1]).exists() && !e[1].equals(last)) cached.add(e);
        }
        if (cached.size() >= 3 && rnd.nextInt(10) < 6) return cached.get(rnd.nextInt(cached.size()));
        String[] e;
        int n = 0;
        do {
            e = l.get(rnd.nextInt(l.size()));
        } while (e[1].equals(last) && l.size() > 1 && ++n < 5);
        return e;
    }

    private File file(String url) {
        return new File(dir, Integer.toHexString(url.hashCode()) + ".jpg");
    }

    // ------------------------------------------------------------------ índice

    private List<String[]> entries(int mode) {
        ArrayList<String[]> out = new ArrayList<>();
        String raw = sp.getString("idx", "");
        if (raw.isEmpty()) return out;
        for (String line : raw.split("\n")) {
            String[] p = line.split("\t");
            if (p.length < 3) continue;
            int t = p[0].length() == 1 ? p[0].charAt(0) - '0' : -1;
            if (t < 1 || t > 4) continue;
            if (mode == MIX || mode == t) out.add(p);
        }
        return out;
    }

    private void ensureIndexAsync() {
        long ts = sp.getLong("idxTs", 0);
        boolean has = !sp.getString("idx", "").isEmpty();
        if (indexing || (has && System.currentTimeMillis() - ts < 7L * 86400000L)) return;
        indexing = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    StringBuilder sb = new StringBuilder();
                    ArrayList<String> seen = new ArrayList<>();
                    for (int t = 1; t <= 4; t++) {
                        for (String k : KW[t]) {
                            try {
                                query(t, k, sb, seen);
                            } catch (Throwable ignored) {
                            }
                        }
                    }
                    if (sb.length() > 0) {
                        sp.edit().putString("idx", sb.toString()).putLong("idxTs", System.currentTimeMillis()).apply();
                    }
                } finally {
                    indexing = false;
                }
            }
        }).start();
    }

    private void query(int topic, String kw, StringBuilder sb, List<String> seen) throws Exception {
        String q = "incategory:\"Featured pictures on Wikimedia Commons\" " + kw + " filetype:bitmap";
        String url = "https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search"
                + "&gsrnamespace=6&gsrlimit=10&gsrsearch=" + URLEncoder.encode(q, "UTF-8")
                + "&prop=imageinfo&iiprop=url%7Csize&iiurlwidth=1920";
        JSONObject o = new JSONObject(new String(get(url), "UTF-8"));
        JSONObject qq = o.optJSONObject("query");
        if (qq == null) return;
        JSONObject pages = qq.optJSONObject("pages");
        if (pages == null) return;
        Iterator<String> it = pages.keys();
        while (it.hasNext()) {
            JSONObject pg = pages.getJSONObject(it.next());
            JSONArray ii = pg.optJSONArray("imageinfo");
            if (ii == null || ii.length() == 0) continue;
            JSONObject info = ii.getJSONObject(0);
            String thumb = info.optString("thumburl", "");
            int w = info.optInt("width"), h = info.optInt("height");
            if (thumb.isEmpty() || h <= 0 || w < 2500 || w / (float) h < 1.45f) continue;
            if (seen.contains(thumb)) continue;
            seen.add(thumb);
            String title = pg.optString("title", "").replace("File:", "").replace('\t', ' ').replace('\n', ' ');
            sb.append(topic).append('\t').append(thumb).append('\t').append(title).append('\n');
        }
    }

    // ------------------------------------------------------------------ descarga y decodificación

    private byte[] get(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setRequestProperty("User-Agent", UA);
        c.setConnectTimeout(12000);
        c.setReadTimeout(25000);
        InputStream in = c.getInputStream();
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        } finally {
            in.close();
            c.disconnect();
        }
    }

    private boolean download(String url, File f) {
        try {
            byte[] data = get(url);
            File tmp = new File(dir, f.getName() + ".tmp");
            FileOutputStream os = new FileOutputStream(tmp);
            os.write(data);
            os.close();
            boolean ok = tmp.renameTo(f);
            trim();
            return ok;
        } catch (Throwable t) {
            return false;
        }
    }

    private void trim() {
        File[] fs = dir.listFiles();
        if (fs == null || fs.length <= 60) return;
        java.util.Arrays.sort(fs, new java.util.Comparator<File>() {
            @Override
            public int compare(File x, File y) {
                return Long.compare(x.lastModified(), y.lastModified());
            }
        });
        for (int i = 0; i < fs.length - 60; i++) fs[i].delete();
    }

    private Bitmap decode(File f) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getPath(), o);
            if (o.outWidth <= 0) {
                f.delete();
                return null;
            }
            int ss = 1;
            while (o.outWidth / (ss * 2) >= 1280 && o.outHeight / (ss * 2) >= 720) ss *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = ss;
            Bitmap src = BitmapFactory.decodeFile(f.getPath(), o2);
            if (src == null) {
                f.delete();
                return null;
            }
            // recorte centrado a 16:9 y escala a 1280x720
            int w = src.getWidth(), h = src.getHeight();
            int cw = w, ch = Math.round(w * 9f / 16f);
            if (ch > h) {
                ch = h;
                cw = Math.round(h * 16f / 9f);
            }
            Bitmap crop = Bitmap.createBitmap(src, (w - cw) / 2, (h - ch) / 2, cw, ch);
            Bitmap out = Bitmap.createScaledBitmap(crop, 1280, 720, true);
            if (crop != out && crop != src) crop.recycle();
            if (src != out) src.recycle();
            f.setLastModified(System.currentTimeMillis());
            return out;
        } catch (Throwable t) {
            return null;
        }
    }

    private Bitmap veil(Bitmap b) {
        Bitmap m = b.isMutable() ? b : b.copy(Bitmap.Config.ARGB_8888, true);
        Canvas c = new Canvas(m);
        Paint p = new Paint();
        int w = m.getWidth(), h = m.getHeight();
        p.setShader(new LinearGradient(0, 0, 0, h, new int[]{0x55000000, 0x22000000, 0x33000000, 0xA0000000},
                new float[]{0f, 0.35f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        return m;
    }
}
