package dev.prisma.tv;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * Fondos con fotos reales (hechas por personas) de animales, paisajes, lugares del mundo y ciudades, de
 * Wikipedia y Wikimedia Commons (solo licencias libres, con crédito). Guardado inteligente: en el dispositivo
 * solo hay como mucho DOS fotos, la que se está viendo y la siguiente (ya descargada para que el cambio sea
 * instantáneo); al pasar a la siguiente se borra la anterior y se baja la nueva siguiente. Si algo falla nunca
 * se devuelve un fondo "inventado": {@link #next(int)} devuelve null y el Inicio se queda con la foto que ya tenía.
 */
final class WallSource {
    static final int MIX = 0, ANIMALS = 1, LAND = 2, WORLD = 3, CITIES = 4;

    private static final String UA = "PrismaTV/2.9 (launcher personal para Fire TV; https://github.com/Miney13FB/PrismaTV)";
    private static final int IDX_VER = 28;
    private static final int PER_TOPIC = 150;
    private static final String API_COMMONS = "https://commons.wikimedia.org/w/api.php?action=query&format=json";
    private static final String API_WIKI = "https://en.wikipedia.org/w/api.php?action=query&format=json";
    private static final String INFO = "&prop=imageinfo&iiprop=url%7Csize%7Cmime%7Cextmetadata"
            + "&iiextmetadatafilter=LicenseShortName%7CArtist%7CCategories&iiurlwidth=1920";
    private static final String CAT_BOTH = "incategory:\"Featured pictures on Wikimedia Commons\"|\"Quality images\"";
    private static final String CAT_FEAT = "incategory:\"Featured pictures on Wikimedia Commons\"";

    private static final int OK = 0, NET = 1, FATAL = 2, RATE = 3;

    /** Error HTTP al hablar con Wikimedia. */
    private static final class HttpErr extends Exception {
        final int code;

        HttpErr(int code) {
            super("HTTP " + code);
            this.code = code;
        }
    }

    private final SharedPreferences sp;
    private final File dir;
    private final File idxFile;
    private final Random rnd = new Random();
    private final Object lock = new Object();
    private final ArrayList<WallIndex.Item> items = new ArrayList<>();
    private final HashSet<String> seen = new HashSet<>();
    private final Set<String> bad = Collections.synchronizedSet(new HashSet<String>());
    private final ArrayList<String> recent = new ArrayList<>();
    private volatile boolean indexing;
    private volatile Runnable ready;

    // guardado inteligente: todo lo de este bloque se lee y escribe dentro de synchronized (keep)
    private final Object keep = new Object();
    private String curUrl = "";         // la foto que se está viendo (su archivo se conserva)
    private int curTopic;
    private String nxtUrl = "";         // la foto siguiente, ya descargada (su archivo se conserva)
    private int nxtTopic;
    private String inflightUrl = "";    // la que se está bajando ahora mismo para ser la siguiente
    private boolean prefetching;
    private volatile boolean started;   // la limpieza inicial ya se hizo (se hace en segundo plano, no al abrir)
    private volatile boolean haveShown; // en esta sesión ya se devolvió alguna foto
    private volatile String credit = "";
    private volatile String error = "";
    private volatile int runs;
    private volatile long nextTry;
    private volatile boolean force;
    private long backoff = 3 * 60000L;
    private int errStreak;
    private int readyMask;

    WallSource(Context c) {
        sp = c.getSharedPreferences("prisma_walls", Context.MODE_PRIVATE);
        dir = new File(c.getFilesDir(), "walls");
        dir.mkdirs();
        idxFile = new File(dir, "index.tsv");
        if (sp.getInt("idxVer", 0) < IDX_VER) {
            // índice y fotos de versiones anteriores: se empieza limpio
            sp.edit().remove("idx").remove("idxTs").remove("bad").remove("cur").remove("curT")
                    .remove("nxt").remove("nxtT").putInt("idxVer", IDX_VER).apply();
            idxFile.delete();
            File[] old = dir.listFiles();
            if (old != null) {
                for (File f : old) f.delete();
            }
        } else {
            items.addAll(WallIndex.parse(readText(idxFile)));
            for (WallIndex.Item i : items) seen.add(i.url);
        }
        curUrl = sp.getString("cur", "");
        curTopic = sp.getInt("curT", 0);
        nxtUrl = sp.getString("nxt", "");
        nxtTopic = sp.getInt("nxtT", 0);
        String b = sp.getString("bad", "");
        if (!b.isEmpty()) {
            for (String s : b.split("\n")) {
                if (!s.isEmpty()) bad.add(s);
            }
        }
    }

    /** Se avisa (desde un hilo de fondo) cuando un tema recibe sus primeras fotos. */
    void setOnReady(Runnable r) {
        ready = r;
    }

    /** Crédito de la última foto devuelta. */
    String credit() {
        return credit;
    }

    /** Último error al buscar o bajar fotos (vacío si todo va bien). */
    String error() {
        return error;
    }

    boolean indexing() {
        return indexing;
    }

    /** Fotos encontradas: [0] = total, [1..4] = animales, paisajes, lugares, ciudades. */
    int[] counts() {
        int[] c = new int[5];
        synchronized (lock) {
            for (WallIndex.Item i : items) {
                c[i.topic]++;
                c[0]++;
            }
        }
        return c;
    }

    /** Fotos guardadas ahora mismo en el dispositivo (con el guardado inteligente, como mucho 2). */
    int stored() {
        int n = 0;
        File[] fs = dir.listFiles();
        if (fs != null) {
            for (File f : fs) {
                if (f.getName().endsWith(".jpg")) n++;
            }
        }
        return n;
    }

    /** Espacio que ocupan esas fotos, en bytes. */
    long storedBytes() {
        long n = 0;
        File[] fs = dir.listFiles();
        if (fs != null) {
            for (File f : fs) {
                if (f.getName().endsWith(".jpg")) n += f.length();
            }
        }
        return n;
    }

    /**
     * Borra todas las fotos descargadas (Ajustes > Fondo > Borrar fotos descargadas). Lo que se ve en pantalla
     * no cambia; la siguiente foto se baja cuando haga falta. Devuelve los bytes liberados.
     */
    long clearDownloads() {
        long freed = storedBytes();
        synchronized (keep) {
            curUrl = "";
            curTopic = 0;
            nxtUrl = "";
            nxtTopic = 0;
            saveState();
        }
        File[] fs = dir.listFiles();
        if (fs != null) {
            for (File f : fs) {
                String n = f.getName();
                if (n.endsWith(".jpg") || (n.endsWith(".tmp") && !n.startsWith("index"))) f.delete();
            }
        }
        return freed;
    }

    private void saveState() {
        sp.edit().putString("cur", curUrl).putInt("curT", curTopic).putString("nxt", nxtUrl).putInt("nxtT", nxtTopic)
                .apply();
    }

    private WallIndex.Item byUrl(String url) {
        if (url == null || url.isEmpty()) return null;
        synchronized (lock) {
            for (WallIndex.Item i : items) {
                if (i.url.equals(url)) return i;
            }
        }
        return null;
    }

    /**
     * Limpieza de la primera vez (en segundo plano): borra todo lo que no sea la foto actual y la siguiente. Al
     * actualizar desde una versión que acumulaba hasta 60 fotos se conserva solo la usada más recientemente.
     */
    private void startup() {
        boolean fresh;
        synchronized (keep) {
            fresh = curUrl.isEmpty() && nxtUrl.isEmpty();
        }
        if (fresh) {
            File[] fs = dir.listFiles();
            File best = null;
            if (fs != null) {
                for (File f : fs) {
                    if (f.getName().endsWith(".jpg") && (best == null || f.lastModified() > best.lastModified())) {
                        best = f;
                    }
                }
            }
            if (best != null) {
                String name = best.getName();
                WallIndex.Item hit = null;
                synchronized (lock) {
                    for (WallIndex.Item i : items) {
                        if (file(i.url).getName().equals(name)) {
                            hit = i;
                            break;
                        }
                    }
                }
                if (hit != null) {
                    synchronized (keep) {
                        curUrl = hit.url;
                        curTopic = hit.topic;
                        saveState();
                    }
                }
            }
        }
        sweep();
    }

    /** Borra todas las fotos guardadas salvo la actual, la siguiente y la que se está bajando (y restos viejos). */
    private void sweep() {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        String a, b, c;
        synchronized (keep) {
            a = curUrl.isEmpty() ? "" : file(curUrl).getName();
            b = nxtUrl.isEmpty() ? "" : file(nxtUrl).getName();
            c = inflightUrl.isEmpty() ? "" : file(inflightUrl).getName();
        }
        long now = System.currentTimeMillis();
        for (File f : fs) {
            String n = f.getName();
            if (n.startsWith("index")) continue;
            if (n.endsWith(".tmp")) {
                // una descarga a medias puede ser de ahora mismo: solo se borran los restos de hace rato
                if (now - f.lastModified() > 120000L) f.delete();
            } else if (n.endsWith(".jpg") && !n.equals(a) && !n.equals(b) && !n.equals(c)) {
                f.delete();
            }
        }
    }

    /** Vuelve a buscar fotos ahora (botón "Actualizar fotos"). */
    void refresh() {
        error = "";
        force = true;
        nextTry = 0;
        ensureIndexAsync();
    }

    /** Fondo liso oscuro solo para tener algo con lo que desenfocar el cristal antes de la primera foto. */
    static Bitmap placeholder() {
        Bitmap b = Bitmap.createBitmap(160, 90, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint();
        p.setShader(new LinearGradient(0, 0, 0, 90, 0xFF16202F, 0xFF080B12, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, 160, 90, p);
        return b;
    }

    // ------------------------------------------------------------------ elegir una foto

    /**
     * Se llama en un hilo en segundo plano. Devuelve la foto que toca ahora (de 16:9, lista para usar) o null si
     * todavía no hay ninguna disponible para ese tema (nunca un fondo falso).
     *
     * Guardado inteligente: en el dispositivo solo están la foto que se ve y la siguiente. Al pasar a la siguiente
     * se borra la anterior y se empieza a bajar la nueva "siguiente".
     */
    Bitmap next(int mode) {
        if (!started) {
            started = true;
            startup();
        }
        ensureIndexAsync();
        int topic = mode < MIX || mode > CITIES ? MIX : mode;
        // al abrir Prisma se vuelve a ver la foto de la última vez (sin bajar nada y sin internet)
        if (!haveShown) {
            Bitmap first = reuseCurrent(topic);
            if (first != null) {
                haveShown = true;
                queueAhead(topic);
                return veil(first);
            }
        }
        ArrayList<WallIndex.Item> pool = poolFor(topic);
        if (pool.isEmpty() && topic != MIX && !indexing && runs > 0) {
            // ese tema no ha dado fotos tras buscar: se usa la mezcla para que nunca falte fondo
            topic = MIX;
            pool = poolFor(MIX);
        }
        if (pool.isEmpty()) return null;
        // 1) la siguiente, que ya estaba descargada: el cambio es inmediato y funciona sin internet
        WallIndex.Item e = takeQueued(topic);
        Bitmap b = null;
        if (e != null) {
            b = decode(file(e.url));
            if (b == null) {
                markBad(e.url);
                e = null;
            }
        }
        // 2) si no la había (primera vez, cambio de categoría...), se baja una ahora
        for (int tries = 0; b == null && tries < 3; tries++) {
            WallIndex.Item c = pick(pool);
            if (c == null) break;
            File f = file(c.url);
            if (!f.exists()) {
                int r = download(c.url, f);
                if (r == NET || r == RATE) break;
                if (r != OK) continue;
            }
            Bitmap d = decode(f);
            if (d == null) {
                markBad(c.url);
                continue;
            }
            e = c;
            b = d;
        }
        if (b == null || e == null) return null;
        commit(e);
        queueAhead(topic);
        return veil(b);
    }

    /** La foto que se estaba viendo la última vez, si sigue guardada y vale para este tema. */
    private Bitmap reuseCurrent(int topic) {
        String u;
        int t;
        synchronized (keep) {
            u = curUrl;
            t = curTopic;
        }
        if (u.isEmpty() || bad.contains(u) || (topic != MIX && t != topic)) return null;
        File f = file(u);
        if (!f.exists()) return null;
        Bitmap b = decode(f);
        if (b == null) {
            markBad(u);
            return null;
        }
        WallIndex.Item e = byUrl(u);
        credit = e == null ? "" : e.credit;
        remember(u);
        return b;
    }

    /** La foto "siguiente" ya descargada, si sirve para este tema; si no sirve se borra para no acumular. */
    private WallIndex.Item takeQueued(int topic) {
        String u;
        synchronized (keep) {
            u = nxtUrl;
            nxtUrl = "";
            nxtTopic = 0;
            saveState();
        }
        if (u.isEmpty()) return null;
        WallIndex.Item e = byUrl(u);
        File f = file(u);
        if (e != null && f.exists() && !bad.contains(u) && (topic == MIX || e.topic == topic)) return e;
        boolean isCur;
        synchronized (keep) {
            isCur = u.equals(curUrl);
        }
        if (!isCur) f.delete();
        return null;
    }

    /** Esta pasa a ser la foto que se ve: la anterior se borra del dispositivo (en pantalla no cambia nada). */
    private void commit(WallIndex.Item e) {
        String old;
        boolean queued;
        synchronized (keep) {
            old = curUrl;
            curUrl = e.url;
            curTopic = e.topic;
            queued = old.equals(nxtUrl);
            saveState();
        }
        remember(e.url);
        credit = e.credit;
        error = "";
        haveShown = true;
        if (!old.isEmpty() && !old.equals(e.url) && !queued) file(old).delete();
        sweep();
    }

    /** Empieza a bajar, en segundo plano, la foto que se verá después de la actual. */
    private void queueAhead(final int topic) {
        synchronized (keep) {
            if (prefetching) return;
            boolean have = !nxtUrl.isEmpty() && (topic == MIX || nxtTopic == topic) && file(nxtUrl).exists();
            if (have) return;
            prefetching = true;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    for (int k = 0; k < 3; k++) {
                        WallIndex.Item e = pick(poolFor(topic));
                        if (e == null) break;
                        File f = file(e.url);
                        synchronized (keep) {
                            inflightUrl = e.url;
                        }
                        int r = f.exists() ? OK : download(e.url, f);
                        if (r == OK) {
                            synchronized (keep) {
                                nxtUrl = e.url;
                                nxtTopic = e.topic;
                                saveState();
                            }
                            break;
                        }
                        if (r == NET || r == RATE) break;
                    }
                } catch (Throwable ignored) {
                } finally {
                    synchronized (keep) {
                        inflightUrl = "";
                        prefetching = false;
                    }
                }
            }
        }, "prisma-next").start();
    }

    private void remember(String url) {
        synchronized (recent) {
            recent.remove(url);
            recent.add(url);
            while (recent.size() > 8) recent.remove(0);
        }
    }

    /** Fotos de un tema (o de un tema al azar si es mezcla), sin las que ya fallaron. */
    private ArrayList<WallIndex.Item> poolFor(int mode) {
        ArrayList<WallIndex.Item> out = new ArrayList<>();
        synchronized (lock) {
            int t = mode;
            if (mode == MIX) {
                int[] c = new int[5];
                for (WallIndex.Item i : items) c[i.topic]++;
                ArrayList<Integer> have = new ArrayList<>();
                for (int k = 1; k <= 4; k++) {
                    if (c[k] > 0) have.add(k);
                }
                if (have.isEmpty()) return out;
                t = have.get(rnd.nextInt(have.size()));
            }
            for (WallIndex.Item i : items) {
                if (i.topic == t && !bad.contains(i.url)) out.add(i);
            }
        }
        return out;
    }

    /** Una foto al azar del tema, sin la actual, la siguiente, la que se está bajando ni las vistas hace poco. */
    private WallIndex.Item pick(List<WallIndex.Item> pool) {
        if (pool.isEmpty()) return null;
        String c, n, i;
        synchronized (keep) {
            c = curUrl;
            n = nxtUrl;
            i = inflightUrl;
        }
        ArrayList<WallIndex.Item> fresh = new ArrayList<>();
        ArrayList<WallIndex.Item> other = new ArrayList<>();
        synchronized (recent) {
            for (WallIndex.Item e : pool) {
                if (e.url.equals(c) || e.url.equals(n) || e.url.equals(i)) continue;
                if (recent.contains(e.url)) other.add(e);
                else fresh.add(e);
            }
        }
        List<WallIndex.Item> src = !fresh.isEmpty() ? fresh : (!other.isEmpty() ? other : pool);
        return src.get(rnd.nextInt(src.size()));
    }

    private File file(String url) {
        return new File(dir, Integer.toHexString(url.hashCode()) + ".jpg");
    }

    private void markBad(String url) {
        bad.add(url);
        file(url).delete();
        synchronized (keep) {
            if (url.equals(curUrl)) {
                curUrl = "";
                curTopic = 0;
            }
            if (url.equals(nxtUrl)) {
                nxtUrl = "";
                nxtTopic = 0;
            }
            saveState();
        }
        StringBuilder sb = new StringBuilder();
        synchronized (bad) {
            int skip = Math.max(0, bad.size() - 400);
            for (String s : bad) {
                if (skip-- > 0) continue;
                if (sb.length() > 0) sb.append('\n');
                sb.append(s);
            }
        }
        sp.edit().putString("bad", sb.toString()).apply();
    }

    // ------------------------------------------------------------------ crear el índice de fotos

    private void ensureIndexAsync() {
        if (indexing) return;
        long now = System.currentTimeMillis();
        if (now < nextTry) return;
        boolean weak = false;
        int[] c = counts();
        for (int t = 1; t <= 4; t++) {
            if (c[t] < 12) weak = true;
        }
        if (!weak && !force) return;
        indexing = true;
        force = false;
        new Thread(new Runnable() {
            @Override
            public void run() {
                boolean done = false;
                try {
                    done = buildIndex();
                } catch (Throwable t) {
                    error = String.valueOf(t.getMessage());
                } finally {
                    long end = System.currentTimeMillis();
                    if (done) {
                        backoff = 3 * 60000L;
                        sp.edit().putLong("idxTs", end).apply();
                        int[] cc = counts();
                        boolean weakNow = false;
                        for (int t = 1; t <= 4; t++) {
                            if (cc[t] < 12) weakNow = true;
                        }
                        nextTry = end + (weakNow ? 12L * 3600000L : 7L * 86400000L);
                    } else {
                        nextTry = end + backoff;
                        backoff = Math.min(backoff * 2, 30 * 60000L);
                    }
                    runs++;
                    indexing = false;
                }
            }
        }, "prisma-photos").start();
    }

    private boolean aborted() {
        return errStreak >= 6;
    }

    private void fail(Throwable e) {
        if (e instanceof HttpErr) {
            int code = ((HttpErr) e).code;
            error = "HTTP " + code;
            errStreak += (code == 429 || code == 403 || code >= 500) ? 3 : 1;
        } else if (e instanceof java.io.IOException) {
            error = "sin conexión";
            errStreak += 2;
        } else {
            error = String.valueOf(e.getMessage());
            errStreak++;
        }
    }

    private void okStep() {
        errStreak = 0;
        error = "";
    }

    private void pause() {
        try {
            Thread.sleep(300);
        } catch (InterruptedException ignored) {
        }
    }

    private boolean buildIndex() {
        errStreak = 0;
        // A) la foto principal de artículos de Wikipedia: pocas peticiones y casi siempre una buena foto
        for (int t = 1; t <= 4; t++) {
            String[] titles = WallData.TITLES[t];
            for (int i = 0; i < titles.length; i += 40) {
                if (aborted()) return false;
                try {
                    addLead(t, titles, i, Math.min(titles.length, i + 40));
                    okStep();
                } catch (Throwable e) {
                    fail(e);
                }
                pause();
            }
        }
        // B) búsquedas en Commons de fotos destacadas y de calidad (una de cada tema por vuelta)
        int maxLen = 0;
        for (int t = 1; t <= 4; t++) maxLen = Math.max(maxLen, WallData.KW[t].length);
        for (int i = 0; i < maxLen; i++) {
            for (int t = 1; t <= 4; t++) {
                if (i >= WallData.KW[t].length || count(t) >= PER_TOPIC) continue;
                if (aborted()) return false;
                try {
                    search(t, WallData.KW[t][i]);
                    okStep();
                } catch (Throwable e) {
                    fail(e);
                }
                pause();
            }
        }
        // C) si algún tema (por ejemplo ciudades) tiene pocas fotos, se prueba con más palabras
        for (int t = 1; t <= 4; t++) {
            for (int i = 0; i < WallData.EXTRA[t].length && count(t) < 40; i++) {
                if (aborted()) return false;
                try {
                    search(t, WallData.EXTRA[t][i]);
                    okStep();
                } catch (Throwable e) {
                    fail(e);
                }
                pause();
            }
        }
        return true;
    }

    private int count(int topic) {
        int n = 0;
        synchronized (lock) {
            for (WallIndex.Item i : items) {
                if (i.topic == topic) n++;
            }
        }
        return n;
    }

    private static String enc(String s) throws Exception {
        return URLEncoder.encode(s, "UTF-8");
    }

    /** Foto principal de cada artículo de Wikipedia → datos y licencia en Commons. */
    private void addLead(int topic, String[] titles, int from, int to) throws Exception {
        StringBuilder sb = new StringBuilder();
        for (int j = from; j < to; j++) {
            if (sb.length() > 0) sb.append('|');
            sb.append(titles[j]);
        }
        String url = API_WIKI + "&prop=pageimages&piprop=name&redirects=1&titles=" + enc(sb.toString());
        List<String> files = WallIndex.leadFiles(text(get(url)), topic);
        for (int k = 0; k < files.size(); k += 20) {
            List<String> part = files.subList(k, Math.min(files.size(), k + 20));
            StringBuilder fb = new StringBuilder();
            for (String f : part) {
                if (fb.length() > 0) fb.append('|');
                fb.append(f);
            }
            String u2 = API_COMMONS + "&redirects=1" + INFO + "&titles=" + enc(fb.toString());
            add(WallIndex.photos(text(get(u2)), topic, 1500, seen, bad));
            pause();
        }
    }

    private void search(int topic, String kw) throws Exception {
        int n = runQuery(topic, kw, CAT_BOTH);
        if (n <= 1) n += runQuery(topic, kw, CAT_FEAT);
        // última opción: búsqueda normal (se siguen comprobando licencia, tamaño y que sea una foto)
        if (n <= 1) runQuery(topic, kw, "");
    }

    private int runQuery(int topic, String kw, String cat) throws Exception {
        String q = (cat.isEmpty() ? "" : cat + " ") + kw + " filetype:bitmap";
        String url = API_COMMONS + "&generator=search&gsrnamespace=6&gsrlimit=25&gsrsearch=" + enc(q) + INFO;
        List<WallIndex.Item> l = WallIndex.photos(text(get(url)), topic, cat.isEmpty() ? 2400 : 1500, seen, bad);
        add(l);
        return l.size();
    }

    private void add(List<WallIndex.Item> l) {
        if (l.isEmpty()) return;
        synchronized (lock) {
            for (WallIndex.Item i : l) {
                int n = 0;
                for (WallIndex.Item o : items) {
                    if (o.topic == i.topic) n++;
                }
                if (n < PER_TOPIC) items.add(i);
            }
        }
        save();
        int[] c = counts();
        int mask = 0;
        for (int t = 1; t <= 4; t++) {
            if (c[t] >= 3) mask |= 1 << t;
        }
        if (mask != readyMask) {
            readyMask = mask;
            Runnable r = ready;
            if (r != null) r.run();
        }
    }

    private void save() {
        String text;
        synchronized (lock) {
            text = WallIndex.serialize(items);
        }
        try {
            File tmp = new File(dir, "index.tmp");
            FileOutputStream os = new FileOutputStream(tmp);
            os.write(text.getBytes("UTF-8"));
            os.close();
            if (!tmp.renameTo(idxFile)) {
                idxFile.delete();
                tmp.renameTo(idxFile);
            }
        } catch (Throwable ignored) {
        }
    }

    private static String readText(File f) {
        try {
            FileInputStream in = new FileInputStream(f);
            try {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                return new String(bo.toByteArray(), "UTF-8");
            } finally {
                in.close();
            }
        } catch (Throwable t) {
            return "";
        }
    }

    private static String text(byte[] b) throws Exception {
        return new String(b, "UTF-8");
    }

    // ------------------------------------------------------------------ descarga y decodificación

    private byte[] get(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setRequestProperty("User-Agent", UA);
        c.setConnectTimeout(12000);
        c.setReadTimeout(25000);
        try {
            int code = c.getResponseCode();
            if (code != 200) throw new HttpErr(code);
            InputStream in = c.getInputStream();
            try {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) {
                    bo.write(buf, 0, n);
                    if (bo.size() > 14 * 1024 * 1024) throw new Exception("demasiado grande");
                }
                return bo.toByteArray();
            } finally {
                in.close();
            }
        } finally {
            c.disconnect();
        }
    }

    private int download(String url, File f) {
        // nombre temporal propio de cada descarga: dos descargas a la vez nunca se pisan
        File tmp = new File(dir, f.getName() + "." + Long.toHexString(System.nanoTime()) + ".tmp");
        try {
            byte[] data = get(url);
            boolean jpeg = data.length > 20000 && (data[0] & 0xFF) == 0xFF && (data[1] & 0xFF) == 0xD8;
            if (!jpeg) {
                markBad(url);
                return FATAL;
            }
            try {
                FileOutputStream os = new FileOutputStream(tmp);
                try {
                    os.write(data);
                } finally {
                    os.close();
                }
            } catch (java.io.IOException io) {
                error = "sin espacio libre";
                return NET;
            }
            boolean ok = tmp.renameTo(f);
            return ok ? OK : FATAL;
        } catch (HttpErr e) {
            error = "HTTP " + e.code;
            // límite de peticiones o bloqueo temporal: no es culpa de esta foto, se deja de intentar un rato
            if (e.code == 429 || e.code == 503 || e.code == 403) return RATE;
            // la foto no existe o no se puede generar: se descarta para siempre
            if (e.code == 404 || e.code == 410 || e.code == 400 || e.code == 415 || e.code == 422) {
                markBad(url);
                return FATAL;
            }
            return NET;
        } catch (Throwable t) {
            error = "sin conexión";
            return NET;
        } finally {
            if (tmp.exists()) tmp.delete();
        }
    }

    private Bitmap decode(File f) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getPath(), o);
            if (o.outWidth <= 0) {
                f.delete();
                return null;
            }
            int ss = 1;
            while (o.outWidth / (ss * 2) >= 1280 && o.outHeight / (ss * 2) >= 720) ss *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = ss;
            Bitmap src = BitmapFactory.decodeFile(f.getPath(), o2);
            if (src == null) {
                f.delete();
                return null;
            }
            // recorte centrado a 16:9 y escala a 1280x720
            int w = src.getWidth(), h = src.getHeight();
            int cw = w, ch = Math.round(w * 9f / 16f);
            if (ch > h) {
                ch = h;
                cw = Math.round(h * 16f / 9f);
            }
            Bitmap crop = Bitmap.createBitmap(src, (w - cw) / 2, (h - ch) / 2, cw, ch);
            Bitmap out = Bitmap.createScaledBitmap(crop, 1280, 720, true);
            if (crop != out && crop != src) crop.recycle();
            if (src != out) src.recycle();
            f.setLastModified(System.currentTimeMillis());
            return out;
        } catch (Throwable t) {
            return null;
        }
    }

    private Bitmap veil(Bitmap b) {
        Bitmap m = b.isMutable() ? b : b.copy(Bitmap.Config.ARGB_8888, true);
        Canvas c = new Canvas(m);
        Paint p = new Paint();
        int w = m.getWidth(), h = m.getHeight();
        p.setShader(new LinearGradient(0, 0, 0, h, new int[]{0x55000000, 0x22000000, 0x33000000, 0xA0000000},
                new float[]{0f, 0.35f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        return m;
    }
}
