package dev.prisma.tv;

import android.content.Context;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Tarjeta de app estilo tvOS: banner redondeado, zoom con rebote, inclinación hacia
 * donde te mueves, brillo y borde blanco al enfocar, y un destello de luz que la cruza una vez.
 */
final class Cell extends FrameLayout implements FocusFx {
    final ImageView img;
    final View rim;
    private final View band;      // banda de luz del destello
    private final int bandW, tileW;
    TextView label;
    String pkg;
    String capName;
    String capSub;

    private final float zLift;
    private final Runnable settle = new Runnable() {
        @Override
        public void run() {
            if (isFocused()) animate().rotationY(0f).setDuration(300).start();
        }
    };

    Cell(Context c, final float u, int cellW, int cellH, int tileWidth, int tileH, int topPad, boolean withLabel) {
        super(c);
        setFocusable(true);
        setClickable(true);
        setLongClickable(true);
        setSoundEffectsEnabled(false);   // el sonido lo pone Lumen (si no, sonaría también el «clic» del sistema)
        setClipChildren(false);
        setClipToPadding(false);
        setCameraDistance(12000f * u);
        zLift = 14f * u;

        final float radius = 14f * u;
        tileW = tileWidth;
        final ViewOutlineProvider round = new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radius);
                o.setAlpha(1f);
            }
        };

        img = new ImageView(c);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        img.setBackgroundColor(0xFF1B2233);
        img.setOutlineProvider(round);
        img.setClipToOutline(true);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(tileWidth, tileH, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        ip.topMargin = topPad;
        addView(img, ip);

        // destello: una banda de luz inclinada que cruza la tarjeta al enfocarla (solo mueve una vista, no dibuja nada a mano)
        FrameLayout shine = new FrameLayout(c);
        shine.setOutlineProvider(round);
        shine.setClipToOutline(true);
        FrameLayout.LayoutParams shp = new FrameLayout.LayoutParams(tileWidth, tileH, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        shp.topMargin = topPad;
        addView(shine, shp);
        band = new View(c);
        band.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0x00FFFFFF, 0x33FFFFFF, 0x00FFFFFF}));
        bandW = Math.round(tileWidth * 0.42f);
        int bandH = Math.round(tileH * 1.8f);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(bandW, bandH);
        bp.topMargin = -(bandH - tileH) / 2;
        shine.addView(band, bp);
        band.setRotation(18f);
        band.setAlpha(0f);

        rim = new View(c);
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0x4DFFFFFF, 0x00FFFFFF});
        gd.setCornerRadius(radius);
        gd.setStroke(Math.max(2, Math.round(3f * u)), 0xF2FFFFFF);
        rim.setBackground(gd);
        rim.setAlpha(0f);
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(tileWidth, tileH, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        rp.topMargin = topPad;
        addView(rim, rp);

        if (withLabel) {
            label = new TextView(c);
            label.setTextSize(TypedValue.COMPLEX_UNIT_PX, 16f * u);
            label.setTextColor(0xE6FFFFFF);
            label.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            label.setSingleLine(true);
            label.setEllipsize(android.text.TextUtils.TruncateAt.END);
            label.setGravity(Gravity.CENTER_HORIZONTAL);
            label.setIncludeFontPadding(false);
            label.setShadowLayer(4f * u, 0f, 1f * u, 0x99000000);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(tileWidth, LayoutParams.WRAP_CONTENT,
                    Gravity.TOP | Gravity.CENTER_HORIZONTAL);
            lp.topMargin = topPad + tileH + Math.round(9f * u);
            addView(label, lp);
        }
    }

    @Override
    public void setPressed(boolean pressed) {
        boolean was = isPressed();
        super.setPressed(pressed);
        if (pressed != was && isFocused() && isShown()) Press.tap(this, pressed, 1.10f, 1.04f);
    }

    @Override
    public void fx(boolean focused, int dir, boolean animate) {
        float s = focused ? 1.10f : 1f;
        // el foco puede llegar mientras la tarjeta aún hace su animación de entrada (primera app del dock):
        // al cancelarla quedaría transparente. Se deja siempre visible.
        if (getAlpha() < 1f) setAlpha(1f);
        if (getTranslationY() != 0f) setTranslationY(0f);
        if (!animate) {
            setScaleX(s);
            setScaleY(s);
            setTranslationZ(focused ? zLift : 0f);
            setRotationY(0f);
            rim.setAlpha(focused ? 1f : 0f);
            noShine();
            return;
        }
        animate().cancel();
        animate().scaleX(s).scaleY(s)
                .translationZ(focused ? zLift : 0f)
                .rotationY(focused ? dir * 5f : 0f)
                .setDuration(focused ? 300 : 200)
                .setInterpolator(focused ? new OvershootInterpolator(1.15f) : new DecelerateInterpolator(1.4f))
                .withEndAction(settle)
                .start();
        rim.animate().cancel();
        rim.animate().alpha(focused ? 1f : 0f).setDuration(190).start();
        if (focused) sweep();
        else noShine();
    }

    /** El destello cruza la tarjeta de izquierda a derecha una sola vez. */
    private void sweep() {
        band.animate().cancel();
        band.setTranslationX(-bandW);
        band.setAlpha(1f);
        band.animate().translationX(tileW).setStartDelay(70).setDuration(600)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .withEndAction(hideBand).start();
    }

    private void noShine() {
        band.animate().cancel();
        band.setAlpha(0f);
    }

    private final Runnable hideBand = new Runnable() {
        @Override
        public void run() {
            band.setAlpha(0f);
        }
    };
}
