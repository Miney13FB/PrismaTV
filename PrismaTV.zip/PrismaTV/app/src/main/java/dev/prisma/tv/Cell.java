package dev.prisma.tv;

import android.content.Context;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Tarjeta de app estilo tvOS: banner redondeado, zoom con rebote, inclinación hacia
 * donde te mueves, brillo y borde blanco al enfocar.
 */
final class Cell extends FrameLayout implements FocusFx {
    final ImageView img;
    final View rim;
    TextView label;
    String pkg;
    String capName;
    String capSub;

    private final float zLift;
    private final Runnable settle = new Runnable() {
        @Override
        public void run() {
            if (isFocused()) animate().rotationY(0f).setDuration(300).start();
        }
    };

    Cell(Context c, final float u, int cellW, int cellH, int tileW, int tileH, int topPad, boolean withLabel) {
        super(c);
        setFocusable(true);
        setClickable(true);
        setLongClickable(true);
        setClipChildren(false);
        setClipToPadding(false);
        setCameraDistance(12000f * u);
        zLift = 14f * u;

        final float radius = 14f * u;

        img = new ImageView(c);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        img.setBackgroundColor(0xFF1B2233);
        img.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radius);
                o.setAlpha(1f);
            }
        });
        img.setClipToOutline(true);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(tileW, tileH, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        ip.topMargin = topPad;
        addView(img, ip);

        rim = new View(c);
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0x4DFFFFFF, 0x00FFFFFF});
        gd.setCornerRadius(radius);
        gd.setStroke(Math.max(2, Math.round(3f * u)), 0xF2FFFFFF);
        rim.setBackground(gd);
        rim.setAlpha(0f);
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(tileW, tileH, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        rp.topMargin = topPad;
        addView(rim, rp);

        if (withLabel) {
            label = new TextView(c);
            label.setTextSize(TypedValue.COMPLEX_UNIT_PX, 16f * u);
            label.setTextColor(0xE6FFFFFF);
            label.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            label.setSingleLine(true);
            label.setEllipsize(android.text.TextUtils.TruncateAt.END);
            label.setGravity(Gravity.CENTER_HORIZONTAL);
            label.setIncludeFontPadding(false);
            label.setShadowLayer(4f * u, 0f, 1f * u, 0x99000000);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(tileW, LayoutParams.WRAP_CONTENT,
                    Gravity.TOP | Gravity.CENTER_HORIZONTAL);
            lp.topMargin = topPad + tileH + Math.round(9f * u);
            addView(label, lp);
        }
    }

    @Override
    public void fx(boolean focused, int dir, boolean animate) {
        float s = focused ? 1.10f : 1f;
        if (!animate) {
            setScaleX(s);
            setScaleY(s);
            setTranslationZ(focused ? zLift : 0f);
            setRotationY(0f);
            rim.setAlpha(focused ? 1f : 0f);
            return;
        }
        animate().cancel();
        animate().scaleX(s).scaleY(s)
                .translationZ(focused ? zLift : 0f)
                .rotationY(focused ? dir * 5f : 0f)
                .setDuration(focused ? 260 : 180)
                .setInterpolator(focused ? new OvershootInterpolator(1.6f) : new DecelerateInterpolator())
                .withEndAction(settle)
                .start();
        rim.animate().cancel();
        rim.animate().alpha(focused ? 1f : 0f).setDuration(170).start();
    }
}
