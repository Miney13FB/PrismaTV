package dev.prisma.tv;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.SystemClock;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashSet;
import java.util.Random;

/**
 * Sonidos de interfaz suaves y modernos, sintetizados por código (nada que descargar ni que ocupe espacio de verdad).
 *
 * Cada sonido es una pequeña «gota» o campanilla de cristal: seno con ataque suave, caída rápida, un deslizamiento de
 * tono muy corto y, en los más largos, un eco breve. Se escriben una sola vez como WAV en la caché y se reproducen con
 * {@link SoundPool}, que responde casi al instante (así el sonido sale a la vez que empieza la animación) y permite
 * variar el tono sin repetir siempre el mismo.
 *
 * Todos suenan bajo a propósito: el que más se oye, el de moverse, es el más corto y el más suave.
 */
final class Sfx {
    static final int MOVE = 0;      // mover el foco
    static final int SELECT = 1;    // pulsar OK
    static final int BACK = 2;      // volver / cerrar
    static final int OPEN = 3;      // abrir un panel o una app
    static final int UNLOCK = 4;    // salir de la pantalla de bloqueo / terminar la bienvenida
    static final int POP = 5;       // aparece un menú pequeño
    private static final int ON = 6;
    private static final int OFF = 7;
    private static final int N = 8;

    private static final int SR = 22050;
    /** Sube este número si se cambia el diseño de algún sonido: se vuelven a generar los archivos de la caché. */
    private static final int VERSION = 31;
    /** Volumen de cada sonido (0..1) sobre el volumen del sistema. */
    private static final float[] VOL = {0.90f, 1f, 0.95f, 1f, 1f, 1f, 1f, 1f};
    /** Tres tonos para el sonido de moverse (±1 semitono): así no suena siempre exactamente igual. */
    private static final float[] MOVE_RATES = {0.944f, 1f, 1.059f};

    boolean enabled = true;

    private SoundPool pool;
    private final Object lock = new Object();
    private final int[] ids = new int[N];
    private final HashSet<Integer> loaded = new HashSet<>();
    private final Random rnd = new Random();
    private long lastMove;
    private int lastVariant = 1;

    Sfx(final Context ctx) {
        final File dir = ctx.getCacheDir();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    start(dir);
                } catch (Throwable ignored) {
                    // sin sonido: la app funciona igual
                }
            }
        }, "lumen-sfx").start();
    }

    private void start(File dir) throws Exception {
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        SoundPool sp = new SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build();
        sp.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
            @Override
            public void onLoadComplete(SoundPool p, int sampleId, int status) {
                if (status != 0) return;
                synchronized (lock) {
                    loaded.add(sampleId);
                }
            }
        });
        // archivos de versiones anteriores del diseño de sonidos
        File[] old = dir.listFiles();
        if (old != null) {
            for (File f : old) {
                String n = f.getName();
                if (n.startsWith("sfx") && n.endsWith(".wav") && !n.startsWith("sfx" + VERSION + "_")) f.delete();
            }
        }
        synchronized (lock) {
            pool = sp;
        }
        for (int i = 0; i < N; i++) {
            File f = new File(dir, "sfx" + VERSION + "_" + i + ".wav");
            if (!f.exists() || f.length() < 100) write(f, build(i));
            int id = sp.load(f.getAbsolutePath(), 1);
            synchronized (lock) {
                ids[i] = id;
            }
        }
    }

    // ------------------------------------------------------------------ reproducir

    void play(int which) {
        if (!enabled) return;
        float v = VOL[which];
        float rate = 1f;
        if (which == MOVE) {
            long now = SystemClock.uptimeMillis();
            long dt = now - lastMove;
            if (dt < 70) return;
            lastMove = now;
            if (dt < 170) v *= 0.72f;   // al recorrer una lista rápido, aún más suave
            lastVariant = (lastVariant + 1 + rnd.nextInt(2)) % MOVE_RATES.length;   // nunca el mismo tono dos veces seguidas
            rate = MOVE_RATES[lastVariant];
        }
        go(which, v, rate);
    }

    /** Interruptor: sube al encenderlo, baja al apagarlo. */
    void toggle(boolean on) {
        play(on ? ON : OFF);
    }

    private void go(int which, float vol, float rate) {
        try {
            SoundPool sp;
            int id;
            synchronized (lock) {
                sp = pool;
                id = ids[which];
                if (sp == null || id == 0 || !loaded.contains(id)) return;
            }
            sp.play(id, vol, vol, 1, 0, rate);
        } catch (Throwable ignored) {
        }
    }

    void release() {
        SoundPool sp;
        synchronized (lock) {
            sp = pool;
            pool = null;
            loaded.clear();
        }
        try {
            if (sp != null) sp.release();
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ diseño de los sonidos

    private static short[] build(int which) {
        float[] b;
        float peak;
        switch (which) {
            case MOVE: {
                // gotita seca: un seno que baja un poco de tono y un «tic» casi imperceptible al principio
                b = new float[(int) (SR * 0.07)];
                tone(b, 1320, 980, 0.020, 0, 0.050, 1.0, 0.0015, 0.010, 0.10, 0);
                click(b, 0, 0.0012, 0.30);
                peak = 0.115f;
                break;
            }
            case SELECT: {
                // toque de cristal: una quinta (la – mi) con un golpecito grave que le da cuerpo
                b = new float[(int) (SR * 0.34)];
                tone(b, 880, 880, 0, 0, 0.22, 1.0, 0.002, 0.075, 0.16, 0.04);
                tone(b, 1318.5, 1318.5, 0, 0.028, 0.24, 0.60, 0.002, 0.085, 0.10, 0);
                tone(b, 196, 165, 0.05, 0, 0.09, 0.50, 0.003, 0.030, 0, 0);
                echo(b, 0.041, 0.16, 0.083, 0.07);
                peak = 0.25f;
                break;
            }
            case BACK: {
                // la contraria: baja de tono y es un poco más corta y más suave
                b = new float[(int) (SR * 0.28)];
                tone(b, 784, 587.3, 0.090, 0, 0.18, 1.0, 0.002, 0.065, 0.14, 0.03);
                tone(b, 165, 131, 0.05, 0, 0.08, 0.45, 0.003, 0.028, 0, 0);
                echo(b, 0.041, 0.12, 0.083, 0.05);
                peak = 0.19f;
                break;
            }
            case OPEN: {
                // «whoosh» corto que sube y tres campanillas (mi – si – mi) que se apagan despacio
                b = new float[(int) (SR * 0.74)];
                sweep(b, 0, 0.19, 480, 3000, 0.55);
                tone(b, 659.3, 659.3, 0, 0.070, 0.42, 0.80, 0.003, 0.130, 0.12, 0.04);
                tone(b, 987.8, 987.8, 0, 0.130, 0.46, 0.65, 0.003, 0.150, 0.10, 0.03);
                tone(b, 1318.5, 1318.5, 0, 0.190, 0.42, 0.40, 0.003, 0.160, 0.08, 0);
                echo(b, 0.045, 0.22, 0.090, 0.12);
                peak = 0.30f;
                break;
            }
            case UNLOCK: {
                // arpegio ascendente (do – mi – sol – do) con un destello al final
                b = new float[(int) (SR * 1.0)];
                tone(b, 523.3, 523.3, 0, 0, 0.55, 0.80, 0.004, 0.200, 0.14, 0.04);
                tone(b, 659.3, 659.3, 0, 0.070, 0.55, 0.72, 0.004, 0.210, 0.12, 0.03);
                tone(b, 784.0, 784.0, 0, 0.140, 0.55, 0.64, 0.004, 0.220, 0.10, 0.03);
                tone(b, 1046.5, 1046.5, 0, 0.210, 0.55, 0.54, 0.004, 0.230, 0.08, 0.02);
                tone(b, 1568.0, 1568.0, 0, 0.300, 0.40, 0.22, 0.004, 0.150, 0.05, 0);
                echo(b, 0.050, 0.24, 0.100, 0.13);
                peak = 0.28f;
                break;
            }
            case POP: {
                // aparece un menú: un «bloop» que sube de tono
                b = new float[(int) (SR * 0.26)];
                tone(b, 520, 880, 0.045, 0, 0.17, 1.0, 0.003, 0.055, 0.10, 0);
                tone(b, 1318.5, 1318.5, 0, 0.020, 0.14, 0.32, 0.002, 0.040, 0, 0);
                echo(b, 0.040, 0.10, 0.080, 0.04);
                peak = 0.22f;
                break;
            }
            case ON: {
                b = new float[(int) (SR * 0.17)];
                tone(b, 1046.5, 1046.5, 0, 0, 0.09, 0.75, 0.002, 0.030, 0.08, 0);
                tone(b, 1568.0, 1568.0, 0, 0.045, 0.11, 1.0, 0.002, 0.040, 0.08, 0);
                peak = 0.21f;
                break;
            }
            default: {
                b = new float[(int) (SR * 0.17)];
                tone(b, 1175.0, 1175.0, 0, 0, 0.09, 0.95, 0.002, 0.030, 0.08, 0);
                tone(b, 784.0, 784.0, 0, 0.045, 0.11, 0.85, 0.002, 0.045, 0.08, 0);
                peak = 0.18f;
                break;
            }
        }
        return finish(b, peak);
    }

    /**
     * Una nota: seno con 2.º y 3.º armónico suaves. {@code f0} → {@code f1} es el deslizamiento de tono durante
     * {@code glide} segundos; {@code start} y {@code dur} sitúan la nota; {@code att} es el ataque y {@code tau} la caída.
     */
    private static void tone(float[] b, double f0, double f1, double glide, double start, double dur, double amp,
                             double att, double tau, double h2, double h3) {
        int s0 = (int) (start * SR);
        int len = Math.min(b.length - s0, (int) (dur * SR));
        double ph = 0;
        for (int i = 0; i < len; i++) {
            double t = i / (double) SR;
            double f = glide > 0 && t < glide ? f0 + (f1 - f0) * (t / glide) : f1;
            ph += 2 * Math.PI * f / SR;
            double a = att > 0 ? Math.min(1.0, t / att) : 1.0;
            a = a * a * (3 - 2 * a);
            double rel = Math.min(1.0, (len - i) / (0.012 * SR));
            double v = Math.sin(ph) + h2 * Math.sin(2 * ph) + h3 * Math.sin(3 * ph);
            b[s0 + i] += (float) (v * a * Math.exp(-t / tau) * rel * amp);
        }
    }

    /** Un «tic» seco de ruido muy breve (el toque táctil del movimiento). */
    private static void click(float[] b, double start, double tau, double amp) {
        int s0 = (int) (start * SR);
        int len = Math.min(b.length - s0, (int) (tau * 6 * SR));
        long seed = 12345;
        for (int i = 0; i < len; i++) {
            seed = seed * 1103515245L + 12345L;
            double n = ((seed >> 16) & 0x7FFF) / 16384.0 - 1.0;
            b[s0 + i] += (float) (n * Math.exp(-(i / (double) SR) / tau) * amp);
        }
    }

    /** Ruido filtrado cuya frecuencia sube de {@code fa} a {@code fb}: el «whoosh» al abrir. */
    private static void sweep(float[] b, double start, double dur, double fa, double fb, double amp) {
        int s0 = (int) (start * SR);
        int len = Math.min(b.length - s0, (int) (dur * SR));
        double low = 0, band = 0;
        long seed = 987654;
        for (int i = 0; i < len; i++) {
            double t = i / (double) len;
            double fc = fa + (fb - fa) * t * t;
            double f = 2 * Math.sin(Math.PI * fc / SR);
            seed = seed * 1103515245L + 12345L;
            double in = ((seed >> 16) & 0x7FFF) / 16384.0 - 1.0;
            low += f * band;
            double high = in - low - 0.45 * band;
            band += f * high;
            double env = Math.sin(Math.PI * t);
            env *= env;
            b[s0 + i] += (float) (band * env * amp);
        }
    }

    /** Dos ecos cortos: el sonido «respira» un poco, sin llegar a ser reverberación. */
    private static void echo(float[] b, double d1, double g1, double d2, double g2) {
        int a = (int) (d1 * SR), c = (int) (d2 * SR);
        float[] src = b.clone();
        for (int i = 0; i < b.length; i++) {
            if (i >= a) b[i] += src[i - a] * (float) g1;
            if (i >= c) b[i] += src[i - c] * (float) g2;
        }
    }

    /** Suaviza los agudos, ajusta el volumen máximo y pasa a 16 bits (con los extremos a cero para que no haya chasquidos). */
    private static short[] finish(float[] b, float peak) {
        float lp = 0, max = 1e-6f;
        for (int i = 0; i < b.length; i++) {
            lp += (b[i] - lp) * 0.85f;
            b[i] = lp;
            max = Math.max(max, Math.abs(lp));
        }
        float g = peak / max;
        int fade = (int) (0.006 * SR);
        short[] out = new short[b.length];
        for (int i = 0; i < b.length; i++) {
            float v = b[i] * g;
            int left = b.length - 1 - i;
            if (left < fade) v *= left / (float) fade;
            out[i] = (short) Math.round(Math.max(-1f, Math.min(1f, v)) * 32767f);
        }
        return out;
    }

    /** Escribe un WAV mono de 16 bits. */
    private static void write(File f, short[] pcm) throws Exception {
        int n = pcm.length * 2;
        byte[] h = new byte[44 + n];
        put(h, 0, "RIFF");
        le32(h, 4, 36 + n);
        put(h, 8, "WAVE");
        put(h, 12, "fmt ");
        le32(h, 16, 16);
        le16(h, 20, 1);          // PCM
        le16(h, 22, 1);          // mono
        le32(h, 24, SR);
        le32(h, 28, SR * 2);
        le16(h, 32, 2);
        le16(h, 34, 16);
        put(h, 36, "data");
        le32(h, 40, n);
        for (int i = 0; i < pcm.length; i++) le16(h, 44 + 2 * i, pcm[i]);
        FileOutputStream o = new FileOutputStream(f);
        try {
            o.write(h);
        } finally {
            o.close();
        }
    }

    private static void put(byte[] b, int at, String s) {
        for (int i = 0; i < s.length(); i++) b[at + i] = (byte) s.charAt(i);
    }

    private static void le16(byte[] b, int at, int v) {
        b[at] = (byte) v;
        b[at + 1] = (byte) (v >> 8);
    }

    private static void le32(byte[] b, int at, int v) {
        le16(b, at, v);
        le16(b, at + 2, v >> 16);
    }
}
