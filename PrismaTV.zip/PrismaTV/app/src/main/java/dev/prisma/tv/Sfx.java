package dev.prisma.tv;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.SystemClock;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashSet;

/**
 * Sonidos de Lumen: el paquete de sonidos propio (carpeta res/raw, WAV de 48 kHz y 16 bits) con un toque de cristal
 * suave, al estilo de Windows 7 y Windows 11. Se reproducen con {@link SoundPool}, que responde casi al instante
 * (así el sonido sale a la vez que empieza la animación).
 *
 * Los archivos vienen masterizados muy fuertes, así que aquí se bajan a un nivel cómodo (tabla {@link #VOL}): el que
 * más se oye, el de moverse por las opciones, es el más bajo. Para subir o bajar todo a la vez basta con tocar
 * {@link #MASTER}.
 *
 * Interruptor encendido/apagado y menú emergente salen del mismo sonido de «OK» (más agudo o más grave y más corto),
 * para que todo suene a lo mismo.
 */
final class Sfx {
    // eventos
    static final int MOVE = 0;       // mover el foco
    static final int SELECT = 1;     // pulsar OK
    static final int BACK = 2;       // volver / cerrar
    static final int OPEN = 3;       // abrir una app (y entrar al Inicio al acabar la bienvenida)
    static final int SETTINGS = 4;   // abrir los ajustes
    static final int STARTUP = 5;    // arranque del launcher
    static final int POP = 6;        // aparece un menú pequeño
    static final int ON = 7;         // interruptor encendido
    static final int OFF = 8;        // interruptor apagado
    static final int UNLOCK = 9;     // salir de la pantalla de bloqueo (el acorde de arranque, más suave)

    /** Muestra (archivo) de cada evento: el desbloqueo reutiliza la del arranque. */
    private static final int[] SAMPLE = {0, 1, 2, 3, 4, 5, 6, 7, 8, 5};
    private static final int SAMPLES = 9;

    /** Qué archivo de res/raw es cada muestra (en este orden se cargan: el de arranque el primero). */
    private static int raw(int sample) {
        switch (sample) {
            case 0: return R.raw.navigation;
            case 1: return R.raw.select;
            case 2: return R.raw.back;
            case 3: return R.raw.open_app;
            case 4: return R.raw.settings;
            case 5: return R.raw.startup;
            case 6: return R.raw.pop;
            case 7: return R.raw.toggle_on;
            default: return R.raw.toggle_off;
        }
    }

    /** Volumen general de todos los sonidos (1 = el nivel pensado; menos = más bajo). */
    private static final float MASTER = 1f;

    /**
     * Volumen de cada evento (0..1) sobre el volumen del sistema. Los archivos están masterizados casi a tope, así que
     * estos números son los que dejan cada uno en su sitio: el de moverse muy suave y los de OK / abrir / arranque
     * algo más presentes.
     */
    private static final float[] VOL = {
            0.075f,   // MOVE
            0.205f,   // SELECT
            0.160f,   // BACK
            0.240f,   // OPEN
            0.205f,   // SETTINGS
            0.330f,   // STARTUP
            0.110f,   // POP
            0.125f,   // ON
            0.110f,   // OFF
            0.200f    // UNLOCK
    };

    boolean enabled = true;

    private final Context ctx;
    private SoundPool pool;
    private final Object lock = new Object();
    private final int[] ids = new int[SAMPLES];
    private final HashSet<Integer> loaded = new HashSet<>();
    private boolean wantStartup;
    private long lastMove;

    Sfx(Context context) {
        ctx = context.getApplicationContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    start();
                } catch (Throwable ignored) {
                    // sin sonido: la app funciona igual
                }
            }
        }, "lumen-sfx").start();
    }

    private void start() {
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        SoundPool sp = new SoundPool.Builder().setMaxStreams(5).setAudioAttributes(attrs).build();
        sp.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
            @Override
            public void onLoadComplete(SoundPool p, int sampleId, int status) {
                if (status != 0) return;
                synchronized (lock) {
                    loaded.add(sampleId);
                }
                tryStartup();
            }
        });
        synchronized (lock) {
            pool = sp;
        }
        // copias de versiones anteriores (los sonidos se generaban y se guardaban en la caché)
        try {
            File[] old = ctx.getCacheDir().listFiles();
            if (old != null) {
                for (File f : old) {
                    String n = f.getName();
                    if (n.startsWith("sfx") && n.endsWith(".wav") && !n.startsWith("sfxr_")) f.delete();
                }
            }
        } catch (Throwable ignored) {
        }
        // primero el de arranque, que es el que tiene prisa
        int[] order = {5, 0, 1, 2, 3, 4, 6, 7, 8};
        for (int s : order) {
            int id = loadSample(sp, s);
            synchronized (lock) {
                ids[s] = id;
            }
        }
        tryStartup();
    }

    /** Carga un archivo de res/raw; si el sistema no lo deja abrir directamente, lo copia a la caché y lo carga de ahí. */
    private int loadSample(SoundPool sp, int sample) {
        int res = raw(sample);
        try {
            int id = sp.load(ctx, res, 1);
            if (id != 0) return id;
        } catch (Throwable ignored) {
        }
        try {
            File f = new File(ctx.getCacheDir(), "sfxr_" + sample + ".wav");
            if (!f.exists() || f.length() < 100) {
                InputStream in = ctx.getResources().openRawResource(res);
                FileOutputStream out = new FileOutputStream(f);
                try {
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                } finally {
                    out.close();
                    in.close();
                }
            }
            return sp.load(f.getAbsolutePath(), 1);
        } catch (Throwable t) {
            return 0;
        }
    }

    // ------------------------------------------------------------------ reproducir

    /**
     * Suena el acorde de arranque en cuanto esté cargado (si hay sonido). Se llama una vez al arrancar el launcher.
     */
    void startup() {
        synchronized (lock) {
            wantStartup = true;
        }
        tryStartup();
    }

    private void tryStartup() {
        synchronized (lock) {
            if (!wantStartup || pool == null) return;
            int id = ids[SAMPLE[STARTUP]];
            if (id == 0 || !loaded.contains(id)) return;
            wantStartup = false;
        }
        if (enabled) go(STARTUP, 1f);
    }

    void play(int which) {
        if (!enabled) return;
        float k = 1f;
        if (which == MOVE) {
            long now = SystemClock.uptimeMillis();
            long dt = now - lastMove;
            if (dt < 110) return;           // nunca más de ~9 por segundo
            lastMove = now;
            if (dt < 220) k = 0.75f;        // recorriendo una lista deprisa: todavía más suave
        }
        go(which, k);
    }

    /** Interruptor: más agudo al encenderlo, más grave al apagarlo. */
    void toggle(boolean on) {
        play(on ? ON : OFF);
    }

    private void go(int which, float k) {
        try {
            SoundPool sp;
            int id;
            synchronized (lock) {
                sp = pool;
                id = ids[SAMPLE[which]];
                if (sp == null || id == 0 || !loaded.contains(id)) return;
            }
            float v = Math.min(1f, VOL[which] * MASTER * k);
            sp.play(id, v, v, which == MOVE ? 0 : 1, 0, 1f);
        } catch (Throwable ignored) {
        }
    }

    void release() {
        SoundPool sp;
        synchronized (lock) {
            sp = pool;
            pool = null;
            loaded.clear();
        }
        try {
            if (sp != null) sp.release();
        } catch (Throwable ignored) {
        }
    }
}
