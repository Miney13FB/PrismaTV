package dev.prisma.tv;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

/** Sonidos de navegación suaves, sintetizados por código (nada que descargar). */
final class Sfx {
    static final int MOVE = 0;
    static final int SELECT = 1;
    static final int BACK = 2;

    boolean enabled = true;
    private final AudioTrack[] tracks = new AudioTrack[3];
    private long lastMove;

    Sfx() {
        try {
            tracks[MOVE] = make(1180f, 1180f, 0.040f, 0.10f);
            tracks[SELECT] = make(740f, 1110f, 0.120f, 0.16f);
            tracks[BACK] = make(620f, 430f, 0.090f, 0.12f);
        } catch (Throwable ignored) {
        }
    }

    private static AudioTrack make(float f0, float f1, float dur, float vol) {
        int sr = 22050;
        int n = (int) (sr * dur);
        short[] s = new short[n];
        double phase = 0;
        for (int i = 0; i < n; i++) {
            double t = i / (double) n;
            double f = f0 + (f1 - f0) * t;
            phase += 2 * Math.PI * f / sr;
            double env = Math.sin(Math.PI * t);
            env *= env;
            double v = Math.sin(phase) * 0.8 + Math.sin(phase * 2) * 0.15;
            s[i] = (short) (v * env * vol * 32767);
        }
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        AudioFormat fmt = new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sr)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build();
        AudioTrack at = new AudioTrack(attrs, fmt, n * 2, AudioTrack.MODE_STATIC,
                AudioManager.AUDIO_SESSION_ID_GENERATE);
        at.write(s, 0, n);
        return at;
    }

    void play(int which) {
        if (!enabled) return;
        if (which == MOVE) {
            long now = System.currentTimeMillis();
            if (now - lastMove < 70) return;
            lastMove = now;
        }
        try {
            AudioTrack t = tracks[which];
            if (t == null) return;
            t.stop();
            t.reloadStaticData();
            t.play();
        } catch (Throwable ignored) {
        }
    }

    void release() {
        for (AudioTrack t : tracks) {
            try {
                if (t != null) t.release();
            } catch (Throwable ignored) {
            }
        }
    }
}
