package dev.prisma.tv;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Ajustes del Fire TV original. En Fire OS las intenciones estándar de Android (android.settings.*) suelen
 * acabar en una pantalla vacía de cumplimiento (CTSDummySettingsHandler) que no abre nada; por eso aquí se
 * prepara una lista de rutas (de la mejor a la peor) y {@link MainActivity#openRoutes} prueba cada una y
 * comprueba que de verdad se abrió algo antes de dar la ruta por buena.
 *
 * Amazon protege la mayoría de las pantallas sueltas de su app de Ajustes con un permiso que solo tienen sus
 * propias apps ({@code com.amazon.tv.permission.LAUNCHER_SETTINGS}): una app normal no puede abrirlas. Por eso
 * cada ruta se comprueba antes (exportada y sin permiso especial) y, si ninguna pantalla concreta se deja abrir,
 * se cae a los Ajustes completos de Fire TV, de los que siempre se puede entrar a mano a la pantalla buscada.
 */
final class FireSettings {
    private FireSettings() {
    }

    static final String LAUNCHER = "com.amazon.tv.launcher";
    static final String[] SETTINGS_PKGS = {"com.amazon.tv.settings.v2", "com.amazon.tv.settings"};
    /** Acciones oficiales de la app de Ajustes de Amazon: cada una abre una pantalla de "Ajustes" de Fire TV. */
    private static final String ACT = "com.amazon.device.settings.action.";

    /** Pantallas de Amazon que no son páginas de ajustes (vacías, de cumplimiento, barra de sonido...). */
    private static final String[] STUBS = {"cts", "dummy", "fallback", "wallpaper", "mirror", "daydream",
            "soundbar", "screensaver", "ambient"};

    /** Lista de rutas para abrir una pantalla: las primeras {@code exact} abren justo la pedida; el resto es el plan B. */
    static final class Plan {
        final ArrayList<Intent> routes = new ArrayList<>();
        int exact;

        /** Cierra el plan con los Ajustes principales de Fire TV (siempre se dejan abrir). */
        Plan fallback(Context c) {
            exact = routes.size();
            routes.addAll(mainRoutes(c));
            return this;
        }
    }

    // ------------------------------------------------------------------ escribir ajustes

    static boolean putSecure(Context c, String key, int v) {
        try {
            return Settings.Secure.putInt(c.getContentResolver(), key, v);
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean putSystem(Context c, String key, int v) {
        try {
            return Settings.System.putInt(c.getContentResolver(), key, v);
        } catch (Throwable t) {
            return false;
        }
    }

    // ------------------------------------------------------------------ rutas para abrir pantallas de ajustes

    private static Intent explicit(String pkg, String cls, String action) {
        Intent i = new Intent(action == null ? Intent.ACTION_MAIN : action);
        i.setComponent(new ComponentName(pkg, cls));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return i;
    }

    private static boolean has(PackageManager pm, String pkg, String cls) {
        try {
            pm.getActivityInfo(new ComponentName(pkg, cls), 0);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Una intención estándar solo vale si no acaba en la pantalla vacía de Fire OS ni en un selector. */
    private static Intent standard(PackageManager pm, Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ResolveInfo ri = pm.resolveActivity(i, 0);
            if (ri == null || ri.activityInfo == null) return null;
            String n = ri.activityInfo.name == null ? "" : ri.activityInfo.name;
            if (n.contains("CTSDummy") || n.contains("ResolverActivity") || n.contains("Dummy")) return null;
            return i;
        } catch (Throwable t) {
            return null;
        }
    }

    private static Intent standard(PackageManager pm, String action) {
        return standard(pm, new Intent(action));
    }

    /** Pantalla principal de Ajustes del launcher de Amazon (Fire OS 7 y 8), de la más a la menos fiable. */
    static List<Intent> mainRoutes(Context c) {
        PackageManager pm = c.getPackageManager();
        ArrayList<Intent> out = new ArrayList<>();
        if (has(pm, LAUNCHER, "com.amazon.tv.launcher.ui.MainSettingsActivity")) {
            out.add(explicit(LAUNCHER, "com.amazon.tv.launcher.ui.MainSettingsActivity",
                    "amazon.intent.action.MAINSETTINGS"));
        }
        try {
            Intent cat = new Intent(Intent.ACTION_MAIN);
            cat.addCategory("android.intent.category.LEANBACK_SETTINGS");
            cat.setPackage(LAUNCHER);
            cat.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (pm.resolveActivity(cat, 0) != null) out.add(cat);
        } catch (Throwable ignored) {
        }
        if (has(pm, LAUNCHER, "com.amazon.tv.launcher.ui.SettingsActivity")) {
            out.add(explicit(LAUNCHER, "com.amazon.tv.launcher.ui.SettingsActivity", null));
        }
        Intent std = standard(pm, Settings.ACTION_SETTINGS);
        if (std != null) out.add(std);
        return out;
    }

    /** Una intención estándar de Android (si funciona de verdad) y, si no, los ajustes principales de Fire TV. */
    static List<Intent> routes(Context c, Intent first) {
        ArrayList<Intent> out = new ArrayList<>();
        Intent std = standard(c.getPackageManager(), first);
        if (std != null) out.add(std);
        out.addAll(mainRoutes(c));
        return out;
    }

    static List<Intent> routes(Context c, String action) {
        return routes(c, new Intent(action));
    }

    // ------------------------------------------------------------------ pantallas sueltas de la app de Ajustes de Amazon

    private static boolean stub(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        for (String s : STUBS) {
            if (n.contains(s)) return true;
        }
        return false;
    }

    private static String simple(String cls) {
        int i = Math.max(cls.lastIndexOf('.'), cls.lastIndexOf('$'));
        return i < 0 ? cls : cls.substring(i + 1);
    }

    /** ¿Puede esta app abrir esa pantalla? (activada y sin un permiso que solo tienen las apps de Amazon). */
    private static boolean allowed(Context c, ActivityInfo ai) {
        if (ai == null || !ai.enabled) return false;
        String perm = ai.permission;
        if (perm == null || perm.isEmpty()) return true;
        try {
            return c.checkPermission(perm, android.os.Process.myPid(), android.os.Process.myUid())
                    == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Pantalla que responde a una acción de Ajustes de Amazon, si esta app puede abrirla. */
    private static Intent action(Context c, String action) {
        try {
            PackageManager pm = c.getPackageManager();
            for (String p : SETTINGS_PKGS) {
                Intent probe = new Intent(action);
                probe.setPackage(p);
                List<ResolveInfo> l = pm.queryIntentActivities(probe, 0);
                if (l == null) continue;
                for (ResolveInfo ri : l) {
                    ActivityInfo ai = ri.activityInfo;
                    if (ai == null || ai.name == null || !ai.exported || stub(ai.name) || !allowed(c, ai)) continue;
                    // con el componente exacto no hace falta que la pantalla declare la categoría "por defecto"
                    Intent i = new Intent(action);
                    i.setComponent(new ComponentName(ai.packageName, ai.name));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    return i;
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** Todas las pantallas de las apps de Ajustes de Amazon que esta app puede abrir. */
    private static List<ActivityInfo> openable(Context c) {
        ArrayList<ActivityInfo> out = new ArrayList<>();
        PackageManager pm = c.getPackageManager();
        for (String p : SETTINGS_PKGS) {
            try {
                PackageInfo pi = pm.getPackageInfo(p, PackageManager.GET_ACTIVITIES);
                if (pi.activities == null) continue;
                for (ActivityInfo ai : pi.activities) {
                    if (ai.name == null || !ai.exported || stub(ai.name) || !allowed(c, ai)) continue;
                    out.add(ai);
                }
            } catch (Throwable ignored) {
            }
        }
        return out;
    }

    /**
     * Pantallas que se pueden abrir cuyo nombre contiene alguna de las palabras (en orden de preferencia) y
     * ninguna de las excluidas. A igual palabra, antes las de nombre más corto (las más generales).
     */
    private static List<Intent> named(Context c, String[] want, String... not) {
        ArrayList<Intent> out = new ArrayList<>();
        ArrayList<ActivityInfo> all = new ArrayList<>(openable(c));
        Collections.sort(all, new Comparator<ActivityInfo>() {
            @Override
            public int compare(ActivityInfo x, ActivityInfo y) {
                return simple(x.name).length() - simple(y.name).length();
            }
        });
        for (String w : want) {
            for (ActivityInfo ai : all) {
                String n = simple(ai.name).toLowerCase(Locale.ROOT);
                if (!n.contains(w)) continue;
                boolean skip = false;
                for (String x : not) {
                    if (n.contains(x)) skip = true;
                }
                if (skip) continue;
                boolean dup = false;
                for (Intent o : out) {
                    if (o.getComponent() != null && o.getComponent().getClassName().equals(ai.name)) dup = true;
                }
                if (!dup) out.add(explicit(ai.packageName, ai.name, null));
            }
        }
        return out;
    }

    private static void add(List<Intent> out, Intent i) {
        if (i != null) out.add(i);
    }

    /** Pantallas de «Mi Fire TV» que esta app puede abrir (acción oficial de Amazon y, si existe, su pantalla). */
    private static List<Intent> deviceRoutes(Context c) {
        ArrayList<Intent> out = new ArrayList<>();
        add(out, action(c, ACT + "DEVICE"));
        PackageManager pm = c.getPackageManager();
        String cls = "com.amazon.tv.settings.v2.tv.device.DeviceActivity";
        try {
            ActivityInfo ai = pm.getActivityInfo(new ComponentName(SETTINGS_PKGS[0], cls), 0);
            if (ai.exported && allowed(c, ai)) out.add(explicit(SETTINGS_PKGS[0], cls, null));
        } catch (Throwable ignored) {
        }
        return out;
    }

    /** "Mi Fire TV" (Acerca de, nombre del dispositivo, actualizaciones, reiniciar). */
    static Plan devicePlan(Context c) {
        Plan p = new Plan();
        p.routes.addAll(deviceRoutes(c));
        return p.fallback(c);
    }

    /**
     * «Reiniciar». Fire OS solo deja reiniciar el aparato a sus propias apps, así que se abre lo más cerca posible del
     * botón «Reiniciar» de los ajustes originales: su pantalla propia (si existe y se deja abrir), «Mi Fire TV», la
     * pantalla de información del equipo y, por último, los Ajustes completos. Con {@code exact = 0} siempre se puede
     * avisar de dónde pulsar.
     */
    static Plan restartPlan(Context c) {
        Plan p = new Plan();
        p.routes.addAll(named(c, new String[]{"restart", "reboot"}));
        p.routes.addAll(deviceRoutes(c));
        add(p.routes, standard(c.getPackageManager(), Settings.ACTION_DEVICE_INFO_SETTINGS));
        p.routes.addAll(mainRoutes(c));
        return p;
    }

    /**
     * La ficha de una app en los ajustes originales de Fire TV (Aplicaciones → Administrar aplicaciones instaladas →
     * la app): desde ahí se abre, se detiene, se borra la caché o los datos y se desinstala. Si Amazon no deja abrir la
     * ficha suelta se abre la lista de aplicaciones instaladas y, si tampoco, los Ajustes completos (con aviso).
     */
    static Plan appPlan(Context c, String pkg) {
        Plan p = new Plan();
        PackageManager pm = c.getPackageManager();
        add(p.routes, standard(pm, new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", pkg, null))));
        p.exact = p.routes.size();
        add(p.routes, standard(pm, new Intent(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS)));
        add(p.routes, standard(pm, new Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS)));
        p.routes.addAll(named(c, new String[]{"allapplications", "manageapplications", "installedapp"}));
        p.routes.addAll(mainRoutes(c));
        return p;
    }

    // ------------------------------------------------------------------ informe (mantener pulsado «Todos los ajustes»)

    private static String first(List<Intent> l) {
        if (l.isEmpty()) return "—";
        Intent i = l.get(0);
        if (i.hasCategory("android.intent.category.LEANBACK_SETTINGS")) return "Ajustes completos";
        if (i.getComponent() != null) {
            if (LAUNCHER.equals(i.getComponent().getPackageName())) return "Ajustes completos";
            return simple(i.getComponent().getClassName());
        }
        return String.valueOf(i.getAction());
    }

    /** Qué pantalla abriría cada fila y qué pantallas de Amazon deja abrir este Fire TV (para saber qué pasa si algo falla). */
    static String report(Context c) {
        StringBuilder sb = new StringBuilder();
        Plan[] ps = {devicePlan(c), restartPlan(c), appPlan(c, c.getPackageName())};
        String[] names = {"Mi Fire TV", "Reiniciar", "Ficha de una app"};
        for (int i = 0; i < ps.length; i++) {
            sb.append(names[i]).append(": ").append(first(ps[i].routes)).append('\n');
        }
        PackageManager pm = c.getPackageManager();
        int total = 0, free = 0;
        StringBuilder list = new StringBuilder();
        for (String p : SETTINGS_PKGS) {
            try {
                PackageInfo pi = pm.getPackageInfo(p, PackageManager.GET_ACTIVITIES);
                if (pi.activities == null) continue;
                for (ActivityInfo ai : pi.activities) {
                    if (ai.name == null || !ai.exported) continue;
                    total++;
                    if (stub(ai.name)) continue;
                    if (allowed(c, ai)) {
                        free++;
                        if (free <= 60) list.append(free > 1 ? ", " : "").append(simple(ai.name));
                    }
                }
            } catch (Throwable ignored) {
            }
        }
        sb.append("\nPantallas de Ajustes que Amazon deja abrir: ").append(free).append(" de ").append(total)
                .append(" visibles\n").append(list);
        return sb.toString();
    }

    /** Texto corto para saber qué se probó (se enseña solo si ninguna ruta funcionó). */
    static String describe(List<Intent> routes) {
        StringBuilder sb = new StringBuilder();
        for (Intent i : routes) {
            if (sb.length() > 0) sb.append('\n');
            if (i.getComponent() != null) {
                String cls = i.getComponent().getClassName();
                sb.append(i.getComponent().getPackageName()).append('/').append(cls.substring(cls.lastIndexOf('.') + 1));
            } else if (i.getAction() != null) {
                sb.append(i.getAction());
            } else {
                sb.append(String.valueOf(i.getCategories()));
            }
        }
        return sb.length() == 0 ? "-" : sb.toString();
    }
}
