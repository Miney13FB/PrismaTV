package dev.prisma.tv;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;

/** Tiempo actual por lugar con Open-Meteo (gratis, sin cuenta ni clave). */
final class Weather {
    static final class Wx {
        float temp;
        int code;
        boolean day;
        long ts;
        // próximos días (sin contar hoy)
        int n;
        int[] dCode = new int[5];
        float[] dMax = new float[5];
        float[] dMin = new float[5];
        String[] dName = new String[5];
    }

    static final class Hit {
        String name, country, admin;
        double lat, lon;

        String label() {
            StringBuilder sb = new StringBuilder(name);
            if (admin != null && !admin.isEmpty() && !admin.equals(name)) sb.append(", ").append(admin);
            if (country != null && !country.isEmpty()) sb.append(", ").append(country);
            return sb.toString();
        }
    }

    interface Done {
        void done();
    }

    interface Found {
        void found(List<Hit> hits, boolean error);
    }

    private static final long STALE = 20L * 60 * 1000;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService ex = Bg.single("lumen-wx");
    private final HashMap<String, Wx> cache = new HashMap<>();

    /** Cierra su hilo (cuando se cierra la pantalla principal): sin esto cada pantalla nueva dejaría uno parado para siempre. */
    void close() {
        ex.shutdownNow();
    }

    static String key(String[] p) {
        return p[2] + "," + p[3];
    }

    synchronized Wx get(String[] p) {
        return cache.get(key(p));
    }

    void refresh(final List<String[]> places, final boolean force, final Done cb) {
        try {
            ex.execute(new Runnable() {
                @Override
                public void run() {
                    boolean changed = false;
                    for (String[] p : places) {
                        Wx old = get(p);
                        if (!force && old != null && System.currentTimeMillis() - old.ts < STALE) continue;
                        try {
                            String url = "https://api.open-meteo.com/v1/forecast?latitude=" + p[2]
                                    + "&longitude=" + p[3]
                                    + "&current=temperature_2m,weather_code,is_day"
                                    + "&daily=weather_code,temperature_2m_max,temperature_2m_min&forecast_days=6&timezone=auto";
                            JSONObject all = new JSONObject(http(url));
                            JSONObject cur = all.getJSONObject("current");
                            Wx w = new Wx();
                            try {
                                JSONObject dl = all.getJSONObject("daily");
                                JSONArray dt = dl.getJSONArray("time");
                                JSONArray dc = dl.getJSONArray("weather_code");
                                JSONArray dx = dl.getJSONArray("temperature_2m_max");
                                JSONArray dn = dl.getJSONArray("temperature_2m_min");
                                SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT);
                                SimpleDateFormat outF = new SimpleDateFormat("EEE", Locale.getDefault());
                                for (int i = 1; i < dt.length() && w.n < 5; i++) {
                                    w.dCode[w.n] = dc.getInt(i);
                                    w.dMax[w.n] = (float) dx.getDouble(i);
                                    w.dMin[w.n] = (float) dn.getDouble(i);
                                    String nm = outF.format(in.parse(dt.getString(i)));
                                    w.dName[w.n] = nm.substring(0, 1).toUpperCase(Locale.getDefault()) + nm.substring(1);
                                    w.n++;
                                }
                            } catch (Throwable ignored2) {
                            }
                            w.temp = (float) cur.getDouble("temperature_2m");
                            w.code = cur.getInt("weather_code");
                            w.day = cur.optInt("is_day", 1) == 1;
                            w.ts = System.currentTimeMillis();
                            synchronized (Weather.this) {
                                cache.put(key(p), w);
                            }
                            changed = true;
                        } catch (Throwable ignored) {
                        }
                    }
                    if (changed && cb != null) {
                        ui.post(new Runnable() {
                            @Override
                            public void run() {
                                cb.done();
                            }
                        });
                    }
                }
            });
        } catch (Throwable ignored) {
        }
    }

    /** Busca una ciudad. Admite "Madrid" o "Madrid, España". */
    void search(final String query, final Found cb) {
        try {
            ex.execute(new Runnable() {
                @Override
                public void run() {
                    final ArrayList<Hit> out = new ArrayList<>();
                    boolean err = false;
                    try {
                        String[] parts = query.split(",");
                        String name = parts[0].trim();
                        String filter = parts.length > 1 ? parts[parts.length - 1].trim().toLowerCase(Locale.ROOT) : "";
                        String lang = Locale.getDefault().getLanguage();
                        String url = "https://geocoding-api.open-meteo.com/v1/search?name="
                                + URLEncoder.encode(name, "UTF-8") + "&count=10&format=json&language="
                                + URLEncoder.encode(lang, "UTF-8");
                        JSONObject o = new JSONObject(http(url));
                        JSONArray arr = o.optJSONArray("results");
                        if (arr != null) {
                            ArrayList<Hit> all = new ArrayList<>();
                            for (int i = 0; i < arr.length(); i++) {
                                JSONObject r = arr.getJSONObject(i);
                                Hit h = new Hit();
                                h.name = r.optString("name");
                                h.country = r.optString("country");
                                h.admin = r.optString("admin1");
                                h.lat = r.getDouble("latitude");
                                h.lon = r.getDouble("longitude");
                                all.add(h);
                            }
                            for (Hit h : all) {
                                if (filter.isEmpty() || h.country.toLowerCase(Locale.ROOT).contains(filter)
                                        || h.admin.toLowerCase(Locale.ROOT).contains(filter)) out.add(h);
                            }
                            if (out.isEmpty()) out.addAll(all);
                        }
                    } catch (Throwable t) {
                        err = true;
                    }
                    final boolean fe = err;
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            cb.found(out, fe);
                        }
                    });
                }
            });
        } catch (Throwable ignored) {
        }
    }

    private static String http(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        try {
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            InputStream in = c.getInputStream();
            try {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                return new String(bo.toByteArray(), "UTF-8");
            } finally {
                in.close();
            }
        } finally {
            c.disconnect();   // también cuando el servidor contesta con un error (antes la conexión se quedaba abierta)
        }
    }
}
