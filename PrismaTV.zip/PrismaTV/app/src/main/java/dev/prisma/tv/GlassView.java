package dev.prisma.tv;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.widget.FrameLayout;

import java.util.ArrayList;

/**
 * Panel de "cristal líquido": dibuja la parte del fondo ya desenfocado que queda
 * justo debajo, un tinte, un brillo superior y un borde fino. Coste por fotograma:
 * un solo drawRoundRect con shader (dos, y solo durante el fundido entre un fondo y otro).
 */
class GlassView extends FrameLayout {
    private static Bitmap backdrop, oldBackdrop;
    private static float mix = 1f;   // 0 = se ve todavía el fondo anterior, 1 = ya solo el nuevo
    private static int sw, sh;
    private static final ArrayList<GlassView> LIVE = new ArrayList<>();

    /** Tamaño de la pantalla (el fondo desenfocado se estira a todo ese tamaño). */
    static void screen(int screenW, int screenH) {
        sw = screenW;
        sh = screenH;
    }

    /** Cambia el fondo del cristal de golpe, sin fundido. */
    static void setBackdrop(Bitmap b) {
        backdrop = b;
        oldBackdrop = null;
        mix = 1f;
        redrawAll();
    }

    /** Empieza un fundido hacia otro fondo desenfocado: el cristal se funde a la vez que la foto. */
    static void fadeTo(Bitmap b) {
        oldBackdrop = backdrop;
        backdrop = b;
        mix = oldBackdrop == null ? 1f : 0f;
        redrawAll();
    }

    /** Avance del fundido (0..1); al llegar a 1 se olvida el fondo anterior. */
    static void setMix(float m) {
        mix = m;
        if (m >= 1f) oldBackdrop = null;
        redrawAll();
    }

    private static void redrawAll() {
        for (int i = 0; i < LIVE.size(); i++) LIVE.get(i).invalidate();
    }

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint tintP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sheenP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rimP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint focusP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final RectF rimRect = new RectF();
    private final Matrix m = new Matrix();
    private final int[] loc = new int[2];
    private BitmapShader shader, oldShader;
    private Bitmap shaderBmp, oldShaderBmp;
    private final float radius;
    private final float rimW;
    private boolean focusRim;

    GlassView(Context c, float radiusPx, int tintColor) {
        super(c);
        setWillNotDraw(false);
        radius = radiusPx;
        rimW = Math.max(1.5f, radiusPx / 22f);

        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(1.35f);
        fill.setColorFilter(new ColorMatrixColorFilter(cm));

        tintP.setStyle(Paint.Style.FILL);
        tintP.setColor(tintColor);

        rimP.setStyle(Paint.Style.STROKE);
        rimP.setStrokeWidth(rimW);
        rimP.setColor(0x4DFFFFFF);

        focusP.setStyle(Paint.Style.STROKE);
        focusP.setStrokeWidth(Math.max(2.5f, radiusPx / 9f));
        focusP.setColor(0xEEFFFFFF);
    }

    void setTint(int c) {
        tintP.setColor(c);
        invalidate();
    }

    void setFocusRim(boolean on) {
        if (focusRim != on) {
            focusRim = on;
            invalidate();
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        rect.set(0, 0, w, h);
        float i = rimW / 2f;
        rimRect.set(i, i, w - i, h - i);
        sheenP.setShader(new LinearGradient(0, 0, 0, h * 0.65f, 0x38FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (!LIVE.contains(this)) LIVE.add(this);
    }

    @Override
    protected void onDetachedFromWindow() {
        LIVE.remove(this);
        super.onDetachedFromWindow();
    }

    /** Coloca el fondo desenfocado de modo que lo que se ve en este panel sea justo lo que hay detrás de él. */
    private void aim(BitmapShader sh2, Bitmap bd) {
        m.setScale(sw / (float) bd.getWidth(), sh / (float) bd.getHeight());
        m.postTranslate(-loc[0], -loc[1]);
        sh2.setLocalMatrix(m);
    }

    @Override
    protected void onDraw(Canvas c) {
        Bitmap bd = backdrop;
        if (bd != null && sw > 0 && sh > 0) {
            getLocationInWindow(loc);
            Bitmap od = mix < 1f ? oldBackdrop : null;
            if (od != null) {
                // fundido: primero el fondo anterior entero y encima el nuevo, cada vez más opaco
                if (oldShader == null || oldShaderBmp != od) {
                    oldShader = new BitmapShader(od, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                    oldShaderBmp = od;
                }
                aim(oldShader, od);
                fill.setShader(oldShader);
                fill.setAlpha(255);
                c.drawRoundRect(rect, radius, radius, fill);
            } else if (oldShader != null) {
                oldShader = null;
                oldShaderBmp = null;
            }
            if (shader == null || shaderBmp != bd) {
                shader = new BitmapShader(bd, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                shaderBmp = bd;
            }
            aim(shader, bd);
            fill.setShader(shader);
            fill.setAlpha(od != null ? Math.round(255 * mix) : 255);
            c.drawRoundRect(rect, radius, radius, fill);
        }
        c.drawRoundRect(rect, radius, radius, tintP);
        c.drawRoundRect(rect, radius, radius, sheenP);
        c.drawRoundRect(rimRect, radius, radius, rimP);
        if (focusRim) {
            float i = focusP.getStrokeWidth() / 2f;
            rimRect.set(i, i, getWidth() - i, getHeight() - i);
            c.drawRoundRect(rimRect, radius, radius, focusP);
            float j = rimW / 2f;
            rimRect.set(j, j, getWidth() - j, getHeight() - j);
        }
    }
}
