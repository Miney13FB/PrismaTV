package dev.prisma.tv;

/** Vistas que reaccionan al foco del mando (zoom, borde, brillo). */
interface FocusFx {
    void fx(boolean focused, int dir, boolean animate);
}
