package dev.prisma.tv;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Icono de Wi-Fi dibujado por código; las barras se apagan según la señal (0-4). */
final class WifiView extends View {
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private int level = 4;

    WifiView(Context c) {
        super(c);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);
        dot.setStyle(Paint.Style.FILL);
    }

    void setLevel(int l) {
        level = l;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float s = Math.min(getWidth(), getHeight());
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f + s * 0.30f;
        arc.setStrokeWidth(s * 0.095f);
        for (int i = 1; i <= 3; i++) {
            float rad = s * 0.20f * i;
            r.set(cx - rad, cy - rad, cx + rad, cy + rad);
            int lit = level <= 0 ? 0 : Math.min(3, level);
            arc.setColor(i <= lit ? 0xFFFFFFFF : 0x4DFFFFFF);
            c.drawArc(r, 225f, 90f, false, arc);
        }
        dot.setColor(level > 0 ? 0xFFFFFFFF : 0x4DFFFFFF);
        c.drawCircle(cx, cy, s * 0.065f, dot);
    }
}
