package dev.prisma.tv;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Fila de ajustes estilo iPhone: icono de color, título, estado (punto verde/gris),
 * valor y a la derecha un interruptor o una flecha.
 */
final class IRow extends LinearLayout implements FocusFx {
    private final float u;
    private final GradientDrawable on;
    private final GradientDrawable off;
    private final FrameLayout iconBox;
    private boolean iconAttached;
    final TextView title;
    final TextView value;
    private StatusDot dot;
    private SwitchView sw;
    private TextView chev;

    IRow(Context c, float u, int glyph, int color, String t) {
        super(c);
        this.u = u;
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        setFocusable(true);
        setClickable(true);
        int pad = Math.round(16f * u);
        setPadding(pad, 0, pad, 0);

        off = new GradientDrawable();
        off.setColor(0x00FFFFFF);
        off.setCornerRadius(12f * u);
        on = new GradientDrawable();
        on.setColor(0x52FFFFFF);
        on.setCornerRadius(12f * u);
        on.setStroke(Math.max(2, Math.round(2f * u)), 0xB3FFFFFF);
        setBackground(off);

        iconBox = new FrameLayout(c);
        if (glyph >= 0) {
            iconBox.addView(new Glyph(c, glyph, color, true), new FrameLayout.LayoutParams(-1, -1));
            attachIcon(36);
        }

        title = new TextView(c);
        title.setText(t);
        title.setTextSize(TypedValue.COMPLEX_UNIT_PX, 21f * u);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setIncludeFontPadding(false);
        addView(title, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));

        value = new TextView(c);
        value.setTextSize(TypedValue.COMPLEX_UNIT_PX, 19f * u);
        value.setTextColor(0xB8FFFFFF);
        value.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        value.setSingleLine(true);
        value.setEllipsize(android.text.TextUtils.TruncateAt.END);
        value.setMaxWidth(Math.round(300f * u));
        value.setIncludeFontPadding(false);
        value.setGravity(Gravity.END);
        LayoutParams vp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        vp.leftMargin = Math.round(10f * u);
        addView(value, vp);
    }

    private void attachIcon(int sizeDesign) {
        if (iconAttached) return;
        iconAttached = true;
        LayoutParams lp = new LayoutParams(Math.round(sizeDesign * u), Math.round(sizeDesign * u));
        lp.rightMargin = Math.round(14f * u);
        addView(iconBox, 0, lp);
    }

    /** Pone una vista propia (por ejemplo, el icono de señal Wi-Fi) en el hueco del icono. */
    void setLead(View v, int sizeDesign) {
        iconBox.removeAllViews();
        iconBox.addView(v, new FrameLayout.LayoutParams(-1, -1));
        attachIcon(sizeDesign);
    }

    void setValue(String v) {
        value.setText(v);
    }

    /** Punto verde (encendido/conectado) o gris (apagado/desconectado) más un texto. */
    void setStatus(boolean isOn, String text) {
        if (dot == null) {
            dot = new StatusDot(getContext());
            LayoutParams lp = new LayoutParams(Math.round(12f * u), Math.round(12f * u));
            addView(dot, indexOfChild(value), lp);
        }
        dot.setOn(isOn);
        value.setText(text);
    }

    void setSwitch(boolean isOn) {
        if (sw == null) {
            sw = new SwitchView(getContext());
            LayoutParams lp = new LayoutParams(Math.round(54f * u), Math.round(32f * u));
            lp.leftMargin = Math.round(14f * u);
            addView(sw, lp);
        }
        sw.setOn(isOn);
    }

    boolean isOn() {
        return sw != null && sw.isOn();
    }

    void setChevron() {
        if (chev != null) return;
        chev = new TextView(getContext());
        chev.setText("›");
        chev.setTextSize(TypedValue.COMPLEX_UNIT_PX, 30f * u);
        chev.setTextColor(0x88FFFFFF);
        chev.setIncludeFontPadding(false);
        LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        lp.leftMargin = Math.round(10f * u);
        addView(chev, lp);
    }

    @Override
    public void fx(boolean focused, int dir, boolean animate) {
        setBackground(focused ? on : off);
        value.setTextColor(focused ? 0xFFFFFFFF : 0xB8FFFFFF);
    }
}
