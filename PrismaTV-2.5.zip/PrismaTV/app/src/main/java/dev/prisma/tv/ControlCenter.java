package dev.prisma.tv;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.net.DhcpInfo;
import android.net.Uri;
import android.os.PowerManager;
import android.view.Display;
import android.widget.ImageView;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.InputType;
import android.text.format.Formatter;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Ajustes de Prisma TV (estilo iPhone): panel lateral de cristal con grupos de filas,
 * interruptores verdes/grises y todo lo del dispositivo (Wi-Fi, Bluetooth, bloqueo, tiempo,
 * dispositivo) sin salir del launcher.
 */
final class ControlCenter {
    interface Get { String get(); }
    interface Stp { void step(int dir); }
    interface SwCb { void on(boolean v); }

    private static final int BLUE = 0xFF0A84FF, ORANGE = 0xFFFF9F0A, PURPLE = 0xFFBF5AF2,
            RED = 0xFFFF453A, TEAL = 0xFF30B0C7, PINK = 0xFFFF375F, INDIGO = 0xFF5E5CE6,
            GREEN = 0xFF34C759, GRAY = 0xFF8E8E93;
    static final int[] IDLE_OPTS = {3, 5, 10, 20};
    private static final int PAGES = 12;

    private final MainActivity a;
    boolean open;
    private FrameLayout layer;
    private GlassView panel;
    private final ScrollView[] svs = new ScrollView[PAGES];
    private final LinearLayout[] cols = new LinearLayout[PAGES];
    private int page = -1;
    private View prevFocus;
    private boolean askedLoc;
    private boolean rxOn;

    // principal
    private TextView timeTv, dateTv;
    private IRow rWifi, rBt, rLock, rWx, rWall, swShelf, swSound, swClock, rName, rHidden, rRam, rDev;

    // Wi-Fi
    private IRow swWifi;
    private LinearLayout wifiBody;
    private boolean scanning;

    // Bluetooth
    private IRow swBt, rSearch;
    private LinearLayout btBody;
    private IGroup btOther;
    private boolean discovering;
    private final ArrayList<BluetoothDevice> found = new ArrayList<>();
    private final HashMap<String, String> foundName = new HashMap<>();
    private final Set<String> foundShown = new HashSet<>();

    ControlCenter(MainActivity act) {
        a = act;
    }

    // ------------------------------------------------------------------ utilidades

    private int px(float v) {
        return a.px(v);
    }

    private String s(int res) {
        return a.getString(res);
    }

    private WifiManager wm() {
        return (WifiManager) a.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
    }

    private static boolean inside(View f, View container) {
        View v = f;
        while (v != null) {
            if (v == container) return true;
            ViewParent p = v.getParent();
            v = p instanceof View ? (View) p : null;
        }
        return false;
    }

    private static View firstFocusable(View v) {
        if (v.isFocusable() && v.getVisibility() == View.VISIBLE && !(v instanceof ScrollView)) return v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = firstFocusable(g.getChildAt(i));
                if (r != null) return r;
            }
        }
        return null;
    }

    private static View findTag(View v, String key) {
        if (key.equals(v.getTag())) return v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = findTag(g.getChildAt(i), key);
                if (r != null) return r;
            }
        }
        return null;
    }

    private String focusKey(View container) {
        View f = a.root.findFocus();
        if (f != null && inside(f, container) && f.getTag() instanceof String) return (String) f.getTag();
        return null;
    }

    private void restoreFocus(View container, String key) {
        if (key == null) return;
        View v = findTag(container, key);
        if (v != null) v.requestFocus();
    }

    private IGroup group(LinearLayout col) {
        IGroup g = new IGroup(a, a.u);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = px(10);
        col.addView(g, lp);
        return g;
    }

    private IRow nav(IGroup g, int glyph, int color, String title, final Runnable click) {
        IRow r = new IRow(a, a.u, glyph, color, title);
        g.add(r);
        r.setChevron();
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.sfx.play(Sfx.SELECT);
                if (click != null) click.run();
            }
        });
        return r;
    }

    private IRow sw(IGroup g, int glyph, int color, String title, boolean init, final SwCb cb) {
        final IRow r = new IRow(a, a.u, glyph, color, title);
        g.add(r);
        r.setSwitch(init);
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.sfx.play(Sfx.TOGGLE);
                boolean nv = !r.isOn();
                r.setSwitch(nv);
                cb.on(nv);
            }
        });
        return r;
    }

    private IRow arrow(IGroup g, int glyph, int color, String title, final Get get, final Stp stp) {
        final IRow r = new IRow(a, a.u, glyph, color, title);
        g.add(r);
        r.setValue("‹  " + get.get() + "  ›");
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.sfx.play(Sfx.SELECT);
                stp.step(1);
                r.setValue("‹  " + get.get() + "  ›");
            }
        });
        r.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int code, KeyEvent e) {
                if (e.getAction() != KeyEvent.ACTION_DOWN) return false;
                if (code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT) {
                    stp.step(code == KeyEvent.KEYCODE_DPAD_LEFT ? -1 : 1);
                    r.setValue("‹  " + get.get() + "  ›");
                    return true;
                }
                return false;
            }
        });
        return r;
    }

    private void arrowRefresh(IRow r, Get g) {
        r.setValue("‹  " + g.get() + "  ›");
    }

    private TextView label(LinearLayout col, String t) {
        TextView v = a.text(t, 14, 0x99FFFFFF, MainActivity.MEDIUM);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = px(18);
        lp.topMargin = px(14);
        lp.bottomMargin = px(8);
        col.addView(v, lp);
        return v;
    }

    private void header(LinearLayout col, String title) {
        IGroup g = group(col);
        IRow b = new IRow(a, a.u, -1, 0, "‹  " + s(R.string.cc_settings));
        g.add(b);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.sfx.play(Sfx.BACK);
                back();
            }
        });
        TextView t = a.text(title, 36, 0xFFFFFFFF, MainActivity.MEDIUM);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = px(18);
        lp.topMargin = px(6);
        lp.bottomMargin = px(10);
        col.addView(t, lp);
    }

    // ------------------------------------------------------------------ abrir / cerrar

    void open(int startPage) {
        if (open) return;
        if (layer == null) build();
        open = true;
        askedLoc = false;
        prevFocus = a.root.findFocus();
        a.blockContent(true);
        a.setTint(0);
        a.root.addView(layer, new FrameLayout.LayoutParams(-1, -1));
        layer.setAlpha(0f);
        layer.animate().alpha(1f).setDuration(240).start();
        panel.setTranslationX(px(660));
        panel.animate().translationX(0f).setDuration(260)
                .setInterpolator(new DecelerateInterpolator()).start();
        page = -1;
        show(startPage, -1);
    }

    void close() {
        if (!open) return;
        unregister();
        stopDiscovery();
        flushHidden();
        iconGen++;
        open = false;
        a.root.removeView(layer);
        a.blockContent(false);
        if (prevFocus != null && prevFocus.isAttachedToWindow()) prevFocus.requestFocus();
        else a.focusFirstFav();
    }

    void back() {
        if (page == 8) show(7, 8);
        else if (page == 11) show(5, 11);
        else if (page > 0) {
            flushHidden();
            show(0, page);
        }
        else close();
    }

    void tick() {
        if (timeTv != null && open && page == 0) {
            timeTv.setText(a.fmtTime());
            dateTv.setText(a.fmtDate());
        }
    }

    void netChanged() {
        if (!open) return;
        if (page == 0) refreshMain();
        else if (page == 1) fillWifi();
    }

    void btChanged() {
        if (open && page == 0) refreshMain();
    }

    void permResult() {
        if (!open) return;
        if (page == 1) {
            startScan();
            fillWifi();
        } else if (page == 2) {
            fillBt();
        }
    }

    private void show(int p, int from) {
        unregister();
        if (page == 2 && p != 2) stopDiscovery();
        page = p;
        for (int i = 0; i < PAGES; i++) svs[i].setVisibility(i == p ? View.VISIBLE : View.GONE);
        View f = null;
        if (p == 0) {
            refreshMain();
            IRow[] back = {null, rWifi, rBt, rLock, rWx, rDev, rHidden, rApps, rApps, rDisp, rSnd, rDev};
            f = from > 0 ? back[from] : firstFocusable(cols[0]);
        } else {
            if (p == 1) {
                buildWifi();
                register(1);
                if ((!a.hasLocation()) && !askedLoc) {
                    askedLoc = true;
                    a.ensureLocation();
                } else {
                    startScan();
                }
            } else if (p == 2) {
                buildBt();
                register(2);
                if ((!a.hasLocation()) && !askedLoc) {
                    askedLoc = true;
                    a.ensureLocation();
                }
            } else if (p == 3) {
                buildLock();
            } else if (p == 4) {
                buildWeather();
            } else if (p == 5) {
                buildFire();
            } else if (p == 6) {
                buildHidden();
            } else if (p == 7) {
                buildApps();
            } else if (p == 8) {
                buildAppDetail();
            } else if (p == 9) {
                buildDisplay();
            } else if (p == 10) {
                buildSound();
            } else {
                buildScreens();
            }
            f = firstFocusable(cols[p]);
        }
        if (f != null) f.requestFocus();
        stagger(cols[p]);
    }

    /** Entrada escalonada de los bloques de una página. */
    private void stagger(LinearLayout col) {
        if (col == null) return;
        for (int i = 0; i < col.getChildCount() && i < 14; i++) {
            View v = col.getChildAt(i);
            v.setAlpha(0f);
            v.setTranslationX(px(44));
            v.animate().alpha(1f).translationX(0f).setStartDelay(40L * i).setDuration(380)
                    .setInterpolator(new DecelerateInterpolator()).start();
        }
    }

    // ------------------------------------------------------------------ construcción

    private void build() {
        layer = new FrameLayout(a);
        layer.setBackgroundColor(0x55000000);
        layer.setClickable(true);
        layer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                close();
            }
        });
        panel = new GlassView(a, px(34), 0x8A121A2C);
        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(px(620), -1, Gravity.END);
        pl.topMargin = px(24);
        pl.bottomMargin = px(24);
        pl.rightMargin = px(24);
        layer.addView(panel, pl);
        for (int i = 0; i < PAGES; i++) {
            ScrollView sv = new ScrollView(a);
            sv.setVerticalScrollBarEnabled(false);
            sv.setSmoothScrollingEnabled(true);
            sv.setClipToPadding(false);
            sv.setPadding(px(20), px(20), px(20), px(30));
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(LinearLayout.VERTICAL);
            sv.addView(col, new FrameLayout.LayoutParams(-1, -2));
            panel.addView(sv, new FrameLayout.LayoutParams(-1, -1));
            svs[i] = sv;
            cols[i] = col;
        }
        buildMain();
    }

    private void buildMain() {
        LinearLayout col = cols[0];
        col.removeAllViews();

        timeTv = a.text("", 52, 0xFFFFFFFF, MainActivity.LIGHT);
        dateTv = a.text("", 17, 0xB8FFFFFF, MainActivity.REG);
        LinearLayout.LayoutParams t1 = new LinearLayout.LayoutParams(-2, -2);
        t1.leftMargin = px(18);
        col.addView(timeTv, t1);
        LinearLayout.LayoutParams t2 = new LinearLayout.LayoutParams(-2, -2);
        t2.leftMargin = px(20);
        t2.bottomMargin = px(14);
        col.addView(dateTv, t2);

        IGroup g1 = group(col);
        rWifi = nav(g1, Glyph.WIFI, BLUE, s(R.string.set_wifi), new Runnable() {
            @Override
            public void run() {
                show(1, 0);
            }
        });
        rBt = nav(g1, Glyph.BT, BLUE, s(R.string.set_bt), new Runnable() {
            @Override
            public void run() {
                show(2, 0);
            }
        });

        IGroup g2 = group(col);
        rLock = nav(g2, Glyph.LOCK, INDIGO, s(R.string.set_lock), new Runnable() {
            @Override
            public void run() {
                show(3, 0);
            }
        });
        rWx = nav(g2, Glyph.WEATHER, ORANGE, s(R.string.set_weather), new Runnable() {
            @Override
            public void run() {
                show(4, 0);
            }
        });
        rWall = arrow(g2, Glyph.WALL, TEAL, s(R.string.set_wallpaper), new Get() {
            @Override
            public String get() {
                return s(MainActivity.WP_NAMES[a.st.wallpaper()]);
            }
        }, new Stp() {
            @Override
            public void step(int d) {
                int n = MainActivity.WP_NAMES.length;
                a.st.setWallpaper((a.st.wallpaper() + d + n) % n);
                a.applyWallpaper();
            }
        });

        IGroup g3 = group(col);
        swShelf = sw(g3, Glyph.SHELF, PURPLE, s(R.string.set_shelf), a.st.shelf(), new SwCb() {
            @Override
            public void on(boolean v) {
                a.st.setShelf(v);
                if (!v) a.setTint(0);
            }
        });
        swSound = sw(g3, Glyph.SOUND, RED, s(R.string.set_sound), a.st.sound(), new SwCb() {
            @Override
            public void on(boolean v) {
                a.st.setSound(v);
                a.sfx.enabled = v;
            }
        });
        swClock = sw(g3, Glyph.CLOCK, TEAL, s(R.string.set_h24), a.st.h24(), new SwCb() {
            @Override
            public void on(boolean v) {
                a.st.setH24(v);
                a.updateClock();
            }
        });

        IGroup g4 = group(col);
        rName = nav(g4, Glyph.USER, GRAY, s(R.string.set_name), new Runnable() {
            @Override
            public void run() {
                askName();
            }
        });
        rHidden = nav(g4, Glyph.HIDDEN, GREEN, s(R.string.set_hidden), new Runnable() {
            @Override
            public void run() {
                show(6, 0);
            }
        });
        rApps = nav(g4, Glyph.SHELF, BLUE, s(R.string.set_apps), new Runnable() {
            @Override
            public void run() {
                show(7, 0);
            }
        });
        rRam = nav(g4, Glyph.RAM, PINK, s(R.string.ram_tile), new Runnable() {
            @Override
            public void run() {
                freeRam();
            }
        });

        IGroup g5 = group(col);
        rDisp = nav(g5, Glyph.WALL, PURPLE, s(R.string.set_display), new Runnable() {
            @Override
            public void run() {
                show(9, 0);
            }
        });
        rSnd = nav(g5, Glyph.SOUND, RED, s(R.string.set_sound_audio), new Runnable() {
            @Override
            public void run() {
                show(10, 0);
            }
        });
        rDev = nav(g5, Glyph.DEVICE, GRAY, s(R.string.set_fire), new Runnable() {
            @Override
            public void run() {
                show(5, 0);
            }
        });
    }

    private void refreshMain() {
        if (timeTv == null) return;
        timeTv.setText(a.fmtTime());
        dateTv.setText(a.fmtDate());
        wifiStatus(rWifi);
        btStatus(rBt);
        rLock.setValue(a.st.lockOn() ? a.getString(R.string.lock_state, a.st.idleMin()) : s(R.string.lock_off));
        int n = a.st.places().size();
        rWx.setValue(n == 0 ? s(R.string.wx_off) : a.getString(R.string.wx_count, n));
        arrowRefresh(rWall, new Get() {
            @Override
            public String get() {
                return s(MainActivity.WP_NAMES[a.st.wallpaper()]);
            }
        });
        swShelf.setSwitch(a.st.shelf());
        swSound.setSwitch(a.st.sound());
        swClock.setSwitch(a.st.h24());
        String nm = a.st.name();
        rName.setValue(nm.isEmpty() ? s(R.string.name_none) : nm);
        int hid = a.st.hidden().size();
        rHidden.setValue(hid == 0 ? s(R.string.hidden_none) : a.getString(R.string.hidden_show, hid));
        rApps.setValue(storageText());
        try {
            ActivityManager am = (ActivityManager) a.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            rRam.setValue(a.getString(R.string.ram_sub, Formatter.formatFileSize(a, mi.availMem)));
        } catch (Throwable ignored) {
        }
    }

    private void wifiStatus(IRow r) {
        try {
            WifiManager w = wm();
            if (!w.isWifiEnabled()) {
                r.setStatus(false, s(R.string.wifi_status_off));
                return;
            }
            WifiInfo wi = w.getConnectionInfo();
            String ssid = wi == null ? null : wi.getSSID();
            boolean c = ssid != null && !ssid.contains("unknown") && wi.getNetworkId() != -1;
            r.setStatus(c, c ? ssid.replace("\"", "") : s(R.string.wifi_status_disc));
        } catch (Throwable t) {
            r.setStatus(false, "");
        }
    }

    private void btStatus(IRow r) {
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            if (ad == null) {
                r.setStatus(false, s(R.string.bt_na));
                return;
            }
            if (!ad.isEnabled()) {
                r.setStatus(false, s(R.string.bt_off));
                return;
            }
            int n = 0;
            for (BluetoothDevice d : ad.getBondedDevices()) {
                if (BtUtil.isConn(d)) n++;
            }
            r.setStatus(true, n > 0 ? a.getString(R.string.bt_n_conn, n) : s(R.string.bt_on));
        } catch (Throwable t) {
            r.setStatus(false, "");
        }
    }

    private String wifiIp() {
        try {
            int ip = wm().getConnectionInfo().getIpAddress();
            if (ip == 0) return "—";
            return (ip & 0xff) + "." + ((ip >> 8) & 0xff) + "." + ((ip >> 16) & 0xff) + "." + ((ip >> 24) & 0xff);
        } catch (Throwable t) {
            return "—";
        }
    }

    // ------------------------------------------------------------------ RAM y nombre

    private void freeRam() {
        try {
            final ActivityManager am = (ActivityManager) a.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            final long before = mi.availMem;
            for (AppItem x : a.apps) {
                try {
                    am.killBackgroundProcesses(x.pkg);
                } catch (Throwable ignored) {
                }
            }
            a.ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    ActivityManager.MemoryInfo m2 = new ActivityManager.MemoryInfo();
                    am.getMemoryInfo(m2);
                    long freed = m2.availMem - before;
                    if (freed > 4L * 1024 * 1024) {
                        a.toast(a.getString(R.string.ram_done, Formatter.formatFileSize(a, freed)));
                    } else {
                        a.toast(R.string.ram_ok);
                    }
                    if (open && page == 0) refreshMain();
                    if (open && page == 5) buildFire();
                }
            }, 900);
        } catch (Throwable ignored) {
        }
    }

    private void askName() {
        final EditText et = new EditText(a);
        et.setSingleLine(true);
        et.setText(a.st.name());
        et.setSelection(et.getText().length());
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(R.string.set_name)
                .setView(et)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        a.st.setName(et.getText().toString());
                        a.updateClock();
                        refreshMain();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    // ------------------------------------------------------------------ receptor Wi-Fi / Bluetooth

    private final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String act = i.getAction();
            if (act == null || !open) return;
            if (page == 1) {
                scanning = false;
                if (swWifi != null) swWifi.setSwitch(wm().isWifiEnabled());
                fillWifi();
            } else if (page == 2) {
                if (BluetoothDevice.ACTION_FOUND.equals(act)) {
                    BluetoothDevice d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    String nm = i.getStringExtra(BluetoothDevice.EXTRA_NAME);
                    if (d != null) onFound(d, nm);
                    return;
                } else if (BluetoothAdapter.ACTION_DISCOVERY_STARTED.equals(act)) {
                    discovering = true;
                    updateSearchRow();
                    return;
                } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(act)) {
                    discovering = false;
                    updateSearchRow();
                    return;
                } else if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(act)) {
                    BluetoothDevice d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    int st = i.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, -1);
                    if (d != null && st == BluetoothDevice.BOND_BONDED) {
                        BtUtil.setConnected(a, d, true);
                    }
                }
                if (swBt != null) swBt.setSwitch(btOn());
                fillBt();
            }
        }
    };

    private void register(int p) {
        IntentFilter f = new IntentFilter();
        if (p == 1) {
            f.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
            f.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
            f.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        } else {
            f.addAction(BluetoothDevice.ACTION_FOUND);
            f.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
            f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
            f.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
            f.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
            f.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
            f.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        }
        try {
            a.registerReceiver(rx, f);
            rxOn = true;
        } catch (Throwable ignored) {
        }
    }

    private void unregister() {
        if (!rxOn) return;
        try {
            a.unregisterReceiver(rx);
        } catch (Throwable ignored) {
        }
        rxOn = false;
    }

    // ------------------------------------------------------------------ ubicación (necesaria para buscar)

    private boolean locationOn() {
        try {
            return Settings.Secure.getInt(a.getContentResolver(), Settings.Secure.LOCATION_MODE) != 0;
        } catch (Throwable t) {
            return true;
        }
    }

    private void enableLocation() {
        try {
            Settings.Secure.putInt(a.getContentResolver(), Settings.Secure.LOCATION_MODE, 3);
        } catch (Throwable t) {
            a.toast(R.string.loc_adb);
            a.tryStart(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
        }
        if (page == 1) fillWifi();
        else if (page == 2) fillBt();
    }

    /** Filas de ayuda si falta el permiso de ubicación o está apagada la ubicación. */
    private void diagRows(LinearLayout body) {
        boolean perm = a.hasLocation();
        boolean loc = locationOn();
        if (perm && loc) return;
        label(body, s(R.string.diag_title));
        IGroup g = group(body);
        if (!perm) {
            IRow r = nav(g, Glyph.LOCK, ORANGE, s(R.string.diag_perm), new Runnable() {
                @Override
                public void run() {
                    a.ensureLocation();
                }
            });
            r.setStatus(false, s(R.string.diag_perm_v));
            r.setTag("diag:perm");
        }
        if (!loc) {
            IRow r = nav(g, Glyph.WEATHER, ORANGE, s(R.string.diag_loc), new Runnable() {
                @Override
                public void run() {
                    enableLocation();
                }
            });
            r.setStatus(false, s(R.string.diag_loc_v));
            r.setTag("diag:loc");
        }
    }

    // ------------------------------------------------------------------ Wi-Fi

    private void startScan() {
        if (!a.hasLocation()) return;
        try {
            scanning = wm().startScan();
        } catch (Throwable ignored) {
        }
    }

    private void buildWifi() {
        LinearLayout col = cols[1];
        col.removeAllViews();
        header(col, s(R.string.set_wifi));
        IGroup g = group(col);
        swWifi = sw(g, -1, 0, s(R.string.set_wifi), wm().isWifiEnabled(), new SwCb() {
            @Override
            public void on(boolean v) {
                try {
                    if (!wm().setWifiEnabled(v)) a.openWifiSettings();
                } catch (Throwable t) {
                    a.openWifiSettings();
                }
                a.ui.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (open && page == 1) {
                            swWifi.setSwitch(wm().isWifiEnabled());
                            startScan();
                            fillWifi();
                        }
                    }
                }, 1500);
            }
        });
        wifiBody = new LinearLayout(a);
        wifiBody.setOrientation(LinearLayout.VERTICAL);
        col.addView(wifiBody, new LinearLayout.LayoutParams(-1, -2));
        fillWifi();
    }

    private void fillWifi() {
        if (wifiBody == null || page != 1) return;
        String key = focusKey(wifiBody);
        wifiBody.removeAllViews();
        final WifiManager w = wm();
        if (!w.isWifiEnabled()) return;
        diagRows(wifiBody);

        String connected = null;
        int connLevel = 0;
        try {
            WifiInfo wi = w.getConnectionInfo();
            if (wi != null && wi.getSSID() != null && !wi.getSSID().contains("unknown") && wi.getNetworkId() != -1) {
                connected = wi.getSSID().replace("\"", "");
                connLevel = WifiManager.calculateSignalLevel(wi.getRssi(), 5);
            }
        } catch (Throwable ignored) {
        }

        HashMap<String, ScanResult> best = new HashMap<>();
        try {
            List<ScanResult> res = w.getScanResults();
            if (res != null) {
                for (ScanResult r : res) {
                    if (r.SSID == null || r.SSID.isEmpty()) continue;
                    ScanResult o = best.get(r.SSID);
                    if (o == null || r.level > o.level) best.put(r.SSID, r);
                }
            }
        } catch (Throwable ignored) {
        }
        ArrayList<ScanResult> list = new ArrayList<>(best.values());
        Collections.sort(list, new Comparator<ScanResult>() {
            @Override
            public int compare(ScanResult x, ScanResult y) {
                return y.level - x.level;
            }
        });

        label(wifiBody, s(R.string.wifi_networks));
        IGroup g = group(wifiBody);
        if (connected != null) {
            IRow r = new IRow(a, a.u, -1, 0, connected);
            g.add(r);
            WifiView wv = new WifiView(a);
            wv.setLevel(connLevel);
            r.setLead(wv, 26);
            r.setStatus(true, a.getString(R.string.wifi_connected, wifiIp()));
            r.setTag("net:" + connected);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    a.toast(R.string.wifi_already);
                }
            });
            list.remove(best.get(connected));
        }
        for (final ScanResult r : list) {
            final boolean sec = isSecure(r);
            IRow row = new IRow(a, a.u, -1, 0, r.SSID);
            g.add(row);
            WifiView wv = new WifiView(a);
            wv.setLevel(WifiManager.calculateSignalLevel(r.level, 5));
            row.setLead(wv, 26);
            row.setStatus(false, s(sec ? R.string.wifi_secure : R.string.wifi_open));
            row.setTag("net:" + r.SSID);
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    a.sfx.play(Sfx.SELECT);
                    connectTo(r.SSID, sec);
                }
            });
        }
        if (connected == null && list.isEmpty()) {
            IRow r = new IRow(a, a.u, -1, 0, s(scanning ? R.string.wifi_searching : R.string.wifi_none));
            r.setFocusable(false);
            r.setClickable(false);
            g.add(r);
        }
        IGroup g2 = group(wifiBody);
        IRow rs = nav(g2, -1, 0, s(R.string.wifi_rescan), new Runnable() {
            @Override
            public void run() {
                if (!a.hasLocation()) {
                    a.ensureLocation();
                    return;
                }
                startScan();
                a.toast(R.string.wifi_searching);
            }
        });
        rs.setTag("rescan");
        restoreFocus(wifiBody, key);
    }

    private static boolean isSecure(ScanResult r) {
        String c = r.capabilities == null ? "" : r.capabilities;
        return c.contains("WPA") || c.contains("WEP") || c.contains("PSK") || c.contains("EAP") || c.contains("SAE");
    }

    private void connectTo(final String ssid, boolean secure) {
        try {
            List<WifiConfiguration> saved = wm().getConfiguredNetworks();
            if (saved != null) {
                for (WifiConfiguration c : saved) {
                    if (c.SSID != null && c.SSID.equals("\"" + ssid + "\"")) {
                        join(c.networkId);
                        return;
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        if (!secure) {
            addAndJoin(ssid, null);
            return;
        }
        final EditText et = new EditText(a);
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(a.getString(R.string.wifi_pw_title, ssid))
                .setView(et)
                .setPositiveButton(R.string.wifi_connect, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        addAndJoin(ssid, et.getText().toString());
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void addAndJoin(String ssid, String pwd) {
        try {
            WifiConfiguration c = new WifiConfiguration();
            c.SSID = "\"" + ssid + "\"";
            if (pwd == null) {
                c.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
            } else {
                c.preSharedKey = "\"" + pwd + "\"";
            }
            int id = wm().addNetwork(c);
            if (id < 0) {
                a.toast(R.string.wifi_fail);
                a.openWifiSettings();
                return;
            }
            join(id);
        } catch (Throwable t) {
            a.toast(R.string.wifi_fail);
            a.openWifiSettings();
        }
    }

    private void join(int id) {
        try {
            WifiManager w = wm();
            w.disconnect();
            boolean ok = w.enableNetwork(id, true);
            w.reconnect();
            a.toast(ok ? R.string.wifi_connecting : R.string.wifi_fail);
        } catch (Throwable t) {
            a.toast(R.string.wifi_fail);
        }
    }

    // ------------------------------------------------------------------ Bluetooth

    private boolean btOn() {
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            return ad != null && ad.isEnabled();
        } catch (Throwable t) {
            return false;
        }
    }

    private void stopDiscovery() {
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            if (ad != null && ad.isDiscovering()) ad.cancelDiscovery();
        } catch (Throwable ignored) {
        }
        discovering = false;
    }

    private void buildBt() {
        LinearLayout col = cols[2];
        col.removeAllViews();
        found.clear();
        foundName.clear();
        foundShown.clear();
        discovering = false;
        header(col, s(R.string.set_bt));
        IGroup g = group(col);
        swBt = sw(g, -1, 0, s(R.string.set_bt), btOn(), new SwCb() {
            @Override
            public void on(boolean v) {
                try {
                    BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
                    if (ad == null) {
                        a.openBluetoothSettings();
                    } else if (!v) {
                        stopDiscovery();
                        ad.disable();
                    } else {
                        ad.enable();
                    }
                } catch (Throwable t) {
                    a.openBluetoothSettings();
                }
                a.ui.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (open && page == 2) {
                            swBt.setSwitch(btOn());
                            fillBt();
                        }
                    }
                }, 1500);
            }
        });
        btBody = new LinearLayout(a);
        btBody.setOrientation(LinearLayout.VERTICAL);
        col.addView(btBody, new LinearLayout.LayoutParams(-1, -2));
        fillBt();
    }

    private void fillBt() {
        if (btBody == null || page != 2) return;
        String key = focusKey(btBody);
        btBody.removeAllViews();
        rSearch = null;
        btOther = null;
        foundShown.clear();
        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null || !ad.isEnabled()) {
            label(btBody, s(ad == null ? R.string.bt_na : R.string.bt_off_hint));
            return;
        }
        diagRows(btBody);

        label(btBody, s(R.string.bt_my));
        IGroup my = group(btBody);
        ArrayList<BluetoothDevice> bonded = new ArrayList<>();
        try {
            bonded.addAll(ad.getBondedDevices());
        } catch (Throwable ignored) {
        }
        Collections.sort(bonded, new Comparator<BluetoothDevice>() {
            @Override
            public int compare(BluetoothDevice x, BluetoothDevice y) {
                return (BtUtil.isConn(y) ? 1 : 0) - (BtUtil.isConn(x) ? 1 : 0);
            }
        });
        if (bonded.isEmpty()) {
            IRow r = new IRow(a, a.u, -1, 0, s(R.string.bt_none));
            r.setFocusable(false);
            r.setClickable(false);
            my.add(r);
        }
        for (final BluetoothDevice d : bonded) {
            boolean conn = BtUtil.isConn(d);
            IRow r = new IRow(a, a.u, Glyph.BT, BLUE, BtUtil.nameOf(d));
            my.add(r);
            r.setStatus(conn, s(conn ? R.string.bt_connected : R.string.bt_disconnected));
            r.setTag("bt:" + d.getAddress());
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    a.sfx.play(Sfx.SELECT);
                    deviceMenu(d);
                }
            });
        }

        label(btBody, s(R.string.bt_other));
        btOther = group(btBody);
        rSearch = new IRow(a, a.u, -1, 0, "");
        btOther.add(rSearch);
        rSearch.setTag("search");
        rSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.sfx.play(Sfx.SELECT);
                startSearch();
            }
        });
        updateSearchRow();
        for (BluetoothDevice d : found) addFoundRow(d);
        restoreFocus(btBody, key);
    }

    private void updateSearchRow() {
        if (rSearch == null) return;
        rSearch.title.setText(s(discovering ? R.string.bt_searching : (found.isEmpty() ? R.string.bt_search
                : R.string.bt_search_again)));
        rSearch.setStatus(discovering, discovering ? "…" : "");
    }

    private void onFound(BluetoothDevice d, String nm) {
        String addr = d.getAddress();
        if (nm != null && !nm.isEmpty()) foundName.put(addr, nm);
        boolean named = foundName.containsKey(addr) || BtUtil.hasName(d);
        if (!named) return;
        if (!found.contains(d)) found.add(d);
        if (btOther == null) return;
        try {
            if (d.getBondState() == BluetoothDevice.BOND_BONDED) return;
        } catch (Throwable ignored) {
        }
        addFoundRow(d);
    }

    private void addFoundRow(final BluetoothDevice d) {
        if (btOther == null) return;
        String addr = d.getAddress();
        if (foundShown.contains(addr)) return;
        try {
            if (d.getBondState() == BluetoothDevice.BOND_BONDED) return;
        } catch (Throwable ignored) {
        }
        foundShown.add(addr);
        String nm = foundName.containsKey(addr) ? foundName.get(addr) : BtUtil.nameOf(d);
        IRow r = new IRow(a, a.u, Glyph.BT, GRAY, nm);
        btOther.add(r);
        r.setValue(s(R.string.bt_tap_pair));
        r.setTag("found:" + addr);
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.sfx.play(Sfx.SELECT);
                try {
                    stopDiscovery();
                    updateSearchRow();
                    boolean ok = d.createBond();
                    a.toast(ok ? R.string.bt_pairing : R.string.bt_pair_fail);
                } catch (Throwable t) {
                    a.openBluetoothSettings();
                }
            }
        });
    }

    private void startSearch() {
        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null || !ad.isEnabled()) return;
        if (!a.hasLocation()) {
            a.ensureLocation();
            return;
        }
        if (!locationOn()) enableLocation();
        try {
            if (ad.isDiscovering()) ad.cancelDiscovery();
            found.clear();
            foundName.clear();
            discovering = true;
            fillBt();
            boolean ok = ad.startDiscovery();
            if (!ok) {
                discovering = false;
                updateSearchRow();
                a.toast(R.string.bt_search_fail);
            }
        } catch (Throwable t) {
            discovering = false;
            updateSearchRow();
            a.toast(R.string.bt_search_fail);
        }
    }

    private void deviceMenu(final BluetoothDevice d) {
        final boolean conn = BtUtil.isConn(d);
        CharSequence[] items = {s(conn ? R.string.bt_disconnect : R.string.bt_connect), s(R.string.bt_forget_yes)};
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(BtUtil.nameOf(d))
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dlg, int which) {
                        if (which == 0) {
                            BtUtil.setConnected(a, d, !conn);
                            a.toast(conn ? R.string.bt_disconnecting : R.string.bt_conn_try);
                            refreshBtLater(1800);
                            refreshBtLater(5000);
                        } else {
                            askForget(d);
                        }
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void refreshBtLater(long ms) {
        a.ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (open && page == 2) fillBt();
                a.updateBt();
            }
        }, ms);
    }

    private void askForget(final BluetoothDevice d) {
        String n = BtUtil.nameOf(d);
        String low = n.toLowerCase();
        if (low.contains("remote") || low.contains("mando")) {
            a.toast(R.string.bt_protected);
            return;
        }
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(a.getString(R.string.bt_forget, n))
                .setPositiveButton(R.string.bt_forget_yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface x, int w) {
                        try {
                            d.getClass().getMethod("removeBond").invoke(d);
                        } catch (Throwable t) {
                            a.openBluetoothSettings();
                        }
                        refreshBtLater(900);
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    // ------------------------------------------------------------------ pantalla de bloqueo

    private void buildLock() {
        LinearLayout col = cols[3];
        col.removeAllViews();
        header(col, s(R.string.set_lock));
        IGroup g = group(col);
        sw(g, Glyph.LOCK, INDIGO, s(R.string.lock_enable), a.st.lockOn(), new SwCb() {
            @Override
            public void on(boolean v) {
                a.st.setLockOn(v);
                a.resetIdle();
            }
        });
        arrow(g, Glyph.CLOCK, TEAL, s(R.string.lock_wait), new Get() {
            @Override
            public String get() {
                return a.getString(R.string.idle_min, a.st.idleMin());
            }
        }, new Stp() {
            @Override
            public void step(int d) {
                int idx = 0;
                for (int i = 0; i < IDLE_OPTS.length; i++) {
                    if (IDLE_OPTS[i] == a.st.idleMin()) idx = i;
                }
                idx = (idx + d + IDLE_OPTS.length) % IDLE_OPTS.length;
                a.st.setIdleMin(IDLE_OPTS[idx]);
                a.resetIdle();
            }
        });
        sw(g, Glyph.WEATHER, ORANGE, s(R.string.lock_wx), a.st.wxLock(), new SwCb() {
            @Override
            public void on(boolean v) {
                a.st.setWxLock(v);
                a.updateWeatherViews();
            }
        });
        IGroup g2 = group(col);
        nav(g2, Glyph.WALL, TEAL, s(R.string.lock_preview), new Runnable() {
            @Override
            public void run() {
                a.previewLock();
            }
        });
        TextView note = a.text(s(R.string.lock_note), 15, 0x99FFFFFF, MainActivity.REG);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = px(18);
        lp.topMargin = px(6);
        col.addView(note, lp);
    }

    // ------------------------------------------------------------------ tiempo

    private void buildWeather() {
        LinearLayout col = cols[4];
        col.removeAllViews();
        header(col, s(R.string.set_weather));
        IGroup g = group(col);
        sw(g, Glyph.WEATHER, ORANGE, s(R.string.wx_home), a.st.wxHome(), new SwCb() {
            @Override
            public void on(boolean v) {
                a.st.setWxHome(v);
                a.updateWeatherViews();
                if (v) a.refreshWeather(false);
            }
        });
        sw(g, Glyph.LOCK, INDIGO, s(R.string.lock_wx), a.st.wxLock(), new SwCb() {
            @Override
            public void on(boolean v) {
                a.st.setWxLock(v);
                a.updateWeatherViews();
            }
        });
        sw(g, Glyph.WEATHER, RED, s(R.string.wx_fahr), a.st.fahrenheit(), new SwCb() {
            @Override
            public void on(boolean v) {
                a.st.setFahrenheit(v);
                a.updateWeatherViews();
            }
        });
        label(col, s(R.string.wx_places));
        IGroup pg = group(col);
        final List<String[]> places = a.st.places();
        for (final String[] p : places) {
            IRow r = new IRow(a, a.u, Glyph.WEATHER, ORANGE, p[0]);
            pg.add(r);
            r.setValue(p[1]);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    a.sfx.play(Sfx.SELECT);
                    askRemovePlace(p);
                }
            });
        }
        IRow add = nav(pg, -1, 0, "+  " + s(R.string.wx_add), new Runnable() {
            @Override
            public void run() {
                if (a.st.places().size() >= 6) {
                    a.toast(R.string.wx_max);
                    return;
                }
                askPlace();
            }
        });
        add.setTag("addplace");
    }

    private void askRemovePlace(final String[] p) {
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(a.getString(R.string.wx_remove, p[0]))
                .setPositiveButton(R.string.wx_remove_yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        ArrayList<String[]> l = new ArrayList<>(a.st.places());
                        for (int i = 0; i < l.size(); i++) {
                            if (Weather.key(l.get(i)).equals(Weather.key(p))) {
                                l.remove(i);
                                break;
                            }
                        }
                        a.st.setPlaces(l);
                        a.updateWeatherViews();
                        if (open && page == 4) buildWeather();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void askPlace() {
        final EditText et = new EditText(a);
        et.setSingleLine(true);
        et.setHint(R.string.wx_hint);
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(R.string.wx_add)
                .setView(et)
                .setPositiveButton(R.string.wx_search, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String q = et.getText().toString().trim();
                        if (!q.isEmpty()) searchPlace(q);
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void searchPlace(String q) {
        a.toast(R.string.wx_searching);
        a.wx.search(q, new Weather.Found() {
            @Override
            public void found(final List<Weather.Hit> hits, boolean error) {
                if (error) {
                    a.toast(R.string.wx_error);
                    return;
                }
                if (hits.isEmpty()) {
                    a.toast(R.string.wx_none);
                    return;
                }
                CharSequence[] labels = new CharSequence[hits.size()];
                for (int i = 0; i < labels.length; i++) labels[i] = hits.get(i).label();
                new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                        .setTitle(R.string.wx_pick)
                        .setItems(labels, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dlg, int which) {
                                addPlace(hits.get(which));
                            }
                        })
                        .setNegativeButton(android.R.string.cancel, null)
                        .show();
            }
        });
    }

    private void addPlace(Weather.Hit h) {
        ArrayList<String[]> l = new ArrayList<>(a.st.places());
        String[] p = {h.name, h.country, String.valueOf(h.lat), String.valueOf(h.lon)};
        for (String[] x : l) {
            if (Weather.key(x).equals(Weather.key(p))) return;
        }
        l.add(p);
        a.st.setPlaces(l);
        a.refreshWeather(true);
        a.updateWeatherViews();
        a.toast(R.string.wx_added);
        if (open && page == 4) buildWeather();
    }

    // ------------------------------------------------------------------ dispositivo

    private IRow info(IGroup g, String title, String value) {
        IRow r = new IRow(a, a.u, -1, 0, title);
        r.setFocusable(false);
        r.setClickable(false);
        r.setValue(value);
        g.add(r);
        return r;
    }

    // ================================================================== v2.3: apps, pantalla, sonido, Mi Fire TV

    private boolean hiddenDirty;
    private int iconGen;
    private String selPkg = "", selLabel = "";
    private IRow rApps, rDisp, rSnd;

    private void flushHidden() {
        if (hiddenDirty) {
            hiddenDirty = false;
            a.refreshHome();
        }
    }

    private boolean go(Intent... l) {
        return a.tryStart(l);
    }

    private Intent display() {
        return new Intent(Settings.ACTION_DISPLAY_SETTINGS);
    }

    private void loadIcons(final List<String> pkgs, final List<ImageView> views) {
        final int gen = ++iconGen;
        new Thread(new Runnable() {
            @Override
            public void run() {
                PackageManager pm = a.getPackageManager();
                for (int i = 0; i < pkgs.size(); i++) {
                    if (gen != iconGen) return;
                    try {
                        final Drawable d = pm.getApplicationIcon(pkgs.get(i));
                        final ImageView v = views.get(i);
                        a.ui.post(new Runnable() {
                            @Override
                            public void run() {
                                v.setImageDrawable(d);
                            }
                        });
                    } catch (Throwable ignored) {
                    }
                }
            }
        }).start();
    }

    private ImageView iconSlot() {
        ImageView iv = new ImageView(a);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        return iv;
    }

    private String storageText() {
        try {
            StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
            return a.getString(R.string.sys_free_of, Formatter.formatFileSize(a, sf.getAvailableBytes()),
                    Formatter.formatFileSize(a, sf.getTotalBytes()));
        } catch (Throwable t) {
            return s(R.string.fire_na);
        }
    }

    private void storageBar(LinearLayout col) {
        try {
            StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
            float total = sf.getTotalBytes();
            float used = total - sf.getAvailableBytes();
            LinearLayout bar = new LinearLayout(a);
            bar.setOrientation(LinearLayout.HORIZONTAL);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0x33FFFFFF);
            bg.setCornerRadius(px(5));
            bar.setBackground(bg);
            View fill = new View(a);
            GradientDrawable fg = new GradientDrawable();
            fg.setColor(BLUE);
            fg.setCornerRadius(px(5));
            fill.setBackground(fg);
            float frac = total <= 0 ? 0f : Math.max(0.02f, Math.min(1f, used / total));
            bar.addView(fill, new LinearLayout.LayoutParams(0, -1, frac));
            bar.addView(new View(a), new LinearLayout.LayoutParams(0, -1, 1f - frac));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, px(10));
            lp.leftMargin = px(18);
            lp.rightMargin = px(18);
            lp.bottomMargin = px(12);
            col.addView(bar, lp);
        } catch (Throwable ignored) {
        }
    }

    // ---- Apps ocultas (lista de todas las apps; interruptor activado = oculta en Inicio)

    private void buildHidden() {
        LinearLayout col = cols[6];
        col.removeAllViews();
        header(col, s(R.string.set_hidden));
        label(col, s(R.string.hid_hint));
        IGroup g = group(col);
        Set<String> hid = a.st.hidden();
        ArrayList<String> pk = new ArrayList<>();
        ArrayList<ImageView> iv = new ArrayList<>();
        for (final AppItem it : a.apps) {
            final IRow r = new IRow(a, a.u, -1, 0, it.label);
            g.add(r);
            r.setTag("h:" + it.pkg);
            ImageView im = iconSlot();
            r.setLead(im, 38);
            r.setSwitch(hid.contains(it.pkg));
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    a.sfx.play(Sfx.TOGGLE);
                    boolean nv = !r.isOn();
                    r.setSwitch(nv);
                    HashSet<String> h = new HashSet<>(a.st.hidden());
                    if (nv) h.add(it.pkg);
                    else h.remove(it.pkg);
                    a.st.setHidden(h);
                    hiddenDirty = true;
                }
            });
            pk.add(it.pkg);
            iv.add(im);
        }
        loadIcons(pk, iv);
    }

    // ---- Apps instaladas

    private void buildApps() {
        final LinearLayout col = cols[7];
        col.removeAllViews();
        header(col, s(R.string.set_apps));
        IGroup gs = group(col);
        info(gs, s(R.string.apps_storage), storageText());
        storageBar(col);
        final TextView loading = label(col, s(R.string.apps_loading));
        new Thread(new Runnable() {
            @Override
            public void run() {
                PackageManager pm = a.getPackageManager();
                final ArrayList<String[]> list = new ArrayList<>();
                try {
                    for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
                        boolean sys = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                        if (sys && pm.getLaunchIntentForPackage(ai.packageName) == null
                                && pm.getLeanbackLaunchIntentForPackage(ai.packageName) == null) continue;
                        CharSequence l = pm.getApplicationLabel(ai);
                        list.add(new String[]{ai.packageName, l == null ? ai.packageName : l.toString(),
                                sys ? "1" : "0"});
                    }
                } catch (Throwable ignored) {
                }
                Collections.sort(list, new Comparator<String[]>() {
                    @Override
                    public int compare(String[] x, String[] y) {
                        return x[1].compareToIgnoreCase(y[1]);
                    }
                });
                a.ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (!open || page != 7) return;
                        col.removeView(loading);
                        IGroup g = group(col);
                        ArrayList<String> pk = new ArrayList<>();
                        ArrayList<ImageView> iv = new ArrayList<>();
                        for (final String[] it : list) {
                            IRow r = new IRow(a, a.u, -1, 0, it[1]);
                            g.add(r);
                            r.setTag("a:" + it[0]);
                            ImageView im = iconSlot();
                            r.setLead(im, 38);
                            if ("1".equals(it[2])) r.setValue(s(R.string.app_system));
                            r.setChevron();
                            r.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    a.sfx.play(Sfx.SELECT);
                                    selPkg = it[0];
                                    selLabel = it[1];
                                    show(8, 7);
                                }
                            });
                            pk.add(it[0]);
                            iv.add(im);
                        }
                        loadIcons(pk, iv);
                        String key = lastAppKey;
                        if (key != null) {
                            View v = findTag(col, key);
                            if (v != null) v.requestFocus();
                        }
                    }
                });
            }
        }).start();
    }

    private String lastAppKey;

    private void buildAppDetail() {
        LinearLayout col = cols[8];
        col.removeAllViews();
        lastAppKey = "a:" + selPkg;
        header(col, selLabel);
        PackageManager pm = a.getPackageManager();
        IGroup gi = group(col);
        try {
            PackageInfo pi = pm.getPackageInfo(selPkg, 0);
            info(gi, s(R.string.app_version), pi.versionName == null ? "-" : pi.versionName);
        } catch (Throwable ignored) {
        }
        info(gi, s(R.string.app_pkg), selPkg);

        IGroup g = group(col);
        nav(g, Glyph.SHELF, BLUE, s(R.string.app_open), new Runnable() {
            @Override
            public void run() {
                PackageManager p = a.getPackageManager();
                Intent i = p.getLeanbackLaunchIntentForPackage(selPkg);
                if (i == null) i = p.getLaunchIntentForPackage(selPkg);
                if (i == null) a.toast(R.string.toast_fail);
                else go(i);
            }
        });
        IGroup g2 = group(col);
        nav(g2, Glyph.RAM, ORANGE, s(R.string.app_cache), new Runnable() {
            @Override
            public void run() {
                clearCache();
            }
        });
        nav(g2, Glyph.HIDDEN, PURPLE, s(R.string.app_data), new Runnable() {
            @Override
            public void run() {
                new AlertDialog.Builder(a)
                        .setTitle(a.getString(R.string.data_confirm, selLabel))
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                a.toast(R.string.data_manual);
                                openAppInfo();
                            }
                        })
                        .setNegativeButton(android.R.string.cancel, null)
                        .show();
            }
        });
        nav(g2, Glyph.GEAR, RED, s(R.string.app_stop), new Runnable() {
            @Override
            public void run() {
                try {
                    ActivityManager am = (ActivityManager) a.getSystemService(Context.ACTIVITY_SERVICE);
                    am.killBackgroundProcesses(selPkg);
                    a.toast(a.getString(R.string.stop_done, selLabel));
                } catch (Throwable t) {
                    a.toast(R.string.toast_fail);
                }
            }
        });
        IGroup g3 = group(col);
        nav(g3, Glyph.LOCK, GREEN, s(R.string.app_perms), new Runnable() {
            @Override
            public void run() {
                Intent p = new Intent("android.intent.action.MANAGE_APP_PERMISSIONS");
                p.putExtra("android.intent.extra.PACKAGE_NAME", selPkg);
                go(p, new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", selPkg, null)));
            }
        });
        nav(g3, Glyph.DEVICE, GRAY, s(R.string.app_info), new Runnable() {
            @Override
            public void run() {
                openAppInfo();
            }
        });
        IGroup g4 = group(col);
        nav(g4, Glyph.HIDDEN, RED, s(R.string.app_uninstall), new Runnable() {
            @Override
            public void run() {
                Intent d = new Intent(Intent.ACTION_DELETE, Uri.fromParts("package", selPkg, null));
                go(d, new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", selPkg, null)));
            }
        });
    }

    private void openAppInfo() {
        go(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", selPkg, null)));
    }

    private void clearCache() {
        try {
            PackageManager pm = a.getPackageManager();
            Class<?> obs = Class.forName("android.content.pm.IPackageDataObserver");
            java.lang.reflect.Method m = PackageManager.class.getMethod("deleteApplicationCacheFiles",
                    String.class, obs);
            m.invoke(pm, selPkg, null);
            a.toast(R.string.cache_done);
        } catch (Throwable t) {
            a.toast(R.string.cache_manual);
            openAppInfo();
        }
    }

    // ---- Pantalla

    private String hdrText(Display d) {
        try {
            if (Build.VERSION.SDK_INT >= 24) {
                Display.HdrCapabilities hc = d.getHdrCapabilities();
                if (hc != null && hc.getSupportedHdrTypes().length > 0) {
                    StringBuilder sb = new StringBuilder();
                    for (int t : hc.getSupportedHdrTypes()) {
                        String n = t == 1 ? "Dolby Vision" : t == 2 ? "HDR10" : t == 3 ? "HLG" : t == 4 ? "HDR10+" : null;
                        if (n == null) continue;
                        if (sb.length() > 0) sb.append(" · ");
                        sb.append(n);
                    }
                    if (sb.length() > 0) return sb.toString();
                }
            }
        } catch (Throwable ignored) {
        }
        return s(R.string.disp_sdr);
    }

    private boolean quiet(Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            a.startActivity(i);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Fila que abre la pantalla de ajustes del sistema cuyo nombre contiene alguna palabra; si no, la lista. */
    private IRow sysKw(IGroup g, int glyph, int color, String title, String value, final String... kws) {
        return sysOpen(g, glyph, color, title, value, false, kws);
    }

    /**
     * Fila que abre la pantalla de ajustes del sistema. Orden: pantalla de Fire OS cuyo nombre encaja,
     * pantalla estándar de Android y, si nada existe, los ajustes principales de Fire TV. Nunca falla en silencio.
     */
    private IRow sysOpen(IGroup g, int glyph, int color, String title, String value, final boolean sound,
                         final String... kws) {
        IRow r = nav(g, glyph, color, title, new Runnable() {
            @Override
            public void run() {
                Intent i = FireSettings.find(a, kws);
                if (i != null && quiet(i)) return;
                for (Intent f : FireSettings.fallbacks(sound)) {
                    if (quiet(f)) return;
                }
                a.toast(R.string.toast_fail);
            }
        });
        if (value != null) r.setValue(value);
        return r;
    }

    private void needGrant() {
        new AlertDialog.Builder(a)
                .setTitle(R.string.grant_title)
                .setMessage(R.string.grant_msg)
                .setPositiveButton(android.R.string.ok, null)
                .show();
    }

    private String sleepLabel(int ms) {
        if (ms <= 0 || ms >= 86400000) return s(R.string.sleep_never);
        int m = ms / 60000;
        if (m >= 60 && m % 60 == 0) return a.getString(R.string.sleep_h, m / 60);
        return a.getString(R.string.idle_min, Math.max(1, m));
    }

    private int sleepNow() {
        try {
            return Settings.System.getInt(a.getContentResolver(), Settings.System.SCREEN_OFF_TIMEOUT);
        } catch (Throwable t) {
            return 0;
        }
    }

    private final int[] SLEEP_MS = {300000, 600000, 900000, 1800000, 3600000, 7200000, 86400000};

    /** Selector de suspensión dentro de Prisma. */
    private void chooseSleep(final Runnable after) {
        CharSequence[] items = new CharSequence[SLEEP_MS.length];
        int cur = -1;
        int now = sleepNow();
        for (int i = 0; i < SLEEP_MS.length; i++) {
            items[i] = sleepLabel(SLEEP_MS[i]);
            if (SLEEP_MS[i] == now) cur = i;
        }
        new AlertDialog.Builder(a)
                .setTitle(R.string.disp_sleep)
                .setSingleChoiceItems(items, cur, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        d.dismiss();
                        int ms = SLEEP_MS[which];
                        boolean ok = FireSettings.putSystem(a, Settings.System.SCREEN_OFF_TIMEOUT, ms);
                        ok = FireSettings.putSecure(a, "sleep_timeout", ms) || ok;
                        if (!ok) needGrant();
                        if (after != null) after.run();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void buildDisplay() {
        LinearLayout col = cols[9];
        col.removeAllViews();
        header(col, s(R.string.set_display));
        Display d = a.getWindowManager().getDefaultDisplay();
        String res = "";
        String hz = Math.round(d.getRefreshRate()) + " Hz";
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                Display.Mode m = d.getMode();
                res = m.getPhysicalWidth() + "×" + m.getPhysicalHeight();
            } else {
                android.graphics.Point pt = new android.graphics.Point();
                d.getRealSize(pt);
                res = pt.x + "×" + pt.y;
            }
        } catch (Throwable ignored) {
        }
        IGroup g = group(col);
        sysKw(g, Glyph.DEVICE, BLUE, s(R.string.disp_res), res, "resolution", "display", "video");
        sysKw(g, Glyph.CLOCK, TEAL, s(R.string.disp_fps), hz, "framerate", "frame_rate", "display", "video");
        sysKw(g, Glyph.WALL, PURPLE, s(R.string.disp_depth), null, "colordepth", "color", "display");
        sysKw(g, Glyph.SHELF, PINK, s(R.string.disp_format), null, "colorformat", "color", "display");
        IGroup g2 = group(col);
        sysKw(g2, Glyph.GEAR, GRAY, s(R.string.disp_calib), null, "calibrat", "display");
        sysKw(g2, Glyph.WEATHER, ORANGE, s(R.string.disp_hdr), hdrText(d), "hdr", "dynamic", "display");
        IGroup g3 = group(col);
        final IRow slp = nav(g3, Glyph.LOCK, INDIGO, s(R.string.disp_sleep), null);
        slp.setValue(sleepLabel(sleepNow()));
        slp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.sfx.play(Sfx.SELECT);
                chooseSleep(new Runnable() {
                    @Override
                    public void run() {
                        slp.setValue(sleepLabel(sleepNow()));
                    }
                });
            }
        });
        label(col, s(R.string.disp_note));
    }

    // ---- Sonido

    private boolean cecOn() {
        try {
            return Settings.Global.getInt(a.getContentResolver(), "hdmi_control_enabled", 1) == 1;
        } catch (Throwable t) {
            return true;
        }
    }

    private int surroundMode() {
        try {
            return Settings.Global.getInt(a.getContentResolver(), "encoded_surround_output", 0);
        } catch (Throwable t) {
            return 0;
        }
    }

    private String surroundFormats() {
        try {
            String f = Settings.Global.getString(a.getContentResolver(), "encoded_surround_output_enabled_formats");
            return f == null ? "" : f;
        } catch (Throwable t) {
            return "";
        }
    }

    /** 0 = mejor calidad, 1 = PCM, 2 = Dolby Digital Plus, 3 = Dolby Digital. */
    private void setSurround(int which) {
        boolean ok;
        if (which == 0) ok = FireSettings.putGlobal(a, "encoded_surround_output", 0);
        else if (which == 1) ok = FireSettings.putGlobal(a, "encoded_surround_output", 1);
        else {
            ok = FireSettings.putGlobal(a, "encoded_surround_output_enabled_formats", which == 2 ? "6" : "5");
            ok = FireSettings.putGlobal(a, "encoded_surround_output", 3) && ok;
        }
        if (!ok) needGrant();
        buildSound();
        View f = findTag(cols[10], "snd" + which);
        if (f != null) f.requestFocus();
    }

    private void buildSound() {
        LinearLayout col = cols[10];
        col.removeAllViews();
        header(col, s(R.string.set_sound_audio));
        IGroup g = group(col);
        sw(g, Glyph.SOUND, RED, s(R.string.snd_nav), a.st.sound(), new SwCb() {
            @Override
            public void on(boolean v) {
                a.st.setSound(v);
                a.sfx.enabled = v;
            }
        });

        label(col, s(R.string.snd_surround));
        boolean ac3 = false, eac3 = false;
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                AudioManager am = (AudioManager) a.getSystemService(Context.AUDIO_SERVICE);
                for (AudioDeviceInfo di : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                    if (di.getType() != AudioDeviceInfo.TYPE_HDMI) continue;
                    for (int e : di.getEncodings()) {
                        if (e == 5) ac3 = true;
                        if (e == 6) eac3 = true;
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        int mode = surroundMode();
        String fm = surroundFormats();
        int sel = mode == 0 ? 0 : mode == 1 ? 1 : fm.contains("6") ? 2 : fm.contains("5") ? 3 : 0;
        String[] names = {s(R.string.snd_best), s(R.string.snd_pcm), s(R.string.snd_ddp), s(R.string.snd_dd)};
        boolean[] sup = {true, true, eac3, ac3};
        int[] cols2 = {BLUE, GRAY, PURPLE, PINK};
        IGroup g2 = group(col);
        for (int i = 0; i < 4; i++) {
            final int w = i;
            IRow r = new IRow(a, a.u, Glyph.SOUND, cols2[i], names[i]);
            g2.add(r);
            r.setTag("snd" + i);
            r.setStatus(sel == i, sel == i ? s(R.string.snd_active) : (sup[i] ? s(R.string.snd_ok) : s(R.string.snd_no)));
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    a.sfx.play(Sfx.SELECT);
                    setSurround(w);
                }
            });
        }

        IGroup g3 = group(col);
        sw(g3, Glyph.DEVICE, TEAL, s(R.string.snd_cec), cecOn(), new SwCb() {
            @Override
            public void on(boolean v) {
                if (!FireSettings.putGlobal(a, "hdmi_control_enabled", v ? 1 : 0)) {
                    needGrant();
                    buildSound();
                }
            }
        });
        IGroup g4 = group(col);
        sysOpen(g4, Glyph.SOUND, BLUE, s(R.string.snd_more), null, true, "sound", "audio");
        label(col, s(R.string.snd_note));
    }

    // ---- Pantallas del sistema (lista de todo lo que ofrece Fire OS)

    private void buildScreens() {
        LinearLayout col = cols[11];
        col.removeAllViews();
        header(col, s(R.string.set_screens));
        label(col, s(R.string.scr_hint));
        IGroup g = group(col);
        List<FireSettings.Screen> all = FireSettings.screens(a);
        if (all.isEmpty()) {
            info(g, s(R.string.scr_empty), "");
            return;
        }
        for (final FireSettings.Screen sc : all) {
            IRow r = nav(g, Glyph.GEAR, GRAY, sc.name, new Runnable() {
                @Override
                public void run() {
                    if (!quiet(FireSettings.intentFor(sc))) a.toast(R.string.toast_fail);
                }
            });
            r.setValue(sc.pkg.replace("com.amazon.tv.", "").replace("com.android.", ""));
        }
    }

    private IRow sysIntent(IGroup g, int glyph, int color, String title, final Intent... it) {
        return nav(g, glyph, color, title, new Runnable() {
            @Override
            public void run() {
                for (Intent i : it) {
                    if (quiet(i)) return;
                }
                a.toast(R.string.scr_none);
                show(11, 5);
            }
        });
    }

    // ---- Mi Fire TV

    private static String ip(int v) {
        return (v & 0xff) + "." + ((v >> 8) & 0xff) + "." + ((v >> 16) & 0xff) + "." + ((v >> 24) & 0xff);
    }

    private String deviceType() {
        String m = Build.MODEL == null ? "" : Build.MODEL;
        if (m.equals("AFTMM")) return "Fire TV Stick 4K";
        if (m.equals("AFTKA")) return "Fire TV Stick 4K Max";
        if (m.equals("AFTGAZL")) return "Fire TV Stick 4K Max (2.ª gen)";
        if (m.equals("AFTSSS")) return "Fire TV Stick (3.ª gen)";
        if (m.equals("AFTSS")) return "Fire TV Stick Lite";
        if (m.equals("AFTT")) return "Fire TV Stick (2.ª gen)";
        if (m.equals("AFTN")) return "Fire TV (3.ª gen)";
        return m.isEmpty() ? s(R.string.fire_na) : m;
    }

    private String macText(WifiInfo wi) {
        String mac = null;
        try {
            mac = wi == null ? null : wi.getMacAddress();
        } catch (Throwable ignored) {
        }
        if (mac == null || mac.startsWith("02:00:00")) {
            try {
                java.io.BufferedReader br = new java.io.BufferedReader(
                        new java.io.FileReader("/sys/class/net/wlan0/address"));
                mac = br.readLine();
                br.close();
            } catch (Throwable ignored) {
                mac = null;
            }
        }
        return mac == null || mac.isEmpty() ? s(R.string.mac_hidden) : mac.toUpperCase();
    }

    private void buildFire() {
        LinearLayout col = cols[5];
        col.removeAllViews();
        header(col, s(R.string.set_fire));
        PackageManager pm = a.getPackageManager();
        IGroup g = group(col);
        String name = null;
        try {
            name = Settings.Global.getString(a.getContentResolver(), "device_name");
        } catch (Throwable ignored) {
        }
        if (name == null || name.isEmpty()) name = deviceType();
        info(g, s(R.string.fire_name), name);
        info(g, s(R.string.fire_type), deviceType());
        try {
            StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
            info(g, s(R.string.fire_cap), Formatter.formatFileSize(a, sf.getTotalBytes()));
        } catch (Throwable ignored) {
        }
        info(g, s(R.string.fire_account), s(R.string.fire_na));
        info(g, s(R.string.fire_sw), (Build.DISPLAY == null ? "" : Build.DISPLAY) + " · Android " + Build.VERSION.RELEASE);
        String home = s(R.string.fire_na);
        try {
            home = pm.getPackageInfo("com.amazon.tv.launcher", 0).versionName;
        } catch (Throwable ignored) {
        }
        info(g, s(R.string.fire_home), home);
        String serial = s(R.string.fire_na);
        try {
            String sn = Build.VERSION.SDK_INT >= 26 ? Build.getSerial() : Build.SERIAL;
            if (sn != null && !sn.equalsIgnoreCase("unknown")) serial = sn;
        } catch (Throwable ignored) {
        }
        info(g, s(R.string.fire_serial), serial);
        info(g, s(R.string.fire_datetime), a.fmtDate() + " · " + a.fmtTime());
        info(g, s(R.string.fire_storage), storageText());

        label(col, s(R.string.fire_net));
        IGroup gn = group(col);
        try {
            WifiManager w = wm();
            WifiInfo wi = w.getConnectionInfo();
            DhcpInfo di = w.getDhcpInfo();
            String ssid = wi == null ? null : wi.getSSID();
            info(gn, s(R.string.fire_ssid), ssid == null || ssid.contains("unknown") ? s(R.string.fire_na)
                    : ssid.replace("\"", ""));
            info(gn, s(R.string.fire_ip), di == null || di.ipAddress == 0 ? s(R.string.fire_na) : ip(di.ipAddress));
            info(gn, s(R.string.fire_gw), di == null || di.gateway == 0 ? s(R.string.fire_na) : ip(di.gateway));
            String dns = di == null || di.dns1 == 0 ? s(R.string.fire_na) : ip(di.dns1)
                    + (di.dns2 != 0 ? ", " + ip(di.dns2) : "");
            info(gn, s(R.string.fire_dns), dns);
            info(gn, s(R.string.fire_mac), macText(wi));
        } catch (Throwable t) {
            info(gn, s(R.string.fire_ssid), s(R.string.fire_na));
        }

        IGroup g2 = group(col);
        sysIntent(g2, Glyph.GEAR, BLUE, s(R.string.fire_update), new Intent("android.settings.SYSTEM_UPDATE_SETTINGS"),
                new Intent(Settings.ACTION_DEVICE_INFO_SETTINGS));
        sysIntent(g2, Glyph.GEAR, GRAY, s(R.string.fire_dev),
                new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
        sysIntent(g2, Glyph.LOCK, ORANGE, s(R.string.fire_unknown),
                new Intent("android.settings.MANAGE_UNKNOWN_APP_SOURCES", Uri.fromParts("package", a.getPackageName(), null)),
                new Intent(Settings.ACTION_SECURITY_SETTINGS));
        final IRow deep = nav(g2, Glyph.CLOCK, INDIGO, s(R.string.fire_deep), null);
        deep.setValue(sleepLabel(sleepNow()));
        deep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.sfx.play(Sfx.SELECT);
                chooseSleep(new Runnable() {
                    @Override
                    public void run() {
                        deep.setValue(sleepLabel(sleepNow()));
                    }
                });
            }
        });
        nav(g2, Glyph.RAM, RED, s(R.string.fire_reboot), new Runnable() {
            @Override
            public void run() {
                new AlertDialog.Builder(a)
                        .setTitle(R.string.fire_reboot_q)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                try {
                                    ((PowerManager) a.getSystemService(Context.POWER_SERVICE)).reboot(null);
                                } catch (Throwable t) {
                                    a.toast(R.string.fire_reboot_manual);
                                    go(new Intent(Settings.ACTION_DEVICE_INFO_SETTINGS), new Intent(Settings.ACTION_SETTINGS));
                                }
                            }
                        })
                        .setNegativeButton(android.R.string.cancel, null)
                        .show();
            }
        });
    }
}
