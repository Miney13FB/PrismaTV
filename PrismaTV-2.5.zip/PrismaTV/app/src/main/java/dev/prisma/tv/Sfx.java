package dev.prisma.tv;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

/**
 * Sonidos de interfaz suaves y limpios, sintetizados por código (nada que descargar).
 * Notas de seno con ataque suave, caída exponencial, un toque de brillo y eco corto,
 * al estilo de los sonidos discretos de Windows 11.
 */
final class Sfx {
    static final int MOVE = 0;
    static final int SELECT = 1;
    static final int BACK = 2;
    static final int OPEN = 3;
    static final int UNLOCK = 4;
    static final int TOGGLE = 5;
    private static final int N = 6;
    private static final int SR = 22050;

    boolean enabled = true;
    private final AudioTrack[] tracks = new AudioTrack[N];
    private long lastMove;

    Sfx() {
        try {
            // {frecuencia Hz, inicio s, duración s, volumen}
            tracks[MOVE] = make(0.20f, new float[][]{{1568f, 0f, 0.075f, 0.50f}});
            tracks[SELECT] = make(0.30f, new float[][]{{659f, 0f, 0.20f, 0.55f}, {988f, 0.045f, 0.24f, 0.50f}});
            tracks[BACK] = make(0.26f, new float[][]{{988f, 0f, 0.14f, 0.50f}, {659f, 0.05f, 0.18f, 0.50f}});
            tracks[OPEN] = make(0.42f, new float[][]{{523f, 0f, 0.30f, 0.45f}, {784f, 0.07f, 0.32f, 0.42f},
                    {1047f, 0.14f, 0.38f, 0.40f}});
            tracks[UNLOCK] = make(0.62f, new float[][]{{659f, 0f, 0.42f, 0.40f}, {880f, 0.08f, 0.42f, 0.36f},
                    {1319f, 0.17f, 0.50f, 0.34f}});
            tracks[TOGGLE] = make(0.18f, new float[][]{{1175f, 0f, 0.11f, 0.50f}});
        } catch (Throwable ignored) {
        }
    }

    private static AudioTrack make(float total, float[][] notes) {
        int n = (int) (SR * total);
        float[] buf = new float[n];
        for (float[] nt : notes) {
            int st = (int) (nt[1] * SR);
            int len = Math.min(n - st, (int) (nt[2] * SR));
            double ph = 0;
            for (int i = 0; i < len; i++) {
                double t = i / (double) SR;
                double att = Math.min(1.0, t / 0.006);
                att = att * att * (3 - 2 * att);
                double dec = Math.exp(-t * 6.0 / nt[2]);
                double rel = Math.min(1.0, (len - i) / (0.015 * SR));
                ph += 2 * Math.PI * nt[0] / SR;
                double v = Math.sin(ph) + 0.18 * Math.sin(2 * ph) + 0.05 * Math.sin(3 * ph);
                buf[st + i] += (float) (v * att * dec * rel * nt[3]);
            }
        }
        // eco corto (reverberación suave)
        float[] out = new float[n];
        int d1 = (int) (0.055 * SR), d2 = (int) (0.115 * SR);
        for (int i = 0; i < n; i++) {
            float v = buf[i];
            if (i >= d1) v += buf[i - d1] * 0.22f;
            if (i >= d2) v += buf[i - d2] * 0.10f;
            out[i] = v;
        }
        // filtro paso bajo suave
        short[] s = new short[n];
        float lp = 0;
        for (int i = 0; i < n; i++) {
            lp += (out[i] - lp) * 0.55f;
            float v = lp * 0.30f;
            if (v > 1f) v = 1f;
            if (v < -1f) v = -1f;
            s[i] = (short) (v * 32767);
        }
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        AudioFormat fmt = new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SR)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build();
        AudioTrack at = new AudioTrack(attrs, fmt, n * 2, AudioTrack.MODE_STATIC,
                AudioManager.AUDIO_SESSION_ID_GENERATE);
        at.write(s, 0, n);
        return at;
    }

    void play(int which) {
        if (!enabled) return;
        if (which == MOVE) {
            long now = System.currentTimeMillis();
            if (now - lastMove < 80) return;
            lastMove = now;
        }
        try {
            AudioTrack t = tracks[which];
            if (t == null) return;
            t.stop();
            t.reloadStaticData();
            t.play();
        } catch (Throwable ignored) {
        }
    }

    void release() {
        for (AudioTrack t : tracks) {
            try {
                if (t != null) t.release();
            } catch (Throwable ignored) {
            }
        }
    }
}
