package dev.prisma.tv;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.widget.FrameLayout;

/**
 * Panel de "cristal líquido": dibuja la parte del fondo ya desenfocado que queda
 * justo debajo, un tinte, un brillo superior y un borde fino. Coste por fotograma:
 * un solo drawRoundRect con shader.
 */
class GlassView extends FrameLayout {
    private static Bitmap backdrop;
    private static int sw, sh, version;

    static void setBackdrop(Bitmap b, int screenW, int screenH) {
        backdrop = b;
        sw = screenW;
        sh = screenH;
        version++;
    }

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint tintP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sheenP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rimP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint focusP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final RectF rimRect = new RectF();
    private final Matrix m = new Matrix();
    private final int[] loc = new int[2];
    private BitmapShader shader;
    private int shaderVer = -1;
    private final float radius;
    private final float rimW;
    private boolean focusRim;

    GlassView(Context c, float radiusPx, int tintColor) {
        super(c);
        setWillNotDraw(false);
        radius = radiusPx;
        rimW = Math.max(1.5f, radiusPx / 22f);

        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(1.35f);
        fill.setColorFilter(new ColorMatrixColorFilter(cm));

        tintP.setStyle(Paint.Style.FILL);
        tintP.setColor(tintColor);

        rimP.setStyle(Paint.Style.STROKE);
        rimP.setStrokeWidth(rimW);
        rimP.setColor(0x4DFFFFFF);

        focusP.setStyle(Paint.Style.STROKE);
        focusP.setStrokeWidth(Math.max(2.5f, radiusPx / 9f));
        focusP.setColor(0xEEFFFFFF);
    }

    void setTint(int c) {
        tintP.setColor(c);
        invalidate();
    }

    void setFocusRim(boolean on) {
        if (focusRim != on) {
            focusRim = on;
            invalidate();
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        rect.set(0, 0, w, h);
        float i = rimW / 2f;
        rimRect.set(i, i, w - i, h - i);
        sheenP.setShader(new LinearGradient(0, 0, 0, h * 0.65f, 0x38FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas c) {
        Bitmap bd = backdrop;
        if (bd != null && sw > 0 && sh > 0) {
            if (shader == null || shaderVer != version) {
                shader = new BitmapShader(bd, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                shaderVer = version;
                fill.setShader(shader);
            }
            getLocationInWindow(loc);
            m.setScale(sw / (float) bd.getWidth(), sh / (float) bd.getHeight());
            m.postTranslate(-loc[0], -loc[1]);
            shader.setLocalMatrix(m);
            c.drawRoundRect(rect, radius, radius, fill);
        }
        c.drawRoundRect(rect, radius, radius, tintP);
        c.drawRoundRect(rect, radius, radius, sheenP);
        c.drawRoundRect(rimRect, radius, radius, rimP);
        if (focusRim) {
            float i = focusP.getStrokeWidth() / 2f;
            rimRect.set(i, i, getWidth() - i, getHeight() - i);
            c.drawRoundRect(rimRect, radius, radius, focusP);
            float j = rimW / 2f;
            rimRect.set(j, j, getWidth() - j, getHeight() - j);
        }
    }
}
