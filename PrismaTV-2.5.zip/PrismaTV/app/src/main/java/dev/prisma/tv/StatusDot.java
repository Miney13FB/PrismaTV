package dev.prisma.tv;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Punto de estado: verde = encendido o conectado, gris = apagado o desconectado. */
final class StatusDot extends View {
    private boolean on;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    StatusDot(Context c) {
        super(c);
    }

    void setOn(boolean v) {
        on = v;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        p.setColor(on ? 0xFF34C759 : 0xFF8E8E93);
        float s = Math.min(getWidth(), getHeight());
        c.drawCircle(getWidth() / 2f, getHeight() / 2f, s / 2f, p);
    }
}
