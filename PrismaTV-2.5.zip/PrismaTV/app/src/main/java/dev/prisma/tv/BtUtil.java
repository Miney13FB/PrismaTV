package dev.prisma.tv;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.content.Context;

import java.lang.reflect.Method;

/** Utilidades de Bluetooth que Android no expone públicamente (estado conectado, conectar perfiles). */
final class BtUtil {
    static boolean isConn(BluetoothDevice d) {
        try {
            Method m = d.getClass().getMethod("isConnected");
            return (Boolean) m.invoke(d);
        } catch (Throwable t) {
            return false;
        }
    }

    static String nameOf(BluetoothDevice d) {
        String n = null;
        try {
            n = d.getName();
        } catch (Throwable ignored) {
        }
        return n == null || n.isEmpty() ? d.getAddress() : n;
    }

    static boolean hasName(BluetoothDevice d) {
        try {
            String n = d.getName();
            return n != null && !n.isEmpty();
        } catch (Throwable t) {
            return false;
        }
    }

    /** Conecta (o desconecta) los perfiles de audio, manos libres y mando del dispositivo ya vinculado. */
    static void setConnected(final Context ctx, final BluetoothDevice d, final boolean connect) {
        final BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null) return;
        int[] profiles = {BluetoothProfile.A2DP, BluetoothProfile.HEADSET, 4 /* INPUT_DEVICE */};
        for (int p : profiles) {
            try {
                ad.getProfileProxy(ctx, new BluetoothProfile.ServiceListener() {
                    @Override
                    public void onServiceConnected(final int profile, final BluetoothProfile proxy) {
                        try {
                            Method m = proxy.getClass().getMethod(connect ? "connect" : "disconnect",
                                    BluetoothDevice.class);
                            m.setAccessible(true);
                            m.invoke(proxy, d);
                        } catch (Throwable ignored) {
                        }
                        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    ad.closeProfileProxy(profile, proxy);
                                } catch (Throwable ignored) {
                                }
                            }
                        }, 4000);
                    }

                    @Override
                    public void onServiceDisconnected(int profile) {
                    }
                }, p);
            } catch (Throwable ignored) {
            }
        }
    }
}
