package dev.prisma.tv;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Interruptor estilo iPhone: verde si está activado, gris si está desactivado. */
final class SwitchView extends View {
    private boolean on;
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knob = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private float pos = 0f;
    private ValueAnimator anim;

    SwitchView(Context c) {
        super(c);
        knob.setColor(0xFFFFFFFF);
        knob.setShadowLayer(3f, 0f, 1.5f, 0x55000000);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
    }

    boolean isOn() {
        return on;
    }

    void setOn(boolean v) {
        boolean changed = on != v;
        on = v;
        if (anim != null) anim.cancel();
        if (changed && isAttachedToWindow()) {
            anim = ValueAnimator.ofFloat(pos, v ? 1f : 0f);
            anim.setDuration(220);
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator a) {
                    pos = (Float) a.getAnimatedValue();
                    invalidate();
                }
            });
            anim.start();
        } else {
            pos = v ? 1f : 0f;
            invalidate();
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        track.setColor((android.graphics.Color.argb(255,
                Math.round(0x6E + (0x34 - 0x6E) * pos), Math.round(0x6E + (0xC7 - 0x6E) * pos),
                Math.round(0x76 + (0x59 - 0x76) * pos))));
        r.set(0, 0, w, h);
        c.drawRoundRect(r, h / 2f, h / 2f, track);
        float pad = h * 0.09f;
        float rad = h / 2f - pad;
        float cx = h / 2f + (w - h) * pos;
        c.drawCircle(cx, h / 2f, rad, knob);
    }
}
