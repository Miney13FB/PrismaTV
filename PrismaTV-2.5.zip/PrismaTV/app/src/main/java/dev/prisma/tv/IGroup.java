package dev.prisma.tv;

import android.content.Context;
import android.graphics.Outline;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.LinearLayout;

/** Grupo redondeado de filas, como en Ajustes de iPhone (separadores finos entre filas). */
final class IGroup extends LinearLayout {
    private final float u;

    IGroup(Context c, float u) {
        super(c);
        this.u = u;
        setOrientation(VERTICAL);
        final float rad = 18f * u;
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x2EFFFFFF);
        bg.setCornerRadius(rad);
        setBackground(bg);
        setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), rad);
            }
        });
        setClipToOutline(true);
    }

    IRow add(IRow r) {
        if (getChildCount() > 0) {
            View d = new View(getContext());
            d.setBackgroundColor(0x24FFFFFF);
            LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, 1);
            lp.leftMargin = Math.round(66f * u);
            addView(d, lp);
        }
        addView(r, new LayoutParams(LayoutParams.MATCH_PARENT, Math.round(62f * u)));
        return r;
    }

    void clear() {
        removeAllViews();
    }
}
