package dev.prisma.tv;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

/** Fondos abstractos generados por código: no ocupan nada en el APK. */
final class WallpaperFactory {
    static final int COUNT = 18;

    static Bitmap make(int style, int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        switch (((style % COUNT) + COUNT) % COUNT) {
            case 0: // Aurora
                vgrad(c, w, h, 0xFF050B1E, 0xFF0B2740);
                blob(c, 0.25f * w, 0.78f * h, 0.62f * w, 0x2DE0B5, 150);
                blob(c, 0.72f * w, 0.28f * h, 0.56f * w, 0x7B5CFF, 150);
                blob(c, 0.50f * w, 0.05f * h, 0.50f * w, 0x2AA7FF, 90);
                blob(c, 0.92f * w, 0.92f * h, 0.40f * w, 0x3CFF9C, 80);
                break;
            case 1: // Crepúsculo
                vgrad(c, w, h, 0xFF14103A, 0xFF3A1A55);
                blob(c, 0.50f * w, 1.05f * h, 0.72f * w, 0xFF8A3D, 210);
                blob(c, 0.14f * w, 0.70f * h, 0.50f * w, 0xFF4F9A, 120);
                blob(c, 0.85f * w, 0.25f * h, 0.45f * w, 0x6A4DFF, 110);
                break;
            case 2: // Océano
                vgrad(c, w, h, 0xFF021B2E, 0xFF04546E);
                blob(c, 0.62f * w, 0.18f * h, 0.55f * w, 0x1FD0D8, 110);
                blob(c, 0.18f * w, 0.85f * h, 0.55f * w, 0x0A7AA8, 130);
                rays(c, w, h);
                break;
            case 3: // Brasa
                vgrad(c, w, h, 0xFF120808, 0xFF2A0E0A);
                blob(c, 0.30f * w, 1.00f * h, 0.70f * w, 0xFF5A1F, 175);
                blob(c, 0.76f * w, 0.95f * h, 0.45f * w, 0xFFB347, 95);
                blob(c, 0.82f * w, 0.20f * h, 0.50f * w, 0xB1123C, 85);
                break;
            case 4: // Grafito
                vgrad(c, w, h, 0xFF0C0D10, 0xFF1A1D24);
                blob(c, 0.50f * w, 0.30f * h, 0.80f * w, 0x4A5568, 70);
                break;
            case 5: // Prisma
                vgrad(c, w, h, 0xFF0A0B14, 0xFF10111F);
                blob(c, 0.14f * w, 0.32f * h, 0.38f * w, 0xFF4D6D, 100);
                blob(c, 0.36f * w, 0.78f * h, 0.38f * w, 0xFFA24D, 95);
                blob(c, 0.56f * w, 0.30f * h, 0.38f * w, 0x3DDC97, 90);
                blob(c, 0.80f * w, 0.72f * h, 0.38f * w, 0x4D8DFF, 100);
                blob(c, 0.92f * w, 0.18f * h, 0.38f * w, 0xB24DFF, 95);
                break;
            case 6: // Cuarzo rosa
                vgrad(c, w, h, 0xFF2A0F2E, 0xFF5A2250);
                blob(c, 0.20f * w, 0.30f * h, 0.60f * w, 0xFF7FB8, 140);
                blob(c, 0.80f * w, 0.80f * h, 0.60f * w, 0xC86BFF, 120);
                blob(c, 0.55f * w, 0.55f * h, 0.35f * w, 0xFFC1A0, 60);
                break;
            case 7: // Esmeralda
                vgrad(c, w, h, 0xFF031712, 0xFF08382B);
                blob(c, 0.25f * w, 0.25f * h, 0.62f * w, 0x1FE08A, 120);
                blob(c, 0.78f * w, 0.85f * h, 0.58f * w, 0x0FB5A0, 130);
                blob(c, 0.90f * w, 0.20f * h, 0.30f * w, 0xB6FF6B, 60);
                break;
            case 8: // Medianoche
                vgrad(c, w, h, 0xFF03040C, 0xFF0A1030);
                blob(c, 0.70f * w, 0.30f * h, 0.60f * w, 0x2B3FD8, 110);
                blob(c, 0.20f * w, 0.80f * h, 0.50f * w, 0x5B2BD8, 90);
                stars(c, w, h, 70, 11, 0.7f);
                break;
            case 9: // Lobo
                vgrad(c, w, h, 0xFF050818, 0xFF1B2748);
                stars(c, w, h, 60, 5, 0.55f);
                blob(c, 0.70f * w, 0.28f * h, 0.30f * w, 0xBFD4FF, 120);
                disc(c, 0.70f * w, 0.28f * h, 0.085f * h * 2.1f, 0xFFF1F5FF);
                ridge(c, w, h, 0.80f, 0.05f, 2.2f, 3, 0xFF0B1022);
                wolf(c, 0.46f * w, 0.52f * h, 0.30f * h, 0xFF05070F);
                break;
            case 10: // Ballena
                vgrad(c, w, h, 0xFF04304A, 0xFF011523);
                rays(c, w, h);
                blob(c, 0.5f * w, 0.0f * h, 0.7f * w, 0x39C6E8, 110);
                whale(c, 0.52f * w, 0.56f * h, 0.62f * w, 0xFF0A3550);
                bubbles(c, w, h, 24, 8);
                break;
            case 11: // Aves al atardecer
                vgrad(c, w, h, 0xFF2B1B52, 0xFFFF8A4A);
                blob(c, 0.5f * w, 0.88f * h, 0.45f * w, 0xFFD27A, 200);
                disc(c, 0.5f * w, 0.84f * h, 0.07f * h * 2f, 0xFFFFE2A6);
                birds(c, w, h, 14, 21);
                ridge(c, w, h, 0.93f, 0.03f, 3f, 9, 0xFF1A0F2E);
                break;
            case 12: // Medusas
                vgrad(c, w, h, 0xFF020A1C, 0xFF05163A);
                blob(c, 0.3f * w, 0.4f * h, 0.5f * w, 0x2A5BFF, 70);
                jelly(c, 0.30f * w, 0.36f * h, 0.15f * h, 0xFFB26BFF);
                jelly(c, 0.68f * w, 0.50f * h, 0.20f * h, 0xFF5BE0FF);
                jelly(c, 0.86f * w, 0.24f * h, 0.09f * h, 0xFFFF7BC8);
                bubbles(c, w, h, 30, 4);
                break;
            case 13: // Monte Fuji, Japón
                vgrad(c, w, h, 0xFF3A4D8F, 0xFFFFB199);
                disc(c, 0.74f * w, 0.30f * h, 0.07f * h * 2f, 0xFFFFF0E0);
                fuji(c, w, h);
                ridge(c, w, h, 0.90f, 0.03f, 2.5f, 17, 0xFF1D2447);
                break;
            case 14: // Dunas del Sáhara
                vgrad(c, w, h, 0xFF2A1B4D, 0xFFFFA45C);
                blob(c, 0.25f * w, 0.55f * h, 0.45f * w, 0xFFE0A0, 160);
                disc(c, 0.25f * w, 0.50f * h, 0.06f * h * 2f, 0xFFFFF1CE);
                ridge(c, w, h, 0.62f, 0.07f, 1.4f, 4, 0xFFB5602F);
                ridge(c, w, h, 0.74f, 0.08f, 1.1f, 7, 0xFF8E4423);
                ridge(c, w, h, 0.88f, 0.07f, 1.6f, 13, 0xFF5E2A18);
                break;
            case 15: // París
                vgrad(c, w, h, 0xFF1E1747, 0xFFFF8F6B);
                blob(c, 0.5f * w, 0.95f * h, 0.6f * w, 0xFFC28A, 150);
                skyline(c, w, h, 0.92f, 0.10f, 0.14f, 31, 0xFF2A1740, false);
                eiffel(c, 0.5f * w, 0.93f * h, 0.78f * h, 0xFF150C26);
                break;
            case 16: // Nueva York
                vgrad(c, w, h, 0xFF0B1030, 0xFFE0724A);
                blob(c, 0.5f * w, 1.0f * h, 0.7f * w, 0xFFB070, 150);
                skyline(c, w, h, 0.97f, 0.35f, 0.26f, 8, 0xFF1A1330, true);
                skyline(c, w, h, 1.0f, 0.50f, 0.18f, 19, 0xFF0C0A1C, true);
                break;
            case 17: // Alpes suizos
                vgrad(c, w, h, 0xFF2E5FA8, 0xFFBFD9F2);
                blob(c, 0.8f * w, 0.2f * h, 0.3f * w, 0xFFFFFF, 90);
                ridge(c, w, h, 0.55f, 0.22f, 2.0f, 6, 0xFF8FA6C4);
                snow(c, w, h, 0.55f, 0.22f, 2.0f, 6);
                ridge(c, w, h, 0.72f, 0.14f, 2.6f, 14, 0xFF3F5F7F);
                ridge(c, w, h, 0.88f, 0.08f, 3.2f, 22, 0xFF1F3A34);
                break;
            default:
                vgrad(c, w, h, 0xFF0C0D10, 0xFF1A1D24);
                break;
        }
        // Velo oscuro abajo para que los textos y el dock se lean bien.
        Paint p = new Paint();
        p.setShader(new LinearGradient(0, h * 0.40f, 0, h, 0x00000000, 0x80000000, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        return b;
    }

    private static void vgrad(Canvas c, int w, int h, int top, int bottom) {
        Paint p = new Paint();
        p.setShader(new LinearGradient(0, 0, 0, h, top, bottom, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
    }

    private static void blob(Canvas c, float cx, float cy, float r, int rgb, int alpha) {
        int inner = (alpha << 24) | (rgb & 0xFFFFFF);
        int outer = rgb & 0xFFFFFF;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new RadialGradient(cx, cy, r, inner, outer, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, p);
    }

    private static void rays(Canvas c, int w, int h) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0x0DFFFFFF);
        for (int i = 0; i < 5; i++) {
            float x = w * (0.15f + i * 0.17f);
            Path path = new Path();
            path.moveTo(x, 0);
            path.lineTo(x + w * 0.07f, 0);
            path.lineTo(x + w * 0.30f, h);
            path.lineTo(x + w * 0.12f, h);
            path.close();
            c.drawPath(path, p);
        }
    }

    // ------------------------------------------------------------------ escenas

    private static float rnd(int seed, int i) {
        double x = Math.sin(seed * 12.9898 + i * 78.233) * 43758.5453;
        return (float) (x - Math.floor(x));
    }

    private static void disc(Canvas c, float cx, float cy, float r, int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        c.drawCircle(cx, cy, r, p);
    }

    private static void stars(Canvas c, int w, int h, int n, int seed, float maxY) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        for (int i = 0; i < n; i++) {
            float x = rnd(seed, i * 2) * w;
            float y = rnd(seed, i * 2 + 1) * h * maxY;
            p.setColor(((int) (70 + rnd(seed, i + 99) * 150) << 24) | 0xFFFFFF);
            c.drawCircle(x, y, 0.6f + rnd(seed, i + 500) * 1.4f, p);
        }
    }

    /** Crestas de colinas o dunas: baseY y amp en fracción de la altura. */
    private static Path ridgePath(int w, int h, float baseY, float amp, float freq, int seed) {
        Path path = new Path();
        path.moveTo(0, h);
        int steps = 48;
        for (int i = 0; i <= steps; i++) {
            float x = w * i / (float) steps;
            double a = i / (double) steps * Math.PI * 2 * freq;
            double v = Math.sin(a + seed) * 0.55 + Math.sin(a * 2.3 + seed * 1.7) * 0.30
                    + Math.sin(a * 4.9 + seed * 0.6) * 0.15;
            float y = h * (baseY - amp * (float) v * 0.5f);
            path.lineTo(x, y);
        }
        path.lineTo(w, h);
        path.close();
        return path;
    }

    private static void ridge(Canvas c, int w, int h, float baseY, float amp, float freq, int seed, int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        c.drawPath(ridgePath(w, h, baseY, amp, freq, seed), p);
    }

    private static void snow(Canvas c, int w, int h, float baseY, float amp, float freq, int seed) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, h * (baseY - amp * 0.5f), 0, h * (baseY - amp * 0.05f),
                0xF0FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawPath(ridgePath(w, h, baseY, amp, freq, seed), p);
    }

    private static void bubbles(Canvas c, int w, int h, int n, int seed) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.4f);
        for (int i = 0; i < n; i++) {
            p.setColor(((int) (40 + rnd(seed, i) * 80) << 24) | 0xFFFFFF);
            c.drawCircle(rnd(seed, i + 40) * w, rnd(seed, i + 80) * h, 2 + rnd(seed, i + 120) * 7, p);
        }
    }

    private static void poly(Canvas c, float ox, float oy, float sw, float sh, float[] pts, boolean mirror, int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        Path path = new Path();
        path.moveTo(ox + pts[0] * sw, oy + pts[1] * sh);
        for (int i = 2; i < pts.length; i += 2) path.lineTo(ox + pts[i] * sw, oy + pts[i + 1] * sh);
        if (mirror) {
            for (int i = pts.length - 2; i >= 0; i -= 2) path.lineTo(ox + (1f - pts[i]) * sw, oy + pts[i + 1] * sh);
        }
        path.close();
        c.drawPath(path, p);
    }

    /** Lobo aullando; (x, y) = esquina inferior izquierda de la silueta, hh = altura. */
    private static void wolf(Canvas c, float x, float y, float hh, int color) {
        float[] pts = {0.00f, 1.00f, 0.02f, 0.72f, 0.10f, 0.54f, 0.22f, 0.46f, 0.36f, 0.42f, 0.43f, 0.30f,
                0.46f, 0.18f, 0.50f, 0.09f, 0.52f, 0.02f, 0.55f, 0.07f, 0.64f, 0.00f, 0.66f, 0.05f,
                0.58f, 0.15f, 0.62f, 0.20f, 0.55f, 0.27f, 0.57f, 0.40f, 0.59f, 0.56f, 0.57f, 0.78f, 0.62f, 1.00f};
        poly(c, x, y - hh, hh * 0.9f, hh, pts, false, color);
    }

    private static void whale(Canvas c, float cx, float cy, float len, int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        float h = len * 0.26f;
        RectF body = new RectF(cx - len * 0.5f, cy - h * 0.5f, cx + len * 0.28f, cy + h * 0.5f);
        c.drawOval(body, p);
        Path tail = new Path();
        tail.moveTo(cx + len * 0.2f, cy - h * 0.18f);
        tail.quadTo(cx + len * 0.38f, cy - h * 0.1f, cx + len * 0.46f, cy - h * 0.55f);
        tail.lineTo(cx + len * 0.52f, cy - h * 0.25f);
        tail.lineTo(cx + len * 0.54f, cy + h * 0.35f);
        tail.lineTo(cx + len * 0.44f, cy + h * 0.10f);
        tail.quadTo(cx + len * 0.36f, cy + h * 0.15f, cx + len * 0.2f, cy + h * 0.22f);
        tail.close();
        c.drawPath(tail, p);
        Path fin = new Path();
        fin.moveTo(cx - len * 0.12f, cy + h * 0.30f);
        fin.lineTo(cx - len * 0.22f, cy + h * 0.78f);
        fin.lineTo(cx - len * 0.02f, cy + h * 0.40f);
        fin.close();
        c.drawPath(fin, p);
        p.setColor(0x33FFFFFF);
        RectF belly = new RectF(cx - len * 0.42f, cy + h * 0.05f, cx + len * 0.2f, cy + h * 0.45f);
        c.drawOval(belly, p);
    }

    private static void birds(Canvas c, int w, int h, int n, int seed) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(0xFF1A0F2E);
        for (int i = 0; i < n; i++) {
            float x = w * (0.12f + rnd(seed, i) * 0.76f);
            float y = h * (0.15f + rnd(seed, i + 30) * 0.45f);
            float s = w * (0.012f + rnd(seed, i + 60) * 0.016f);
            p.setStrokeWidth(Math.max(1.4f, s * 0.22f));
            Path path = new Path();
            path.moveTo(x - s, y - s * 0.3f);
            path.quadTo(x - s * 0.4f, y - s * 0.7f, x, y);
            path.quadTo(x + s * 0.4f, y - s * 0.7f, x + s, y - s * 0.3f);
            c.drawPath(path, p);
        }
    }

    private static void jelly(Canvas c, float cx, float cy, float r, int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        blob(c, cx, cy, r * 2.6f, color & 0xFFFFFF, 90);
        p.setShader(new LinearGradient(0, cy - r, 0, cy + r * 0.3f, (color & 0xFFFFFF) | 0xE0000000,
                (color & 0xFFFFFF) | 0x60000000, Shader.TileMode.CLAMP));
        RectF dome = new RectF(cx - r, cy - r, cx + r, cy + r);
        c.drawArc(dome, 180, 180, true, p);
        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setStyle(Paint.Style.STROKE);
        t.setStrokeCap(Paint.Cap.ROUND);
        t.setStrokeWidth(Math.max(1.5f, r * 0.07f));
        t.setColor((color & 0xFFFFFF) | 0x90000000);
        for (int i = 0; i < 6; i++) {
            float x = cx - r * 0.75f + i * r * 0.3f;
            Path path = new Path();
            path.moveTo(x, cy);
            path.cubicTo(x - r * 0.25f, cy + r * 0.7f, x + r * 0.25f, cy + r * 1.3f, x - r * 0.1f, cy + r * 2.0f);
            c.drawPath(path, t);
        }
    }

    private static void fuji(Canvas c, int w, int h) {
        float cx = w * 0.5f, top = h * 0.36f, base = h * 0.90f, half = w * 0.40f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, top, 0, base, 0xFF4A5C9A, 0xFF1D2447, Shader.TileMode.CLAMP));
        Path cone = new Path();
        cone.moveTo(cx - half, base);
        cone.quadTo(cx - half * 0.35f, base - (base - top) * 0.15f, cx - w * 0.06f, top);
        cone.lineTo(cx + w * 0.06f, top);
        cone.quadTo(cx + half * 0.35f, base - (base - top) * 0.15f, cx + half, base);
        cone.close();
        c.drawPath(cone, p);
        Paint sn = new Paint(Paint.ANTI_ALIAS_FLAG);
        sn.setColor(0xFFF4F6FF);
        Path cap = new Path();
        float cy2 = top + (base - top) * 0.26f;
        cap.moveTo(cx - w * 0.06f, top);
        cap.lineTo(cx + w * 0.06f, top);
        cap.lineTo(cx + w * 0.115f, cy2);
        cap.lineTo(cx + w * 0.07f, cy2 - h * 0.03f);
        cap.lineTo(cx + w * 0.03f, cy2 + h * 0.025f);
        cap.lineTo(cx - w * 0.01f, cy2 - h * 0.02f);
        cap.lineTo(cx - w * 0.05f, cy2 + h * 0.03f);
        cap.lineTo(cx - w * 0.085f, cy2 - h * 0.01f);
        cap.lineTo(cx - w * 0.115f, cy2);
        cap.close();
        c.drawPath(cap, sn);
        Paint cl = new Paint(Paint.ANTI_ALIAS_FLAG);
        cl.setColor(0x55FFFFFF);
        c.drawOval(new RectF(w * 0.08f, h * 0.56f, w * 0.36f, h * 0.63f), cl);
        c.drawOval(new RectF(w * 0.60f, h * 0.64f, w * 0.92f, h * 0.72f), cl);
    }

    private static void skyline(Canvas c, int w, int h, float baseY, float maxH, float minH, int seed, int color,
                                boolean windows) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint wp = new Paint(Paint.ANTI_ALIAS_FLAG);
        float x = -w * 0.02f;
        int i = 0;
        while (x < w) {
            float bw = w * (0.035f + rnd(seed, i) * 0.045f);
            float bh = h * (minH * 0.4f + rnd(seed, i + 70) * (maxH - minH * 0.4f));
            float top = h * baseY - bh;
            p.setColor(color);
            c.drawRect(x, top, x + bw, h, p);
            if (windows) {
                wp.setColor(0xFFFFD27A);
                for (float wy = top + h * 0.02f; wy < h * baseY - h * 0.02f; wy += h * 0.028f) {
                    for (float wx = x + bw * 0.12f; wx < x + bw * 0.85f; wx += bw * 0.25f) {
                        if (rnd(seed, (int) (wx * 7 + wy * 13)) > 0.62f) {
                            wp.setAlpha(120 + (int) (rnd(seed, (int) (wx + wy)) * 120));
                            c.drawRect(wx, wy, wx + bw * 0.1f, wy + h * 0.012f, wp);
                        }
                    }
                }
                if (i % 7 == 3) {
                    p.setColor(color);
                    c.drawRect(x + bw * 0.46f, top - h * 0.05f, x + bw * 0.54f, top, p);
                }
            }
            x += bw + w * 0.004f;
            i++;
        }
    }

    private static void eiffel(Canvas c, float cx, float base, float hh, int color) {
        float[] pts = {0.00f, 1.00f, 0.17f, 0.64f, 0.22f, 0.64f, 0.27f, 0.47f, 0.33f, 0.47f, 0.41f, 0.20f,
                0.455f, 0.20f, 0.48f, 0.0f};
        float sw = hh * 0.62f;
        poly(c, cx - sw / 2f, base - hh, sw, hh, pts, true, color);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0xFF0B0616);
        Path arch = new Path();
        arch.moveTo(cx - sw * 0.20f, base);
        arch.quadTo(cx, base - hh * 0.30f, cx + sw * 0.20f, base);
        arch.close();
        c.drawPath(arch, p);
    }
}
