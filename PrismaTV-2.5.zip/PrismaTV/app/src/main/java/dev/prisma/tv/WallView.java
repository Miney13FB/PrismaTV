package dev.prisma.tv;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;

/** Fondo con cambio suave (fundido cruzado) entre un fondo y otro. */
final class WallView extends View {
    private Bitmap bmp, prev;
    private float t = 1f;
    private ValueAnimator anim;
    private final Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Rect src = new Rect();
    private final Rect dst = new Rect();

    WallView(Context c) {
        super(c);
    }

    void setBitmap(Bitmap b) {
        setBitmap(b, 0);
    }

    void setBitmap(Bitmap b, int fadeMs) {
        if (anim != null) anim.cancel();
        if (bmp != null && fadeMs > 0) {
            prev = bmp;
            bmp = b;
            t = 0f;
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(fadeMs);
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator a) {
                    t = (Float) a.getAnimatedValue();
                    if (t >= 1f) prev = null;
                    invalidate();
                }
            });
            anim.start();
        } else {
            prev = null;
            bmp = b;
            t = 1f;
            invalidate();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        dst.set(0, 0, getWidth(), getHeight());
        if (prev != null && t < 1f) {
            src.set(0, 0, prev.getWidth(), prev.getHeight());
            p.setAlpha(255);
            canvas.drawBitmap(prev, src, dst, p);
        }
        if (bmp == null) return;
        src.set(0, 0, bmp.getWidth(), bmp.getHeight());
        p.setAlpha(Math.round(255 * t));
        canvas.drawBitmap(bmp, src, dst, p);
    }
}
