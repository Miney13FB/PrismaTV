package dev.prisma.tv;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Iconos de colores (estilo Ajustes de iPhone), dibujados por código. Color 0 = sin fondo. */
final class Glyph extends View {
    static final int WIFI = 0, BT = 1, ANIM = 2, SHELF = 3, SOUND = 4, CLOCK = 5, HIDDEN = 6, RAM = 7,
            LOCK = 8, WEATHER = 9, DEVICE = 10, USER = 11, WALL = 12, GEAR = 13;

    private final int type;
    private final int color;
    private final boolean square;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint solid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF r = new RectF();

    Glyph(Context c, int type, int color) {
        this(c, type, color, false);
    }

    Glyph(Context c, int type, int color, boolean square) {
        super(c);
        this.type = type;
        this.color = color;
        this.square = square;
        fill.setColor(color);
        line.setStyle(Paint.Style.STROKE);
        line.setColor(0xFFFFFFFF);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        solid.setColor(0xFFFFFFFF);
    }

    @Override
    protected void onDraw(Canvas c) {
        float s = Math.min(getWidth(), getHeight());
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        if (color != 0) {
            if (square) {
                r.set(cx - s / 2f, cy - s / 2f, cx + s / 2f, cy + s / 2f);
                c.drawRoundRect(r, s * 0.24f, s * 0.24f, fill);
            } else {
                c.drawCircle(cx, cy, s / 2f, fill);
            }
        }
        line.setStrokeWidth(s * 0.075f);
        c.save();
        c.translate(cx - s / 2f, cy - s / 2f);
        switch (type) {
            case WIFI:
                for (int i = 1; i <= 3; i++) {
                    float rad = s * 0.15f * i;
                    r.set(s * 0.5f - rad, s * 0.68f - rad, s * 0.5f + rad, s * 0.68f + rad);
                    c.drawArc(r, 225f, 90f, false, line);
                }
                c.drawCircle(s * 0.5f, s * 0.68f, s * 0.05f, solid);
                break;
            case BT:
                path.reset();
                path.moveTo(s * 0.35f, s * 0.35f);
                path.lineTo(s * 0.65f, s * 0.65f);
                path.lineTo(s * 0.50f, s * 0.80f);
                path.lineTo(s * 0.50f, s * 0.20f);
                path.lineTo(s * 0.65f, s * 0.35f);
                path.lineTo(s * 0.35f, s * 0.65f);
                c.drawPath(path, line);
                break;
            case ANIM:
                path.reset();
                path.moveTo(s * 0.40f, s * 0.30f);
                path.lineTo(s * 0.72f, s * 0.50f);
                path.lineTo(s * 0.40f, s * 0.70f);
                path.close();
                c.drawPath(path, solid);
                break;
            case SHELF:
                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < 2; j++) {
                        float x = s * (0.26f + j * 0.26f);
                        float y = s * (0.26f + i * 0.26f);
                        r.set(x, y, x + s * 0.22f, y + s * 0.22f);
                        c.drawRoundRect(r, s * 0.05f, s * 0.05f, solid);
                    }
                }
                break;
            case SOUND:
                path.reset();
                path.moveTo(s * 0.28f, s * 0.42f);
                path.lineTo(s * 0.40f, s * 0.42f);
                path.lineTo(s * 0.54f, s * 0.30f);
                path.lineTo(s * 0.54f, s * 0.70f);
                path.lineTo(s * 0.40f, s * 0.58f);
                path.lineTo(s * 0.28f, s * 0.58f);
                path.close();
                c.drawPath(path, solid);
                r.set(s * 0.48f, s * 0.36f, s * 0.74f, s * 0.64f);
                c.drawArc(r, -50f, 100f, false, line);
                break;
            case CLOCK:
                c.drawCircle(s * 0.5f, s * 0.5f, s * 0.22f, line);
                c.drawLine(s * 0.5f, s * 0.5f, s * 0.5f, s * 0.36f, line);
                c.drawLine(s * 0.5f, s * 0.5f, s * 0.60f, s * 0.54f, line);
                break;
            case HIDDEN:
                r.set(s * 0.24f, s * 0.36f, s * 0.76f, s * 0.64f);
                c.drawOval(r, line);
                c.drawCircle(s * 0.5f, s * 0.5f, s * 0.05f, solid);
                c.drawLine(s * 0.28f, s * 0.72f, s * 0.72f, s * 0.28f, line);
                break;
            case LOCK:
                r.set(s * 0.30f, s * 0.46f, s * 0.70f, s * 0.74f);
                c.drawRoundRect(r, s * 0.05f, s * 0.05f, solid);
                r.set(s * 0.37f, s * 0.26f, s * 0.63f, s * 0.58f);
                c.drawArc(r, 180f, 180f, false, line);
                break;
            case WEATHER:
                c.drawCircle(s * 0.5f, s * 0.5f, s * 0.13f, solid);
                for (int i = 0; i < 8; i++) {
                    c.drawLine(s * 0.5f, s * 0.27f, s * 0.5f, s * 0.20f, line);
                    c.rotate(45f, s * 0.5f, s * 0.5f);
                }
                break;
            case DEVICE:
                r.set(s * 0.22f, s * 0.28f, s * 0.78f, s * 0.62f);
                c.drawRoundRect(r, s * 0.05f, s * 0.05f, line);
                c.drawLine(s * 0.5f, s * 0.62f, s * 0.5f, s * 0.72f, line);
                c.drawLine(s * 0.38f, s * 0.72f, s * 0.62f, s * 0.72f, line);
                break;
            case USER:
                c.drawCircle(s * 0.5f, s * 0.38f, s * 0.11f, solid);
                r.set(s * 0.28f, s * 0.54f, s * 0.72f, s * 0.98f);
                c.drawArc(r, 180f, 180f, true, solid);
                break;
            case WALL:
                r.set(s * 0.24f, s * 0.28f, s * 0.76f, s * 0.72f);
                c.drawRoundRect(r, s * 0.05f, s * 0.05f, line);
                path.reset();
                path.moveTo(s * 0.28f, s * 0.68f);
                path.lineTo(s * 0.43f, s * 0.46f);
                path.lineTo(s * 0.55f, s * 0.60f);
                path.lineTo(s * 0.62f, s * 0.52f);
                path.lineTo(s * 0.72f, s * 0.68f);
                path.close();
                c.drawPath(path, solid);
                break;
            case GEAR:
                c.drawCircle(s * 0.5f, s * 0.5f, s * 0.15f, line);
                for (int i = 0; i < 8; i++) {
                    c.drawLine(s * 0.5f, s * 0.25f, s * 0.5f, s * 0.31f, line);
                    c.rotate(45f, s * 0.5f, s * 0.5f);
                }
                break;
            default: // RAM
                r.set(s * 0.26f, s * 0.34f, s * 0.74f, s * 0.66f);
                c.drawRoundRect(r, s * 0.04f, s * 0.04f, line);
                for (int i = 0; i < 3; i++) {
                    float x = s * (0.36f + i * 0.14f);
                    c.drawLine(x, s * 0.42f, x, s * 0.58f, line);
                }
                break;
        }
        c.restore();
    }
}
