package dev.prisma.tv;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Ajustes del sistema: escritura directa de valores y búsqueda de las pantallas de ajustes de Fire OS. */
final class FireSettings {
    static final String[] PKGS = {"com.amazon.tv.settings.v2", "com.amazon.tv.settings", "com.amazon.tv.launcher",
            "com.android.tv.settings", "com.android.settings"};

    /** Pantalla de ajustes del sistema: paquete, clase y nombre legible. */
    static final class Screen {
        String pkg, cls, name;
    }

    static boolean putGlobal(Context c, String key, int v) {
        try {
            return Settings.Global.putInt(c.getContentResolver(), key, v) && true;
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean putGlobal(Context c, String key, String v) {
        try {
            return Settings.Global.putString(c.getContentResolver(), key, v);
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean putSecure(Context c, String key, int v) {
        try {
            return Settings.Secure.putInt(c.getContentResolver(), key, v);
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean putSystem(Context c, String key, int v) {
        try {
            return Settings.System.putInt(c.getContentResolver(), key, v);
        } catch (Throwable t) {
            return false;
        }
    }

    /** Todas las actividades exportadas de los paquetes de ajustes (salvo la pantalla de inicio). */
    static List<Screen> screens(Context c) {
        ArrayList<Screen> out = new ArrayList<>();
        PackageManager pm = c.getPackageManager();
        for (String p : PKGS) {
            try {
                PackageInfo pi = pm.getPackageInfo(p, PackageManager.GET_ACTIVITIES);
                if (pi.activities == null) continue;
                for (ActivityInfo ai : pi.activities) {
                    if (!ai.exported || !ai.enabled) continue;
                    String simple = ai.name.substring(ai.name.lastIndexOf('.') + 1);
                    String low = simple.toLowerCase(Locale.ROOT);
                    if (low.contains("homeactivity") || low.contains("mainactivity")) continue;
                    Screen s = new Screen();
                    s.pkg = p;
                    s.cls = ai.name;
                    s.name = pretty(simple);
                    out.add(s);
                }
            } catch (Throwable ignored) {
            }
        }
        Collections.sort(out, new Comparator<Screen>() {
            @Override
            public int compare(Screen x, Screen y) {
                return x.name.compareToIgnoreCase(y.name);
            }
        });
        return out;
    }

    private static String pretty(String simple) {
        String s = simple.replace("Activity", "").replace("Settings", "").replace("Fragment", "");
        if (s.isEmpty()) s = simple;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (i > 0 && Character.isUpperCase(ch) && Character.isLowerCase(s.charAt(i - 1))) sb.append(' ');
            sb.append(ch == '_' ? ' ' : ch);
        }
        return sb.toString().trim();
    }

    static Intent intentFor(Screen s) {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.setComponent(new ComponentName(s.pkg, s.cls));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return i;
    }

    /**
     * Pantallas de ajustes a probar, en orden, cuando no se encuentra una pantalla propia de Fire OS:
     * primero las de Android (pantalla o sonido) y por último los ajustes principales de Fire TV,
     * que es lo que abre "Opciones de desarrollador" y siempre existe.
     */
    static Intent[] fallbacks(boolean sound) {
        Intent std = new Intent(sound ? Settings.ACTION_SOUND_SETTINGS : Settings.ACTION_DISPLAY_SETTINGS);
        Intent amazon = new Intent(Intent.ACTION_MAIN);
        amazon.setComponent(new ComponentName("com.amazon.tv.launcher", "com.amazon.tv.launcher.ui.SettingsActivity"));
        Intent amazon2 = new Intent(Intent.ACTION_MAIN);
        amazon2.setComponent(new ComponentName("com.amazon.tv.settings.v2", "com.amazon.tv.settings.v2.SettingsActivity"));
        Intent generic = new Intent(Settings.ACTION_SETTINGS);
        return new Intent[]{std, amazon, amazon2, generic};
    }

    /** Primera pantalla cuyo nombre contenga alguna de las palabras (en el orden dado). */
    static Intent find(Context c, String... kws) {
        List<Screen> all = screens(c);
        for (String k : kws) {
            for (Screen s : all) {
                if (s.cls.toLowerCase(Locale.ROOT).contains(k)) return intentFor(s);
            }
        }
        return null;
    }
}
