package dev.prisma.tv;

import android.content.Context;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Baldosa del Centro de control (icono de color + título + estado). Se ilumina al enfocar. */
final class QTile extends GlassView implements FocusFx {
    private final TextView title;
    private final TextView sub;

    QTile(Context c, float u, int type, int color, String t) {
        super(c, 22f * u, 0x33FFFFFF);
        setFocusable(true);
        setClickable(true);
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_VERTICAL);
        col.setPadding(Math.round(16f * u), 0, Math.round(10f * u), 0);

        Glyph g = new Glyph(c, type, color);
        col.addView(g, new LinearLayout.LayoutParams(Math.round(34f * u), Math.round(34f * u)));

        title = new TextView(c);
        title.setText(t);
        title.setTextSize(TypedValue.COMPLEX_UNIT_PX, 19f * u);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        title.setSingleLine(true);
        title.setIncludeFontPadding(false);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.topMargin = Math.round(8f * u);
        col.addView(title, tp);

        sub = new TextView(c);
        sub.setTextSize(TypedValue.COMPLEX_UNIT_PX, 14f * u);
        sub.setTextColor(0xB8FFFFFF);
        sub.setSingleLine(true);
        sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        sub.setIncludeFontPadding(false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
        sp.topMargin = Math.round(2f * u);
        col.addView(sub, sp);

        addView(col, new FrameLayout.LayoutParams(-1, -1));
    }

    void setSub(String s) {
        sub.setText(s);
    }

    @Override
    public void fx(boolean focused, int dir, boolean animate) {
        setTint(focused ? 0xE8EEF2FB : 0x33FFFFFF);
        title.setTextColor(focused ? 0xFF111827 : 0xFFFFFFFF);
        sub.setTextColor(focused ? 0xFF4B5563 : 0xB8FFFFFF);
        float s = focused ? 1.04f : 1f;
        if (!animate) {
            setScaleX(s);
            setScaleY(s);
            return;
        }
        animate().cancel();
        animate().scaleX(s).scaleY(s).setDuration(focused ? 200 : 140)
                .setInterpolator(focused ? new OvershootInterpolator(1.4f) : new DecelerateInterpolator())
                .start();
    }
}
