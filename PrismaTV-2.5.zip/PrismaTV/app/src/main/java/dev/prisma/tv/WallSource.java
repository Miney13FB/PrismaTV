package dev.prisma.tv;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;

/**
 * Fondos con fotos reales (hechas por personas) de animales, paisajes, lugares y maravillas del mundo y ciudades.
 * Las fotos salen de Wikimedia Commons (imágenes destacadas y de calidad, solo con licencias libres:
 * dominio público, CC0 o CC BY / CC BY-SA con crédito) y se guardan en el dispositivo la primera vez.
 * Sin internet se usan los fondos abstractos generados por código.
 */
final class WallSource {
    static final int MIX = 0, ANIMALS = 1, LAND = 2, WORLD = 3, CITIES = 4, ABSTRACT = 5;
    private static final String UA = "PrismaTV/2.5 (launcher personal para Fire TV; github.com/Miney13FB/PrismaTV)";
    private static final int MAX_IDX = 520;
    private static final String CAT_BOTH = "incategory:\"Featured pictures on Wikimedia Commons\"|\"Quality images\"";
    private static final String CAT_FEAT = "incategory:\"Featured pictures on Wikimedia Commons\"";
    private static final String[][] KW = {
            {},
            {"lion", "tiger", "eagle", "wolf", "elephant", "fox", "owl", "bear", "whale", "parrot", "horse",
                    "butterfly", "penguin", "giraffe", "dolphin", "flamingo", "leopard", "panda", "koala",
                    "hummingbird", "deer", "zebra"},
            {"mountain", "lake", "waterfall", "forest", "sunset", "desert", "glacier", "valley", "aurora",
                    "canyon", "beach", "volcano", "fjord", "autumn forest", "coast cliffs", "snow peaks"},
            {"Taj Mahal", "Machu Picchu", "Great Wall of China", "Petra Jordan", "Colosseum Rome",
                    "Chichen Itza", "Christ the Redeemer", "Pyramids of Giza", "Angkor Wat", "Alhambra",
                    "Sagrada Familia", "Eiffel Tower", "Santorini", "Iguazu Falls", "Grand Canyon", "Stonehenge",
                    "Easter Island moai", "Mont Saint-Michel", "Neuschwanstein", "Burj Khalifa", "Uluru",
                    "Hagia Sophia", "Forbidden City", "Acropolis Athens", "Victoria Falls"},
            {"skyline", "cityscape night", "harbour city", "New York skyline", "Tokyo", "Paris", "London",
                    "Madrid", "Barcelona", "Venice", "Dubai", "Hong Kong", "Sydney", "Rome", "Istanbul",
                    "Prague", "San Francisco", "Singapore", "Shanghai", "Lisbon"}};

    private final SharedPreferences sp;
    private final File dir;
    private final Random rnd = new Random();
    private volatile boolean indexing;
    private volatile Runnable ready;
    private volatile String credit = "";
    private String last = "";
    private int lastAbs = -1;

    WallSource(Context c) {
        sp = c.getSharedPreferences("prisma_walls", Context.MODE_PRIVATE);
        dir = new File(c.getFilesDir(), "walls");
        dir.mkdirs();
    }

    /** Se avisa (desde un hilo de fondo) cuando ya hay fotos para usar tras crear el índice por primera vez. */
    void setOnReady(Runnable r) {
        ready = r;
    }

    /** Crédito de la última foto devuelta (vacío si fue un fondo abstracto). */
    String credit() {
        return credit;
    }

    /** Se llama en un hilo en segundo plano. Devuelve siempre un bitmap de 16:9 listo para usar. */
    Bitmap next(int mode) {
        if (mode != ABSTRACT) {
            ensureIndexAsync();
            List<String[]> l = entries(mode);
            for (int tries = 0; tries < 4 && !l.isEmpty(); tries++) {
                String[] e = pick(l);
                File f = file(e[1]);
                if (!f.exists() && !download(e[1], f)) continue;
                Bitmap b = decode(f);
                if (b != null) {
                    last = e[1];
                    credit = e.length > 3 ? e[3] : e[2];
                    return veil(b);
                }
            }
        }
        credit = "";
        int st;
        do {
            st = rnd.nextInt(9);
        } while (st == lastAbs);
        lastAbs = st;
        return WallpaperFactory.make(st, 640, 360);
    }

    private String[] pick(List<String[]> l) {
        ArrayList<String[]> cached = new ArrayList<>();
        for (String[] e : l) {
            if (file(e[1]).exists() && !e[1].equals(last)) cached.add(e);
        }
        if (cached.size() >= 3 && rnd.nextInt(10) < 6) return cached.get(rnd.nextInt(cached.size()));
        String[] e;
        int n = 0;
        do {
            e = l.get(rnd.nextInt(l.size()));
        } while (e[1].equals(last) && l.size() > 1 && ++n < 5);
        return e;
    }

    private File file(String url) {
        return new File(dir, Integer.toHexString(url.hashCode()) + ".jpg");
    }

    // ------------------------------------------------------------------ índice

    private List<String[]> entries(int mode) {
        ArrayList<String[]> out = new ArrayList<>();
        String raw = sp.getString("idx", "");
        if (raw.isEmpty()) return out;
        for (String line : raw.split("\n")) {
            String[] p = line.split("\t");
            if (p.length < 3) continue;
            int t = p[0].length() == 1 ? p[0].charAt(0) - '0' : -1;
            if (t < 1 || t > 4) continue;
            if (mode == MIX || mode == t) out.add(p);
        }
        return out;
    }

    private void ensureIndexAsync() {
        long ts = sp.getLong("idxTs", 0);
        String old = sp.getString("idx", "");
        boolean has = !old.isEmpty();
        // índice nuevo de la versión 2.5 (con licencias y créditos): se rehace una vez
        boolean v25 = sp.getInt("idxVer", 0) >= 25;
        if (indexing || (has && v25 && System.currentTimeMillis() - ts < 7L * 86400000L)) return;
        indexing = true;
        final boolean hadPhotos = has && v25;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    ArrayList<String> lines = new ArrayList<>();
                    HashSet<String> seen = new HashSet<>();
                    if (hadPhotos) {
                        String raw = sp.getString("idx", "");
                        for (String line : raw.split("\n")) {
                            String[] p = line.split("\t");
                            if (p.length >= 3) {
                                lines.add(line);
                                seen.add(p[1]);
                            }
                        }
                    }
                    boolean notified = hadPhotos;
                    int maxLen = 0;
                    for (int t = 1; t <= 4; t++) maxLen = Math.max(maxLen, KW[t].length);
                    for (int i = 0; i < maxLen && lines.size() < MAX_IDX; i++) {
                        for (int t = 1; t <= 4; t++) {
                            if (i >= KW[t].length) continue;
                            try {
                                int added = query(t, KW[t][i], lines, seen);
                                if (added > 0) {
                                    save(lines, false);
                                    if (!notified && lines.size() >= 4) {
                                        notified = true;
                                        Runnable r = ready;
                                        if (r != null) r.run();
                                    }
                                }
                            } catch (Throwable ignored) {
                            }
                        }
                    }
                    if (!lines.isEmpty()) save(lines, true);
                } finally {
                    indexing = false;
                }
            }
        }).start();
    }

    private void save(List<String> lines, boolean done) {
        StringBuilder sb = new StringBuilder();
        for (String s : lines) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(s);
        }
        SharedPreferences.Editor ed = sp.edit().putString("idx", sb.toString()).putInt("idxVer", 25);
        if (done) ed.putLong("idxTs", System.currentTimeMillis());
        ed.apply();
    }

    private int query(int topic, String kw, List<String> lines, Set<String> seen) throws Exception {
        int n = runQuery(topic, kw, CAT_BOTH, lines, seen);
        if (n < 0) n = runQuery(topic, kw, CAT_FEAT, lines, seen);
        return Math.max(n, 0);
    }

    /** Devuelve -1 si la búsqueda no dio resultados; si no, cuántas fotos nuevas se añadieron. */
    private int runQuery(int topic, String kw, String cat, List<String> lines, Set<String> seen) throws Exception {
        String q = cat + " " + kw + " filetype:bitmap";
        String url = "https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search"
                + "&gsrnamespace=6&gsrlimit=15&gsrsearch=" + URLEncoder.encode(q, "UTF-8")
                + "&prop=imageinfo&iiprop=url%7Csize%7Cextmetadata"
                + "&iiextmetadatafilter=LicenseShortName%7CArtist&iiurlwidth=1920";
        JSONObject o = new JSONObject(new String(get(url), "UTF-8"));
        JSONObject qq = o.optJSONObject("query");
        if (qq == null) return -1;
        JSONObject pages = qq.optJSONObject("pages");
        if (pages == null) return -1;
        int added = 0;
        Iterator<String> it = pages.keys();
        while (it.hasNext()) {
            JSONObject pg = pages.getJSONObject(it.next());
            JSONArray ii = pg.optJSONArray("imageinfo");
            if (ii == null || ii.length() == 0) continue;
            JSONObject info = ii.getJSONObject(0);
            String thumb = info.optString("thumburl", "");
            int w = info.optInt("width"), h = info.optInt("height");
            if (thumb.isEmpty() || h <= 0 || w < 1920 || w / (float) h < 1.3f) continue;
            if (seen.contains(thumb)) continue;
            JSONObject md = info.optJSONObject("extmetadata");
            String lic = val(md, "LicenseShortName");
            if (!okLicense(lic)) continue;
            String title = clean(pg.optString("title", "").replace("File:", "")
                    .replaceAll("\\.[A-Za-z]{3,4}$", "").replace('_', ' '), 60);
            String artist = clean(strip(val(md, "Artist")), 40);
            String credit = title + (artist.isEmpty() ? "" : " · " + artist) + " · " + niceLicense(lic);
            seen.add(thumb);
            lines.add(topic + "\t" + thumb + "\t" + title + "\t" + credit);
            added++;
            if (lines.size() >= MAX_IDX) break;
        }
        return added;
    }

    private static String val(JSONObject md, String key) {
        if (md == null) return "";
        JSONObject o = md.optJSONObject(key);
        return o == null ? "" : o.optString("value", "");
    }

    /** Dominio público, CC0 y Creative Commons con permiso de uso (sin NC ni ND). */
    private static boolean okLicense(String lic) {
        String s = lic == null ? "" : lic.toLowerCase(Locale.ROOT).trim();
        if (s.isEmpty()) return false;
        if (s.contains("-nc") || s.contains("-nd") || s.contains(" nc") || s.contains(" nd")) return false;
        return s.startsWith("public domain") || s.startsWith("pd") || s.startsWith("cc0") || s.startsWith("cc by");
    }

    private static String niceLicense(String lic) {
        String s = lic.toLowerCase(Locale.ROOT).trim();
        if (s.startsWith("public domain") || s.startsWith("pd")) return "dominio público";
        return lic.trim();
    }

    private static String strip(String html) {
        return html.replaceAll("<[^>]*>", "").replace("&amp;", "&").replace("&nbsp;", " ")
                .replace("&quot;", "\"").replace("&#39;", "'");
    }

    private static String clean(String s, int max) {
        String t = s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim();
        while (t.contains("  ")) t = t.replace("  ", " ");
        if (t.length() > max) t = t.substring(0, max - 1).trim() + "…";
        return t;
    }

    // ------------------------------------------------------------------ descarga y decodificación

    private byte[] get(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setRequestProperty("User-Agent", UA);
        c.setConnectTimeout(12000);
        c.setReadTimeout(25000);
        InputStream in = c.getInputStream();
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        } finally {
            in.close();
            c.disconnect();
        }
    }

    private boolean download(String url, File f) {
        try {
            byte[] data = get(url);
            File tmp = new File(dir, f.getName() + ".tmp");
            FileOutputStream os = new FileOutputStream(tmp);
            os.write(data);
            os.close();
            boolean ok = tmp.renameTo(f);
            trim();
            return ok;
        } catch (Throwable t) {
            return false;
        }
    }

    private void trim() {
        File[] fs = dir.listFiles();
        if (fs == null || fs.length <= 90) return;
        java.util.Arrays.sort(fs, new java.util.Comparator<File>() {
            @Override
            public int compare(File x, File y) {
                return Long.compare(x.lastModified(), y.lastModified());
            }
        });
        for (int i = 0; i < fs.length - 90; i++) fs[i].delete();
    }

    private Bitmap decode(File f) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getPath(), o);
            if (o.outWidth <= 0) {
                f.delete();
                return null;
            }
            int ss = 1;
            while (o.outWidth / (ss * 2) >= 1280 && o.outHeight / (ss * 2) >= 720) ss *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = ss;
            Bitmap src = BitmapFactory.decodeFile(f.getPath(), o2);
            if (src == null) {
                f.delete();
                return null;
            }
            // recorte centrado a 16:9 y escala a 1280x720
            int w = src.getWidth(), h = src.getHeight();
            int cw = w, ch = Math.round(w * 9f / 16f);
            if (ch > h) {
                ch = h;
                cw = Math.round(h * 16f / 9f);
            }
            Bitmap crop = Bitmap.createBitmap(src, (w - cw) / 2, (h - ch) / 2, cw, ch);
            Bitmap out = Bitmap.createScaledBitmap(crop, 1280, 720, true);
            if (crop != out && crop != src) crop.recycle();
            if (src != out) src.recycle();
            f.setLastModified(System.currentTimeMillis());
            return out;
        } catch (Throwable t) {
            return null;
        }
    }

    private Bitmap veil(Bitmap b) {
        Bitmap m = b.isMutable() ? b : b.copy(Bitmap.Config.ARGB_8888, true);
        Canvas c = new Canvas(m);
        Paint p = new Paint();
        int w = m.getWidth(), h = m.getHeight();
        p.setShader(new LinearGradient(0, 0, 0, h, new int[]{0x55000000, 0x22000000, 0x33000000, 0xA0000000},
                new float[]{0f, 0.35f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        return m;
    }
}
