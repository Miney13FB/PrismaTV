package dev.prisma.tv;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.List;

/** Ajustes del sistema: escritura directa de valores y acceso a los ajustes originales de Fire OS. */
final class FireSettings {
    static boolean putGlobal(Context c, String key, int v) {
        try {
            return Settings.Global.putInt(c.getContentResolver(), key, v) && true;
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean putGlobal(Context c, String key, String v) {
        try {
            return Settings.Global.putString(c.getContentResolver(), key, v);
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean putSecure(Context c, String key, int v) {
        try {
            return Settings.Secure.putInt(c.getContentResolver(), key, v);
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean putSystem(Context c, String key, int v) {
        try {
            return Settings.System.putInt(c.getContentResolver(), key, v);
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Pantallas ORIGINALES de ajustes de Fire TV (Amazon) para Pantalla o Sonido, en orden de prueba.
     * Quien las usa va probando una a una hasta que el sistema abre una; la última son los ajustes principales.
     */
    static List<Intent> original(Context c, boolean sound) {
        ArrayList<Intent> out = new ArrayList<>();
        // 1) pantalla estándar: Fire OS la redirige a su propio menú de Pantalla y sonidos
        out.add(new Intent(sound ? Settings.ACTION_SOUND_SETTINGS : Settings.ACTION_DISPLAY_SETTINGS));
        // 2) pantallas de Amazon
        String[][] amazon = {
                {"com.amazon.tv.launcher", "com.amazon.tv.launcher.ui.SettingsActivity"},
                {"com.amazon.tv.settings.v2", "com.amazon.tv.settings.v2.SettingsActivity"},
                {"com.amazon.tv.settings", "com.amazon.tv.settings.SettingsActivity"}};
        for (String[] a : amazon) {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.setComponent(new ComponentName(a[0], a[1]));
            out.add(i);
        }
        // 3) ajustes principales
        out.add(new Intent(Settings.ACTION_SETTINGS));
        for (Intent i : out) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return out;
    }
}
