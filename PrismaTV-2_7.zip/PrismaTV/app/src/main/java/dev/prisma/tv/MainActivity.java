package dev.prisma.tv;

import android.Manifest;
import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.LruCache;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Prisma TV 2.6: un solo Inicio (dock + todas las apps), el fondo toma el color de la app
 * enfocada, ajustes propios estilo iPhone (Wi-Fi, Bluetooth, tiempo, bloqueo...) y pantalla de bloqueo.
 * Estilo cristal tipo tvOS inspirado en Glass. Código propio, sin librerías.
 */
public class MainActivity extends Activity {

    static final int TW = 240, TH = 135;
    /** Color base (sin app enfocada) del cristal de la fila de aplicaciones. */
    static final int BAND_BASE = 0x4D0E1424;
    static final Typeface LIGHT = Typeface.create("sans-serif-light", Typeface.NORMAL);
    static final Typeface MEDIUM = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    static final Typeface REG = Typeface.create("sans-serif", Typeface.NORMAL);
    static final int[] WP_NAMES = {R.string.wp_0, R.string.wp_1, R.string.wp_2,
            R.string.wp_3, R.string.wp_4};
    

    Store st;
    float u;
    int sw, sh;
    final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    Sfx sfx;
    private boolean soundReady;

    FrameLayout root;
    private FrameLayout content;
    private WallView wall;
    private View tint;
    private GradientDrawable tintD;
    private int tintCur = 0;
    private int tintTarget = 0;
    private ValueAnimator tintAnim;

    // barra superior
    private TextView netText, btText;
    private WifiView wifiIcon;
    private Glyph btIcon;
    private StatusDot btDot;
    Weather wx;
    private LinearLayout wxHomeBox, wxLockBox;

    // inicio
    private ScrollView homeScroll;
    private TextView greetTv, clockTv, dateTv, capName, capSub, gridTitle;
    private View capBox;
    private LinearLayout dockRow, gridBox;
    private HorizontalScrollView dockScroll;
    private GlassView dockBand;
    private final ArgbEvaluator argb = new ArgbEvaluator();

    // datos
    List<AppItem> apps = new ArrayList<>();
    private final HashMap<String, AppItem> byPkg = new HashMap<>();
    private final HashMap<String, Integer> appColors = new HashMap<>();
    private final LruCache<String, Bitmap> tiles = new LruCache<String, Bitmap>(16 * 1024 * 1024) {
        @Override
        protected int sizeOf(String k, Bitmap b) {
            return b.getByteCount();
        }
    };

    private ControlCenter cc;

    // menú contextual
    private FrameLayout menuLayer;
    private View menuPrevFocus;

    // reloj en reposo
    private FrameLayout saver;
    private LinearLayout saverCol;
    private TextView saverClock, saverDate, saverGreet, creditTv;
    private int lockWall;
    private View openOv;
    private boolean saverOn;
    private final Random rnd = new Random();
    private ValueAnimator drift;

    // ------------------------------------------------------------------ ciclo de vida

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        st = new Store(this);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        sw = Math.max(dm.widthPixels, dm.heightPixels);
        sh = Math.min(dm.widthPixels, dm.heightPixels);
        u = Math.min(sw / 1280f, sh / 720f);
        sfx = new Sfx();
        sfx.enabled = st.sound();
        wx = new Weather();

        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        // la pantalla nunca se apaga ni entra el protector de pantalla del sistema mientras Prisma está delante
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF05070C);

        wall = new WallView(this);
        wall.setScaleX(1.06f);
        wall.setScaleY(1.06f);
        root.addView(wall, new FrameLayout.LayoutParams(-1, -1));

        tint = new View(this);
        tintD = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0, 0});
        tint.setBackground(tintD);
        root.addView(tint, new FrameLayout.LayoutParams(-1, -1));

        content = new FrameLayout(this);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        buildTopBar();
        View home = buildHome();
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, -1);
        hp.topMargin = px(96);
        content.addView(home, hp);
        buildSaver();
        setContentView(root);

        cc = new ControlCenter(this);
        root.getViewTreeObserver().addOnGlobalFocusChangeListener(focusL);

        handleIntentExtras(getIntent());
        applyWallpaper();
        reloadApps(true);
        updateClock();
        updateNet();
        updateBt();
        updateWeatherViews();
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                soundReady = true;
            }
        }, 900);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleIntentExtras(i);
        dismissMenu(false);
        if (cc != null && cc.open) cc.close();
        if (saverOn) hideSaver();
        homeScroll.scrollTo(0, 0);
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                focusFirstFav();
            }
        }, 80);
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter f1 = new IntentFilter();
        f1.addAction(Intent.ACTION_TIME_TICK);
        f1.addAction(Intent.ACTION_TIME_CHANGED);
        f1.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        f1.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        f1.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        f1.addAction(WifiManager.RSSI_CHANGED_ACTION);
        f1.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        f1.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        f1.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        f1.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        f1.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        registerReceiver(rx, f1);
        IntentFilter f2 = new IntentFilter();
        f2.addAction(Intent.ACTION_PACKAGE_ADDED);
        f2.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f2.addAction(Intent.ACTION_PACKAGE_REPLACED);
        f2.addDataScheme("package");
        registerReceiver(rx, f2);
        updateClock();
        updateNet();
        updateBt();
        updateWeatherViews();
        refreshWeather(false);
        removeOpenOverlay(true);
        ui.removeCallbacks(wxR);
        ui.postDelayed(wxR, 20 * 60000L);
        startDrift();
        resetIdle();
        ui.removeCallbacks(homeCycleR);
        ui.postDelayed(homeCycleR, 30000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            unregisterReceiver(rx);
        } catch (Throwable ignored) {
        }
        stopDrift();
        ui.removeCallbacks(wxR);
        ui.removeCallbacks(homeCycleR);
        ui.removeCallbacks(idleR);
        if (saverOn) hideSaver();
        if (cc != null && cc.open) cc.close();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bg.shutdownNow();
        wallEx.shutdownNow();
        io.shutdownNow();
        sfx.release();
    }

    @Override
    public void onBackPressed() {
        if (menuLayer != null) {
            sfx.play(Sfx.BACK);
            dismissMenu(true);
            return;
        }
        if (cc != null && cc.open) {
            sfx.play(Sfx.BACK);
            cc.back();
            return;
        }
        if (homeScroll.getScrollY() > 0) {
            sfx.play(Sfx.BACK);
            homeScroll.smoothScrollTo(0, 0);
            focusFirstFav();
        }
        // En Inicio no se hace nada más: un launcher no se cierra.
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (saverOn) {
            if (e.getAction() == KeyEvent.ACTION_DOWN) hideSaver();
            return true;
        }
        resetIdle();
        if (e.getKeyCode() == KeyEvent.KEYCODE_MENU) {
            if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) {
                if (cc.open) cc.close();
                else if (menuLayer == null) cc.open(0);
            }
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    public void onUserInteraction() {
        resetIdle();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (cc != null) cc.permResult();
    }

    private void handleIntentExtras(Intent i) {
        if (i != null && i.hasExtra("name")) {
            st.setName(i.getStringExtra("name"));
            updateClock();
        }
    }

    // ------------------------------------------------------------------ utilidades

    int px(float v) {
        return Math.round(v * u);
    }

    TextView text(String s, float sizeDesign, int color, Typeface tf) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizeDesign * u);
        t.setTextColor(color);
        if (tf != null) t.setTypeface(tf);
        t.setIncludeFontPadding(false);
        return t;
    }

    void toast(int res) {
        Toast.makeText(this, res, Toast.LENGTH_SHORT).show();
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    void blockContent(boolean b) {
        content.setDescendantFocusability(b ? ViewGroup.FOCUS_BLOCK_DESCENDANTS
                : ViewGroup.FOCUS_AFTER_DESCENDANTS);
    }

    boolean hasLocation() {
        return Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    /** Pide el permiso solo si falta; devuelve true si ya está concedido. */
    boolean ensureLocation() {
        if (hasLocation()) return true;
        try {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 7);
        } catch (Throwable ignored) {
        }
        return false;
    }

    private static int centerX(View v) {
        int[] l = new int[2];
        v.getLocationOnScreen(l);
        return l[0] + v.getWidth() / 2;
    }

    private void invalidateGlass(View v) {
        if (v instanceof GlassView) v.invalidate();
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) invalidateGlass(g.getChildAt(i));
        }
    }

    private static String cap(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase(Locale.getDefault()) + s.substring(1);
    }

    String fmtTime() {
        return new SimpleDateFormat(st.h24() ? "HH:mm" : "h:mm", Locale.getDefault()).format(new Date());
    }

    String fmtDate() {
        Locale loc = Locale.getDefault();
        String pat = android.text.format.DateFormat.getBestDateTimePattern(loc, "EEEEdMMMM");
        return cap(new SimpleDateFormat(pat, loc).format(new Date()));
    }

    // ------------------------------------------------------------------ foco global y color por app

    private final ViewTreeObserver.OnGlobalFocusChangeListener focusL =
            new ViewTreeObserver.OnGlobalFocusChangeListener() {
                @Override
                public void onGlobalFocusChanged(View oldF, View newF) {
                    boolean anim = st.anim();
                    int dir = 0;
                    if (oldF != null && newF != null) {
                        dir = Integer.signum(centerX(newF) - centerX(oldF));
                    }
                    if (oldF instanceof FocusFx) ((FocusFx) oldF).fx(false, 0, anim);
                    if (newF instanceof FocusFx) ((FocusFx) newF).fx(true, dir, anim);
                    if (newF != null && soundReady) sfx.play(Sfx.MOVE);
                    if (cc != null && cc.open) return;
                    if (saverOn) return;
                    updateCaption(newF);
                    if (newF instanceof Cell && ((Cell) newF).pkg != null) {
                        setTint(colorFor(((Cell) newF).pkg));
                    } else if (newF != null && menuLayer == null) {
                        setTint(0);
                    }
                }
            };

    private int colorFor(String pkg) {
        Integer c = appColors.get(pkg);
        if (c != null) return c;
        Bitmap b = tiles.get(pkg);
        if (b == null) return 0;
        int v = TileFactory.dominantOf(b);
        appColors.put(pkg, v);
        return v;
    }

    /** Anima el fondo hacia el color de la app enfocada (0 = sin color). */
    void setTint(int color) {
        if (!st.shelf()) color = 0;
        if (color == tintTarget) return;
        tintTarget = color;
        int base = color == 0 ? (tintCur & 0xFFFFFF) : (color & 0xFFFFFF);
        final int to = color == 0 ? base : (0xC8000000 | base);
        final int from = tintCur == 0 ? base : tintCur;
        if (tintAnim != null) tintAnim.cancel();
        if (!st.anim()) {
            applyTint(to);
            return;
        }
        tintAnim = ValueAnimator.ofObject(new ArgbEvaluator(), from, to);
        tintAnim.setDuration(480);
        tintAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                applyTint((Integer) a.getAnimatedValue());
            }
        });
        tintAnim.start();
    }

    private void applyTint(int c) {
        tintCur = c;
        int a = c >>> 24;
        int low = ((a / 3) << 24) | (c & 0xFFFFFF);
        // sin color en toda la pantalla: el color de la app solo se nota en la fila de aplicaciones
        tintD.setColors(new int[]{0, 0});
        tint.invalidate();
        // la fila de aplicaciones (cristal) también se tiñe con el color de la app enfocada
        if (dockBand != null) {
            float k = Math.min(1f, (c >>> 24) / 200f);
            int target = 0x70000000 | (c & 0xFFFFFF);
            dockBand.setTint((Integer) argb.evaluate(k, BAND_BASE, target));
        }
    }

    private void updateCaption(View f) {
        if (capBox == null) return;
        if (f instanceof Cell && ((Cell) f).capName != null) {
            Cell c = (Cell) f;
            capName.setText(c.capName);
            capSub.setText(c.capSub == null ? "" : c.capSub);
            capBox.setVisibility(View.VISIBLE);
        } else if (menuLayer == null) {
            capBox.setVisibility(View.INVISIBLE);
        }
    }

    // ------------------------------------------------------------------ barra superior

    private void buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        bar.setPadding(0, 0, px(64), 0);
        content.addView(bar, new FrameLayout.LayoutParams(-1, px(96)));

        // Bluetooth
        Chip bt = new Chip(this, px(24));
        LinearLayout bl = new LinearLayout(this);
        bl.setOrientation(LinearLayout.HORIZONTAL);
        bl.setGravity(Gravity.CENTER_VERTICAL);
        bl.setPadding(px(14), 0, px(14), 0);
        btIcon = new Glyph(this, Glyph.BT, 0);
        bl.addView(btIcon, new LinearLayout.LayoutParams(px(28), px(28)));
        btDot = new StatusDot(this);
        LinearLayout.LayoutParams bdp = new LinearLayout.LayoutParams(px(10), px(10));
        bdp.leftMargin = px(6);
        bl.addView(btDot, bdp);
        btText = text("", 17, 0xE6FFFFFF, REG);
        btText.setSingleLine(true);
        btText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        btText.setMaxWidth(px(170));
        LinearLayout.LayoutParams btp = new LinearLayout.LayoutParams(-2, -2);
        btp.leftMargin = px(8);
        bl.addView(btText, btp);
        bt.addView(bl, new FrameLayout.LayoutParams(-2, -1));
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sfx.play(Sfx.SELECT);
                cc.open(2);
            }
        });
        bump(bt, btIcon);
        bar.addView(bt, new LinearLayout.LayoutParams(-2, px(48)));

        // Wi-Fi
        Chip wifi = new Chip(this, px(24));
        LinearLayout wl = new LinearLayout(this);
        wl.setOrientation(LinearLayout.HORIZONTAL);
        wl.setGravity(Gravity.CENTER_VERTICAL);
        wl.setPadding(px(14), 0, px(18), 0);
        wifiIcon = new WifiView(this);
        wl.addView(wifiIcon, new LinearLayout.LayoutParams(px(28), px(28)));
        netText = text("", 17, 0xE6FFFFFF, REG);
        netText.setSingleLine(true);
        netText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        netText.setMaxWidth(px(220));
        LinearLayout.LayoutParams ntp = new LinearLayout.LayoutParams(-2, -2);
        ntp.leftMargin = px(8);
        wl.addView(netText, ntp);
        wifi.addView(wl, new FrameLayout.LayoutParams(-2, -1));
        wifi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sfx.play(Sfx.SELECT);
                cc.open(1);
            }
        });
        bump(wifi, wifiIcon);
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(-2, px(48));
        wlp.leftMargin = px(14);
        bar.addView(wifi, wlp);

        // Ajustes
        Chip gear = new Chip(this, px(24));
        GearView gv = new GearView(this);
        gear.addView(gv, new FrameLayout.LayoutParams(px(30), px(30), Gravity.CENTER));
        gear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sfx.play(Sfx.SELECT);
                cc.open(0);
            }
        });
        final GearView gvf = gv;
        gear.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean has) {
                gvf.animate().cancel();
                gvf.animate().rotation(has ? 90f : 0f).setDuration(450)
                        .setInterpolator(new AccelerateDecelerateInterpolator()).start();
            }
        });
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(px(48), px(48));
        gl.leftMargin = px(14);
        bar.addView(gear, gl);
    }

    /** Pequeño salto del icono al enfocar el botón. */
    private void bump(View chip, final View icon) {
        chip.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean has) {
                icon.animate().cancel();
                if (has) {
                    icon.setScaleX(0.7f);
                    icon.setScaleY(0.7f);
                    icon.animate().scaleX(1.18f).scaleY(1.18f).setDuration(300)
                            .setInterpolator(new android.view.animation.OvershootInterpolator(2.5f)).start();
                } else {
                    icon.animate().scaleX(1f).scaleY(1f).setDuration(160).start();
                }
            }
        });
    }

    // ------------------------------------------------------------------ inicio

    private View buildHome() {
        homeScroll = new ScrollView(this);
        homeScroll.setVerticalScrollBarEnabled(false);
        homeScroll.setSmoothScrollingEnabled(true);
        homeScroll.setClipToPadding(false);
        homeScroll.setClipChildren(false);
        homeScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setClipChildren(false);
        homeScroll.addView(box, new FrameLayout.LayoutParams(-1, -2));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        greetTv = text("", 24, 0xE6FFFFFF, MEDIUM);
        clockTv = text("", 104, 0xFFFFFFFF, LIGHT);
        dateTv = text("", 24, 0xB8FFFFFF, REG);
        head.addView(greetTv);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
        cp.topMargin = px(4);
        head.addView(clockTv, cp);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-2, -2);
        dp.topMargin = px(2);
        head.addView(dateTv, dp);
        LinearLayout headRow = new LinearLayout(this);
        headRow.setOrientation(LinearLayout.HORIZONTAL);
        headRow.setGravity(Gravity.CENTER_VERTICAL);
        headRow.addView(head, new LinearLayout.LayoutParams(0, -2, 1f));
        wxHomeBox = new LinearLayout(this);
        wxHomeBox.setOrientation(LinearLayout.HORIZONTAL);
        wxHomeBox.setGravity(Gravity.END);
        wxHomeBox.setVisibility(View.GONE);
        headRow.addView(wxHomeBox, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(-1, -2);
        hl.leftMargin = px(72);
        hl.rightMargin = px(64);
        hl.topMargin = px(4);
        box.addView(headRow, hl);

        LinearLayout cap = new LinearLayout(this);
        cap.setOrientation(LinearLayout.VERTICAL);
        capName = text("", 34, 0xFFFFFFFF, MEDIUM);
        capSub = text("", 17, 0xB8FFFFFF, REG);
        cap.addView(capName);
        LinearLayout.LayoutParams csp = new LinearLayout.LayoutParams(-2, -2);
        csp.topMargin = px(4);
        cap.addView(capSub, csp);
        cap.setVisibility(View.INVISIBLE);
        capBox = cap;
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, px(84));
        cl.leftMargin = px(72);
        cl.topMargin = px(18);
        box.addView(cap, cl);

        GlassView band = new GlassView(this, px(36), BAND_BASE);
        dockBand = band;
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, px(172));
        bl.leftMargin = px(48);
        bl.rightMargin = px(48);
        box.addView(band, bl);

        dockScroll = new HorizontalScrollView(this);
        dockScroll.setHorizontalScrollBarEnabled(false);
        dockScroll.setSmoothScrollingEnabled(true);
        dockScroll.setClipToPadding(false);
        dockScroll.setClipChildren(false);
        dockScroll.setPadding(px(32), px(34), px(32), px(34));
        dockScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        dockRow = new LinearLayout(this);
        dockRow.setOrientation(LinearLayout.HORIZONTAL);
        dockRow.setClipChildren(false);
        dockScroll.addView(dockRow, new FrameLayout.LayoutParams(-2, -1));
        band.addView(dockScroll, new FrameLayout.LayoutParams(-1, -1));

        gridTitle = text("", 26, 0xFFFFFFFF, MEDIUM);
        LinearLayout.LayoutParams gtl = new LinearLayout.LayoutParams(-2, -2);
        gtl.leftMargin = px(72);
        gtl.topMargin = px(34);
        gtl.bottomMargin = px(6);
        box.addView(gridTitle, gtl);

        gridBox = new LinearLayout(this);
        gridBox.setOrientation(LinearLayout.VERTICAL);
        gridBox.setClipChildren(false);
        gridBox.setPadding(px(52), px(6), px(52), px(70));
        box.addView(gridBox, new LinearLayout.LayoutParams(-1, -2));
        return homeScroll;
    }

    private List<AppItem> favApps() {
        ArrayList<AppItem> out = new ArrayList<>();
        Set<String> hid = st.hidden();
        for (String p : st.favs()) {
            AppItem a = byPkg.get(p);
            if (a != null && !hid.contains(p)) out.add(a);
        }
        return out;
    }

    private List<AppItem> visibleApps() {
        ArrayList<AppItem> out = new ArrayList<>();
        Set<String> hid = st.hidden();
        for (AppItem a : apps) {
            if (!hid.contains(a.pkg)) out.add(a);
        }
        return out;
    }

    void refreshHome() {
        buildDock();
        buildGrid();
    }

    private void buildDock() {
        dockRow.removeAllViews();
        int cw = px(184), ch = px(104);
        List<AppItem> favs = favApps();
        for (final AppItem a : favs) {
            final Cell c = new Cell(this, u, cw, ch, cw, ch, 0, false);
            c.pkg = a.pkg;
            c.capName = a.label;
            c.capSub = getString(R.string.cap_hint);
            c.img.setTag(a.pkg);
            loadTile(a, c.img);
            c.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    launch(a);
                }
            });
            c.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    showAppMenu(a, true);
                    return true;
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(cw, ch);
            lp.rightMargin = px(18);
            dockRow.addView(c, lp);
            c.setAlpha(0f);
            c.setTranslationY(px(28));
            c.animate().alpha(1f).translationY(0f).setStartDelay(50L * dockRow.getChildCount())
                    .setDuration(420).setInterpolator(new DecelerateInterpolator())
                    .withEndAction(new Runnable() {
                        @Override
                        public void run() {
                            // por si la animación se cancela: la tarjeta nunca se queda transparente
                            c.setAlpha(1f);
                            c.setTranslationY(0f);
                        }
                    }).start();
        }
    }

    private void buildGrid() {
        gridBox.removeAllViews();
        List<AppItem> vis = visibleApps();
        gridTitle.setText(getString(R.string.all_apps) + "  ·  " + getString(R.string.apps_count, vis.size()));
        int cols = 6;
        int cw = (sw - px(104)) / cols;
        int tw = px(164);
        int th = Math.round(tw * TH / (float) TW);
        int topPad = px(12);
        int ch = topPad + th + px(9) + px(22) + px(14);
        for (int i = 0; i < vis.size(); i += cols) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setClipChildren(false);
            for (int j = 0; j < cols && i + j < vis.size(); j++) {
                final AppItem a = vis.get(i + j);
                Cell c = new Cell(this, u, cw, ch, tw, th, topPad, true);
                c.pkg = a.pkg;
                c.capName = a.label;
                c.capSub = "";
                c.label.setText(a.label);
                c.img.setTag(a.pkg);
                loadTile(a, c.img);
                c.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        launch(a);
                    }
                });
                c.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        showAppMenu(a, false);
                        return true;
                    }
                });
                row.addView(c, new LinearLayout.LayoutParams(cw, ch));
            }
            gridBox.addView(row, new LinearLayout.LayoutParams(-1, ch));
        }
    }

    void focusFirstFav() {
        if (dockRow != null && dockRow.getChildCount() > 0) {
            dockScroll.scrollTo(0, 0);
            dockRow.getChildAt(0).requestFocus();
        } else if (gridBox != null && gridBox.getChildCount() > 0) {
            View r = gridBox.getChildAt(0);
            if (r instanceof ViewGroup && ((ViewGroup) r).getChildCount() > 0) {
                ((ViewGroup) r).getChildAt(0).requestFocus();
            }
        }
    }

    private void focusDock(final String pkg) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < dockRow.getChildCount(); i++) {
                    View v = dockRow.getChildAt(i);
                    if (v instanceof Cell && pkg.equals(((Cell) v).pkg)) {
                        v.requestFocus();
                        return;
                    }
                }
                focusFirstFav();
            }
        });
    }

    // ------------------------------------------------------------------ apps: lanzar, menú, favoritos

    private void launch(final AppItem a) {
        sfx.play(Sfx.OPEN);
        final Runnable go = new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_MAIN);
                    i.addCategory(a.leanback ? Intent.CATEGORY_LEANBACK_LAUNCHER : Intent.CATEGORY_LAUNCHER);
                    i.setComponent(a.cn);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                    startActivity(i);
                    ui.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            removeOpenOverlay(true);
                        }
                    }, 3500);
                } catch (Throwable t) {
                    removeOpenOverlay(true);
                    toast(R.string.toast_fail);
                }
            }
        };
        View f = root.findFocus();
        if (f instanceof Cell && a.pkg.equals(((Cell) f).pkg) && f.getWidth() > 0 && st.anim()) {
            zoomOpen(f, a, go);
        } else {
            go.run();
        }
    }

    /** La tarjeta de la app se agranda hasta llenar la pantalla y entonces se abre la app. */
    private void zoomOpen(View cell, AppItem a, final Runnable go) {
        removeOpenOverlay(false);
        int[] l = new int[2];
        cell.getLocationOnScreen(l);
        int w = cell.getWidth(), h = cell.getHeight();
        FrameLayout ov = new FrameLayout(this);
        ov.setClickable(true);
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        Bitmap b = tiles.get(a.pkg);
        if (b != null) iv.setImageBitmap(b);
        else iv.setBackgroundColor(0xFF1B2233);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(w, h);
        lp.leftMargin = l[0];
        lp.topMargin = l[1];
        ov.addView(iv, lp);
        root.addView(ov, new FrameLayout.LayoutParams(-1, -1));
        openOv = ov;
        float s = Math.max(sw / (float) w, sh / (float) h) * 1.05f;
        float dx = sw / 2f - (l[0] + w / 2f);
        float dy = sh / 2f - (l[1] + h / 2f);
        iv.animate().scaleX(s).scaleY(s).translationX(dx).translationY(dy).setDuration(360)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .withEndAction(go).start();
        content.animate().alpha(0f).setDuration(300).start();
    }

    private void removeOpenOverlay(boolean fade) {
        content.animate().cancel();
        if (!saverOn) content.setAlpha(1f);
        final View ov = openOv;
        if (ov == null) return;
        openOv = null;
        if (fade) {
            ov.animate().alpha(0f).setDuration(320).withEndAction(new Runnable() {
                @Override
                public void run() {
                    root.removeView(ov);
                }
            }).start();
        } else {
            root.removeView(ov);
        }
    }

    private void showAppMenu(final AppItem a, boolean fromDock) {
        sfx.play(Sfx.SELECT);
        final ArrayList<String> labels = new ArrayList<>();
        final ArrayList<Runnable> acts = new ArrayList<>();
        final List<String> favs = st.favs();
        final boolean isFav = favs.contains(a.pkg);

        labels.add(getString(R.string.menu_open));
        acts.add(new Runnable() {
            @Override
            public void run() {
                launch(a);
            }
        });
        if (fromDock) {
            final int idx = favs.indexOf(a.pkg);
            if (idx > 0) {
                labels.add(getString(R.string.menu_left));
                acts.add(new Runnable() {
                    @Override
                    public void run() {
                        moveFav(a.pkg, -1);
                    }
                });
            }
            if (idx >= 0 && idx < favs.size() - 1) {
                labels.add(getString(R.string.menu_right));
                acts.add(new Runnable() {
                    @Override
                    public void run() {
                        moveFav(a.pkg, 1);
                    }
                });
            }
        }
        labels.add(getString(isFav ? R.string.menu_remove : R.string.menu_add));
        acts.add(new Runnable() {
            @Override
            public void run() {
                ArrayList<String> f = new ArrayList<>(st.favs());
                if (isFav) f.remove(a.pkg);
                else f.add(a.pkg);
                st.setFavs(f);
                buildDock();
                if (isFav) focusFirstFav();
                else focusDock(a.pkg);
            }
        });
        labels.add(getString(R.string.menu_hide));
        acts.add(new Runnable() {
            @Override
            public void run() {
                HashSet<String> h = new HashSet<>(st.hidden());
                h.add(a.pkg);
                st.setHidden(h);
                refreshHome();
                focusFirstFav();
            }
        });
        labels.add(getString(R.string.menu_info));
        acts.add(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.fromParts("package", a.pkg, null));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Throwable t) {
                    toast(R.string.toast_fail);
                }
            }
        });
        showMenu(a.label, labels, acts);
    }

    private void moveFav(String pkg, int delta) {
        ArrayList<String> f = new ArrayList<>(st.favs());
        int i = f.indexOf(pkg);
        int j = i + delta;
        if (i < 0 || j < 0 || j >= f.size()) return;
        Collections.swap(f, i, j);
        st.setFavs(f);
        buildDock();
        focusDock(pkg);
    }

    private void showMenu(String title, List<String> labels, final List<Runnable> acts) {
        dismissMenu(false);
        menuPrevFocus = root.findFocus();
        menuLayer = new FrameLayout(this);
        menuLayer.setBackgroundColor(0x9E000000);
        menuLayer.setClickable(true);

        GlassView panel = new GlassView(this, px(28), 0x7A141C2E);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(px(16), px(18), px(16), px(16));
        TextView t = text(title, 24, 0xFFFFFFFF, MEDIUM);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setPadding(px(10), 0, px(10), px(10));
        col.addView(t, new LinearLayout.LayoutParams(-1, -2));
        Row first = null;
        for (int i = 0; i < labels.size(); i++) {
            final int k = i;
            Row r = new Row(this, u, labels.get(i));
            r.value.setVisibility(View.GONE);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    sfx.play(Sfx.SELECT);
                    dismissMenu(true);
                    acts.get(k).run();
                }
            });
            col.addView(r, new LinearLayout.LayoutParams(-1, px(56)));
            if (first == null) first = r;
        }
        panel.addView(col, new FrameLayout.LayoutParams(-1, -2));
        menuLayer.addView(panel, new FrameLayout.LayoutParams(px(460), -2, Gravity.CENTER));
        root.addView(menuLayer, new FrameLayout.LayoutParams(-1, -1));
        blockContent(true);
        if (first != null) first.requestFocus();
    }

    private void dismissMenu(boolean restoreFocus) {
        if (menuLayer == null) return;
        root.removeView(menuLayer);
        menuLayer = null;
        blockContent(false);
        View p = menuPrevFocus;
        menuPrevFocus = null;
        if (restoreFocus && p != null && p.isAttachedToWindow()) p.requestFocus();
    }

    // ------------------------------------------------------------------ iconos y fondo

    private void loadTile(final AppItem a, final ImageView iv) {
        Bitmap b = tiles.get(a.pkg);
        if (b != null) {
            iv.setImageBitmap(b);
            return;
        }
        try {
            io.execute(new Runnable() {
                @Override
                public void run() {
                    Bitmap nb = tiles.get(a.pkg);
                    if (nb == null) {
                        nb = TileFactory.make(getPackageManager(), a, TW, TH);
                        tiles.put(a.pkg, nb);
                    }
                    final Bitmap fb = nb;
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            if (a.pkg.equals(iv.getTag())) iv.setImageBitmap(fb);
                            View f = root.findFocus();
                            if (f instanceof Cell && a.pkg.equals(((Cell) f).pkg)
                                    && !(cc != null && cc.open)) {
                                setTint(colorFor(a.pkg));
                            }
                        }
                    });
                }
            });
        } catch (Throwable ignored) {
        }
    }

    private boolean wallFirst = true;
    private WallSource wsrc;
    private final ExecutorService wallEx = Executors.newSingleThreadExecutor();
    private volatile boolean wallBusy;

    void applyWallpaper() {
        ui.removeCallbacks(homeCycleR);
        loadWall();
        ui.postDelayed(homeCycleR, 30000);
    }

    /** Cambia el fondo de Inicio de forma suave cada rato. */
    private final Runnable homeCycleR = new Runnable() {
        @Override
        public void run() {
            if (!saverOn && !(cc != null && cc.open) && menuLayer == null) loadWall();
            ui.postDelayed(homeCycleR, 30000);
        }
    };

    private void loadWall() {
        if (wallBusy) return;
        wallBusy = true;
        if (wsrc == null) {
            wsrc = new WallSource(this);
            // en cuanto el índice de fotos tenga las primeras, se cambia el fondo abstracto por una foto
            wsrc.setOnReady(new Runnable() {
                @Override
                public void run() {
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            photoSoon(8);
                        }
                    });
                }
            });
        }
        final int mode = st.wallpaper();
        final boolean fade = !wallFirst;
        wallFirst = false;
        try {
            wallEx.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        final Bitmap w = wsrc.next(mode);
                        final String cr = wsrc.credit();
                        final Bitmap f = Blur.frost(w, 160, 90, 4, 3);
                        ui.post(new Runnable() {
                            @Override
                            public void run() {
                                if (creditTv != null) creditTv.setText(cr.isEmpty() ? "" : getString(R.string.photo_credit, cr));
                                wall.setBitmap(w, fade ? 2600 : 0);
                                GlassView.setBackdrop(f, sw, sh);
                                invalidateGlass(root);
                            }
                        });
                    } catch (Throwable ignored) {
                    } finally {
                        wallBusy = false;
                    }
                }
            });
        } catch (Throwable t) {
            wallBusy = false;
        }
    }

    /** Pide una foto nueva en cuanto el cargador de fondos esté libre (reintenta unas veces). */
    private void photoSoon(final int tries) {
        if (tries <= 0 || saverOn) return;
        if (wallBusy) {
            ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    photoSoon(tries - 1);
                }
            }, 2500);
            return;
        }
        loadWall();
    }

    void startDrift() {
        if (!st.anim() || drift != null) return;
        drift = ValueAnimator.ofFloat(0f, 1f);
        drift.setDuration(50000);
        drift.setRepeatCount(ValueAnimator.INFINITE);
        drift.setInterpolator(new LinearInterpolator());
        drift.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                float t = (Float) a.getAnimatedValue();
                double ang = t * 2 * Math.PI;
                wall.setTranslationX((float) Math.sin(ang) * px(16));
                wall.setTranslationY((float) Math.cos(ang) * px(8));
            }
        });
        drift.start();
    }

    void stopDrift() {
        if (drift != null) {
            drift.cancel();
            drift = null;
        }
        wall.setTranslationX(0f);
        wall.setTranslationY(0f);
    }

    // ------------------------------------------------------------------ cargar apps

    private void reloadApps(final boolean first) {
        bg.execute(new Runnable() {
            @Override
            public void run() {
                final List<AppItem> l = AppRepo.load(MainActivity.this);
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        apps = l;
                        byPkg.clear();
                        for (AppItem a : l) byPkg.put(a.pkg, a);
                        if (!st.favsReady()) initFavs();
                        refreshHome();
                        if (first) focusFirstFav();
                    }
                });
            }
        });
    }

    private void initFavs() {
        ArrayList<String> f = new ArrayList<>();
        for (String p : AppRepo.PREFERRED) {
            if (byPkg.containsKey(p) && f.size() < 7) f.add(p);
        }
        for (AppItem a : apps) {
            if (f.size() >= 5) break;
            if (!f.contains(a.pkg)) f.add(a.pkg);
        }
        st.setFavs(f);
    }

    private final Runnable reloadR = new Runnable() {
        @Override
        public void run() {
            reloadApps(false);
        }
    };

    // ------------------------------------------------------------------ reloj, red, ajustes del sistema

    void updateClock() {
        String t = fmtTime();
        clockTv.setText(t);
        saverClock.setText(t);
        saverDate.setText(fmtDate());
        dateTv.setText(fmtDate());
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        int g = h < 6 ? R.string.greet_night : (h < 13 ? R.string.greet_morning
                : (h < 20 ? R.string.greet_afternoon : R.string.greet_night));
        String name = st.name();
        String greet = name.isEmpty() ? getString(g) : getString(g) + ", " + name;
        greetTv.setText(greet);
        saverGreet.setText(greet);
        if (cc != null) cc.tick();
    }

    void updateNet() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            String label;
            int level;
            if (ni == null || !ni.isConnected()) {
                label = getString(R.string.net_off);
                level = 0;
            } else if (ni.getType() == ConnectivityManager.TYPE_ETHERNET) {
                label = getString(R.string.net_ethernet);
                level = 4;
            } else {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                WifiInfo wi = wm.getConnectionInfo();
                level = WifiManager.calculateSignalLevel(wi.getRssi(), 5);
                String ssid = wi.getSSID();
                if (ssid != null) ssid = ssid.replace("\"", "");
                label = (ssid == null || ssid.isEmpty() || ssid.contains("unknown"))
                        ? getString(R.string.net_connected) : ssid;
            }
            wifiIcon.setLevel(level);
            netText.setText(label);
        } catch (Throwable t) {
            wifiIcon.setLevel(0);
            netText.setText(R.string.net_off);
        }
        if (cc != null) cc.netChanged();
    }

    boolean tryStart(Intent... list) {
        for (Intent i : list) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return true;
            } catch (Throwable ignored) {
            }
        }
        toast(R.string.toast_fail);
        return false;
    }

    void openWifiSettings() {
        tryStart(new Intent(Settings.ACTION_WIFI_SETTINGS), new Intent(Settings.ACTION_SETTINGS));
    }

    void openBluetoothSettings() {
        tryStart(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS), new Intent(Settings.ACTION_SETTINGS));
    }

    void openSystemSettings() {
        tryStart(new Intent(Settings.ACTION_SETTINGS));
    }

    private final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (a == null) return;
            if (Intent.ACTION_TIME_TICK.equals(a) || Intent.ACTION_TIME_CHANGED.equals(a)
                    || Intent.ACTION_TIMEZONE_CHANGED.equals(a)) {
                updateClock();
            } else if (a.startsWith("android.intent.action.PACKAGE")) {
                ui.removeCallbacks(reloadR);
                ui.postDelayed(reloadR, 700);
            } else if (a.startsWith("android.bluetooth")) {
                updateBt();
                ui.removeCallbacks(btR);
                ui.postDelayed(btR, 1500);
            } else {
                updateNet();
            }
        }
    };

    private final Runnable btR = new Runnable() {
        @Override
        public void run() {
            updateBt();
        }
    };

    // ------------------------------------------------------------------ Bluetooth en la barra

    void updateBt() {
        boolean on = false;
        int n = 0;
        String first = null;
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            on = ad != null && ad.isEnabled();
            if (on) {
                for (BluetoothDevice d : ad.getBondedDevices()) {
                    if (BtUtil.isConn(d)) {
                        n++;
                        if (first == null) first = BtUtil.nameOf(d);
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        btIcon.setAlpha(on ? 1f : 0.45f);
        btDot.setOn(n > 0);
        btDot.setVisibility(on ? View.VISIBLE : View.GONE);
        btText.setText(n == 0 ? "" : (n == 1 ? first : getString(R.string.bt_n_conn, n)));
        btText.setVisibility(n == 0 ? View.GONE : View.VISIBLE);
        if (cc != null) cc.btChanged();
    }

    // ------------------------------------------------------------------ el tiempo

    private final Runnable wxR = new Runnable() {
        @Override
        public void run() {
            refreshWeather(false);
            ui.postDelayed(wxR, 20 * 60000L);
        }
    };

    void refreshWeather(boolean force) {
        List<String[]> pl = st.places();
        if (pl.isEmpty()) return;
        if (!force && !st.wxHome() && !st.wxLock()) return;
        wx.refresh(pl, force, new Weather.Done() {
            @Override
            public void done() {
                updateWeatherViews();
            }
        });
    }

    private String fmtTemp(float c) {
        float v = st.fahrenheit() ? c * 9f / 5f + 32f : c;
        return Math.round(v) + "°";
    }

    void updateWeatherViews() {
        List<String[]> pl = st.places();
        boolean home = st.wxHome() && !pl.isEmpty();
        wxHomeBox.setVisibility(home ? View.VISIBLE : View.GONE);
        if (home) fillHomeWx(pl);
        boolean lock = st.wxLock() && !pl.isEmpty();
        wxLockBox.setVisibility(lock ? View.VISIBLE : View.GONE);
        if (lock) fillLockWx(pl);
    }

    private void fillHomeWx(List<String[]> pl) {
        wxHomeBox.removeAllViews();
        for (int i = 0; i < pl.size() && i < 2; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            if (i > 0) lp.leftMargin = px(12);
            wxHomeBox.addView(forecastCard(pl.get(i), true), lp);
        }
    }

    private void fillLockWx(List<String[]> pl) {
        wxLockBox.removeAllViews();
        for (int i = 0; i < pl.size() && i < 2; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            if (i > 0) lp.leftMargin = px(18);
            wxLockBox.addView(forecastCard(pl.get(i), false), lp);
        }
    }

    /** Tarjeta con el tiempo de ahora y los próximos 5 días (no se puede pulsar). */
    private View forecastCard(String[] p, boolean compact) {
        float k = compact ? 0.78f : 1f;
        Weather.Wx w = wx.get(p);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(px(20 * k), px(14 * k), px(20 * k), px(14 * k));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(compact ? 0x330E1424 : 0x38FFFFFF);
        gd.setCornerRadius(px(28 * k));
        gd.setStroke(Math.max(1, px(1)), 0x44FFFFFF);
        card.setBackground(gd);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        WxView nowIc = new WxView(this);
        if (w != null) nowIc.set(w.code, w.day);
        head.addView(nowIc, new LinearLayout.LayoutParams(px(52 * k), px(52 * k)));
        TextView city = text(p[0], 24 * k, 0xFFFFFFFF, MEDIUM);
        city.setSingleLine(true);
        city.setEllipsize(android.text.TextUtils.TruncateAt.END);
        city.setMaxWidth(px(230 * k));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
        cp.leftMargin = px(10 * k);
        head.addView(city, cp);
        head.addView(text(w == null ? "–°" : fmtTemp(w.temp), 44 * k, 0xFFFFFFFF, LIGHT));
        card.addView(head, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout days = new LinearLayout(this);
        days.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-2, -2);
        dl.topMargin = px(8 * k);
        card.addView(days, dl);
        int n = w == null ? 0 : w.n;
        for (int i = 0; i < n; i++) {
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER_HORIZONTAL);
            col.addView(text(w.dName[i], 16 * k, 0xCCFFFFFF, REG));
            WxView ic = new WxView(this);
            ic.set(w.dCode[i], true);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(px(40 * k), px(40 * k));
            ip.topMargin = px(2 * k);
            col.addView(ic, ip);
            col.addView(text(fmtTemp(w.dMax[i]), 19 * k, 0xFFFFFFFF, MEDIUM));
            col.addView(text(fmtTemp(w.dMin[i]), 16 * k, 0x99FFFFFF, REG));
            days.addView(col, new LinearLayout.LayoutParams(px(78 * k), -2));
        }
        return card;
    }

    // ------------------------------------------------------------------ pantalla de bloqueo

    private void buildSaver() {
        saver = new FrameLayout(this);
        saver.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x77000000, 0x14000000, 0xA0000000}));
        saver.setClickable(true);
        saver.setVisibility(View.GONE);

        saverCol = new LinearLayout(this);
        saverCol.setOrientation(LinearLayout.VERTICAL);
        saverCol.setGravity(Gravity.START);
        Glyph lock = new Glyph(this, Glyph.LOCK, 0);
        saverCol.addView(lock, new LinearLayout.LayoutParams(px(32), px(32)));
        saverDate = text("", 30, 0xE6FFFFFF, MEDIUM);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-2, -2);
        dl.topMargin = px(8);
        saverCol.addView(saverDate, dl);
        saverClock = text("", 176, 0xFFFFFFFF, LIGHT);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2);
        cl.topMargin = px(0);
        saverCol.addView(saverClock, cl);
        saverGreet = text("", 32, 0xF2FFFFFF, MEDIUM);
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(-2, -2);
        gl.topMargin = px(2);
        saverCol.addView(saverGreet, gl);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        sp.topMargin = px(56);
        sp.leftMargin = px(72);
        saver.addView(saverCol, sp);

        wxLockBox = new LinearLayout(this);
        wxLockBox.setOrientation(LinearLayout.HORIZONTAL);
        wxLockBox.setVisibility(View.GONE);
        FrameLayout.LayoutParams wp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START);
        wp.bottomMargin = px(96);
        wp.leftMargin = px(72);
        saver.addView(wxLockBox, wp);

        TextView hint = text(getString(R.string.lock_hint), 18, 0x99FFFFFF, REG);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START);
        hp.bottomMargin = px(44);
        hp.leftMargin = px(76);
        saver.addView(hint, hp);

        creditTv = text("", 14, 0x88FFFFFF, REG);
        creditTv.setSingleLine(true);
        creditTv.setEllipsize(android.text.TextUtils.TruncateAt.END);
        creditTv.setMaxWidth(px(900));
        FrameLayout.LayoutParams crp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        crp.bottomMargin = px(44);
        crp.rightMargin = px(72);
        saver.addView(creditTv, crp);
        root.addView(saver, new FrameLayout.LayoutParams(-1, -1));
    }

    private final Runnable idleR = new Runnable() {
        @Override
        public void run() {
            showSaver(false);
        }
    };

    /** Cambia suavemente de fondo mientras la pantalla de bloqueo está activa. */
    private final Runnable cycleR = new Runnable() {
        @Override
        public void run() {
            if (!saverOn) return;
            lockWall = (lockWall + 1) % WallpaperFactory.COUNT;
            loadWall();
            ui.postDelayed(cycleR, 14000);
        }
    };

    void resetIdle() {
        ui.removeCallbacks(idleR);
        int m = st.idleMin();
        if (st.lockOn() && m > 0 && !saverOn) ui.postDelayed(idleR, m * 60000L);
    }

    /** Muestra la pantalla de bloqueo ahora mismo (vista previa desde Ajustes). */
    void previewLock() {
        if (cc != null && cc.open) cc.close();
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                showSaver(true);
            }
        }, 250);
    }

    private void showSaver(boolean force) {
        if (saverOn) return;
        if (!force && (menuLayer != null || (cc != null && cc.open))) {
            resetIdle();
            return;
        }
        saverOn = true;
        updateClock();
        updateWeatherViews();
        refreshWeather(false);
        saver.animate().cancel();
        saverCol.animate().cancel();
        wxLockBox.animate().cancel();
        saver.setAlpha(0f);
        saver.setVisibility(View.VISIBLE);
        saverCol.setAlpha(0f);
        saverCol.setTranslationX(-px(70));
        wxLockBox.setAlpha(0f);
        wxLockBox.setTranslationY(px(50));
        saver.animate().alpha(1f).setDuration(700).setInterpolator(new DecelerateInterpolator()).start();
        saverCol.animate().alpha(1f).translationX(0f).setStartDelay(250).setDuration(800)
                .setInterpolator(new DecelerateInterpolator()).start();
        wxLockBox.animate().alpha(1f).translationY(0f).setStartDelay(450).setDuration(800)
                .setInterpolator(new DecelerateInterpolator()).start();
        content.animate().cancel();
        content.animate().alpha(0f).scaleX(0.96f).scaleY(0.96f).setDuration(600).start();
        tint.animate().alpha(0f).setDuration(500).start();
        lockWall = st.wallpaper();
        ui.removeCallbacks(cycleR);
        ui.postDelayed(cycleR, 12000);
    }

    private void hideSaver() {
        saverOn = false;
        ui.removeCallbacks(cycleR);
        sfx.play(Sfx.UNLOCK);
        saver.animate().cancel();
        saverCol.animate().cancel();
        wxLockBox.animate().cancel();
        saverCol.animate().alpha(0f).translationX(-px(90)).setStartDelay(0).setDuration(380)
                .setInterpolator(new AccelerateDecelerateInterpolator()).start();
        wxLockBox.animate().alpha(0f).translationY(px(60)).setStartDelay(0).setDuration(380).start();
        saver.animate().alpha(0f).setStartDelay(80).setDuration(520).withEndAction(new Runnable() {
            @Override
            public void run() {
                if (!saverOn) saver.setVisibility(View.GONE);
            }
        }).start();
        content.animate().cancel();
        content.setScaleX(1.06f);
        content.setScaleY(1.06f);
        content.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(120).setDuration(620)
                .setInterpolator(new DecelerateInterpolator()).start();
        tint.animate().cancel();
        tint.animate().alpha(1f).setStartDelay(300).setDuration(500).start();
        resetIdle();
    }
}
