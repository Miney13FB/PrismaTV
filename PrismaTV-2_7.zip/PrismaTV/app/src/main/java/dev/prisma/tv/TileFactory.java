package dev.prisma.tv;

import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;

/**
 * Crea la tarjeta de cada app: 1) su banner de Android TV a pantalla completa;
 * 2) si no tiene, su icono sobre un degradado con el color dominante y el nombre.
 */
final class TileFactory {

    static Bitmap make(PackageManager pm, AppItem a, int w, int h) {
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);

        Drawable banner = null;
        try {
            banner = a.ri.activityInfo.loadBanner(pm);
            if (banner == null) banner = a.ri.activityInfo.applicationInfo.loadBanner(pm);
        } catch (Throwable ignored) {
        }
        if (banner != null) {
            drawCover(c, banner, w, h);
            // algunos banners (p. ej. YouTube) pueden salir casi transparentes: en ese caso se usa el icono
            if (!mostlyBlank(out)) return out;
            out.eraseColor(0);
        }

        Drawable icon = null;
        try {
            icon = a.ri.loadIcon(pm);
        } catch (Throwable ignored) {
        }
        int base = icon != null ? dominant(icon) : 0xFF3A4A66;

        float[] hsv = new float[3];
        Color.colorToHSV(base, hsv);
        hsv[1] = Math.max(hsv[1], 0.45f);
        hsv[2] = Math.min(Math.max(hsv[2], 0.55f), 0.90f);
        int top = Color.HSVToColor(hsv);
        hsv[2] *= 0.50f;
        int bot = Color.HSVToColor(hsv);

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, w * 0.4f, h, top, bot, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);

        if (icon != null) {
            int s = (int) (h * 0.50f);
            int l = (w - s) / 2;
            int t = (int) (h * 0.12f);
            icon.setBounds(l, t, l + s, t + s);
            icon.draw(c);
        }

        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setColor(0xFFFFFFFF);
        tp.setTextSize(h * 0.135f);
        tp.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tp.setTextAlign(Paint.Align.CENTER);
        tp.setShadowLayer(h * 0.03f, 0, h * 0.01f, 0x99000000);
        CharSequence lab = TextUtils.ellipsize(a.label, new android.text.TextPaint(tp), w * 0.86f,
                TextUtils.TruncateAt.END);
        c.drawText(lab, 0, lab.length(), w / 2f, h * 0.90f, tp);
        return out;
    }

    /** Tarjeta "Todas las apps": cuadrícula de 3x3 sobre degradado azul. */
    static Bitmap allApps(int w, int h) {
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, w, h, 0xFF3B4FA0, 0xFF161C3A, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);
        p.setColor(0xE6FFFFFF);
        float cell = h * 0.17f;
        float gap = h * 0.06f;
        float total = cell * 3 + gap * 2;
        float x0 = (w - total) / 2f;
        float y0 = (h - total) / 2f;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                float x = x0 + j * (cell + gap);
                float y = y0 + i * (cell + gap);
                p.setAlpha(i == 1 && j == 1 ? 255 : 190);
                c.drawRoundRect(new RectF(x, y, x + cell, y + cell), cell * 0.28f, cell * 0.28f, p);
            }
        }
        return out;
    }

    /** Color representativo de una tarjeta ya hecha (para teñir el fondo). 0 si no hay color claro. */
    static int dominantOf(Bitmap src) {
        try {
            Bitmap s = Bitmap.createScaledBitmap(src, 24, 24, true);
            double r = 0, g = 0, b = 0, wt = 0;
            float[] hsv = new float[3];
            for (int y = 0; y < 24; y++) {
                for (int x = 0; x < 24; x++) {
                    int px = s.getPixel(x, y);
                    Color.colorToHSV(px, hsv);
                    double wgt = hsv[1] * hsv[1] * hsv[2];
                    if (wgt < 0.04) continue;
                    r += Color.red(px) * wgt;
                    g += Color.green(px) * wgt;
                    b += Color.blue(px) * wgt;
                    wt += wgt;
                }
            }
            if (s != src) s.recycle();
            if (wt < 0.5) return 0xFF4A5A80;
            int c = Color.rgb((int) (r / wt), (int) (g / wt), (int) (b / wt));
            Color.colorToHSV(c, hsv);
            hsv[1] = Math.max(hsv[1], 0.55f);
            hsv[2] = Math.min(Math.max(hsv[2], 0.50f), 0.85f);
            return Color.HSVToColor(hsv);
        } catch (Throwable t) {
            return 0xFF4A5A80;
        }
    }

    /** true si la tarjeta es casi toda transparente (no se vería nada). */
    private static boolean mostlyBlank(Bitmap b) {
        try {
            Bitmap s = Bitmap.createScaledBitmap(b, 24, 14, true);
            int solid = 0;
            for (int y = 0; y < 14; y++) {
                for (int x = 0; x < 24; x++) {
                    if (Color.alpha(s.getPixel(x, y)) > 40) solid++;
                }
            }
            if (s != b) s.recycle();
            return solid < 24 * 14 * 0.25;
        } catch (Throwable t) {
            return false;
        }
    }

    private static void drawCover(Canvas c, Drawable d, int w, int h) {
        int iw = d.getIntrinsicWidth();
        int ih = d.getIntrinsicHeight();
        if (iw <= 0 || ih <= 0) {
            d.setBounds(0, 0, w, h);
            d.draw(c);
            return;
        }
        float s = Math.max(w / (float) iw, h / (float) ih);
        c.save();
        c.translate((w - iw * s) / 2f, (h - ih * s) / 2f);
        c.scale(s, s);
        d.setBounds(0, 0, iw, ih);
        d.draw(c);
        c.restore();
    }

    private static int dominant(Drawable icon) {
        try {
            Bitmap s = Bitmap.createBitmap(24, 24, Bitmap.Config.ARGB_8888);
            Canvas sc = new Canvas(s);
            icon.setBounds(0, 0, 24, 24);
            icon.draw(sc);
            double r = 0, g = 0, b = 0, wt = 0;
            float[] hsv = new float[3];
            for (int y = 0; y < 24; y++) {
                for (int x = 0; x < 24; x++) {
                    int px = s.getPixel(x, y);
                    if (Color.alpha(px) < 128) continue;
                    Color.colorToHSV(px, hsv);
                    double wgt = hsv[1] * hsv[2];
                    if (wgt < 0.05) continue;
                    r += Color.red(px) * wgt;
                    g += Color.green(px) * wgt;
                    b += Color.blue(px) * wgt;
                    wt += wgt;
                }
            }
            s.recycle();
            if (wt < 1) return 0xFF3A4A66;
            return Color.rgb((int) (r / wt), (int) (g / wt), (int) (b / wt));
        } catch (Throwable t) {
            return 0xFF3A4A66;
        }
    }
}
