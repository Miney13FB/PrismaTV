# Prisma TV 2
Launcher ligero para Fire TV: un solo Inicio (dock + todas las apps), fondo que toma el color de cada app,
y Centro de control propio (botón ≡ del mando o el engranaje): Wi-Fi, Bluetooth, volumen, RAM, fondos y atajos.

Opcional (ADB, una vez) para que Wi-Fi/Bluetooth busquen sin pedir permiso:
  adb shell pm grant dev.prisma.tv android.permission.ACCESS_FINE_LOCATION

## v2.1
- Ajustes propios estilo iPhone (interruptores verdes/grises): Wi-Fi, Bluetooth, pantalla de bloqueo, tiempo, dispositivo.
- Bluetooth junto al Wi-Fi en la barra superior; búsqueda y conexión corregidas.
- El tiempo por ciudad (opcional en Inicio) con Open-Meteo, sin claves.
- Pantalla de bloqueo con hora, fecha, nombre y tiempo tras unos minutos sin usar el mando.
- Quitados logo, animaciones y volumen.

Permisos opcionales por ADB:
    adb shell pm grant dev.prisma.tv android.permission.ACCESS_FINE_LOCATION
    adb shell settings put secure location_mode 3

## v2.2
- 12 fondos nuevos (colores, animales y lugares del mundo) con cambio suave entre fondos.
- Tiempo con los próximos 5 días (pulsa una tarjeta del Inicio) y en la pantalla de bloqueo.
- Pantalla de bloqueo con textos a la izquierda, fondos que cambian solos y animación al volver al Inicio.
- Animación de apertura de apps, ajustes y iconos animados, sonidos nuevos más suaves.

## v2.3
- Tiempo del Inicio sin foco, con la previsión de 5 días.
- Apps ocultas como lista con interruptores; Apps instaladas con menú por app (caché, datos, detener, desinstalar, permisos).
- Pantalla, Sonido y Mi Fire TV dentro de Prisma.
- Quitado "Ajustes completos".

## v2.4
- Fondos con fotos reales (animales, paisajes, lugares del mundo, ciudades) de Wikimedia Commons, que cambian solas con fundido suave.
- Pantalla, Sonido y suspensión funcionan dentro de Prisma; lista de todas las pantallas de ajustes del sistema.

Permisos por ADB (una vez):
    adb shell pm grant dev.prisma.tv android.permission.WRITE_SECURE_SETTINGS
    adb shell appops set dev.prisma.tv WRITE_SETTINGS allow

## v2.5
- Fondos: solo fotos reales de Wikimedia Commons (destacadas y de calidad) con licencia libre (dominio público, CC0, CC BY, CC BY-SA); ciudades, animales, paisajes y maravillas del mundo (Taj Mahal, Machu Picchu, Petra, Coliseo...). Crédito de la foto en la pantalla de bloqueo. La primera foto aparece en cuanto se indexan las primeras (sin esperar).
- Fila de apps del Inicio: el cristal ahora cambia de color con la app enfocada (modo top shelf).
- Pantalla y Sonido: cada opción abre su pantalla de Fire OS; si no existe, la de Android y, si tampoco, los ajustes principales de Fire TV. Añadido "Más ajustes de sonido de Fire TV". Quitada la lista "Pantallas del sistema".

## v2.6
- Pantalla y Sonido: se quitan todas las opciones propias; cada uno abre directamente los ajustes de Fire TV (launcher original), no su pantalla de inicio. Eliminada "Pantallas del sistema".
- Fondo: ahora es una lista por categorías (Mezcla, Animales, Paisajes, Lugares del mundo, Ciudades, Abstractos). Si una categoría aún no tiene fotos descargadas se usan fotos de otra en vez de un fondo azul; búsqueda de fotos con más fuentes de respaldo.
- Top Shelf más discreto: ya no tiñe toda la pantalla; el color de la app solo se nota, suave, en la fila de aplicaciones.

## v2.7
- Top Shelf eliminado (ya no hay color de app ni interruptor).
- Fondos del Inicio y de la pantalla de bloqueo: solo fotos reales (Animales, Paisajes, Lugares del mundo, Ciudades o Mezcla); se quitan los abstractos. Más búsquedas de respaldo, sobre todo para ciudades. Sin fotos descargadas (primera vez sin internet) se ve un fondo liso oscuro.
- Pantalla y Sonido: abren los ajustes de Fire TV (el original); desde ahí se entra en Pantalla y sonidos. Sin pantallas ni opciones propias.
- Mi Fire TV simplificado: nombre, tipo, capacidad, software, almacenamiento e IP; "Liberar RAM" ahora está aquí.
- Arreglado: YouTube (primera app del dock) se quedaba transparente al iniciar; opción de ajustes que quedaba marcada tras cerrar; la pantalla se mantiene siempre encendida para que la pantalla de bloqueo no pase a negro.

## v2.7.1
- Al final del menú de ajustes se muestra la versión instalada ("Prisma TV 2.7.1") para comprobar que se instaló el APK nuevo.
